-- ============================================================================
-- StockAI 2.0 Database Schema
-- 支持: PostgreSQL, SQLite
-- 基于 Phase 1 架构设计，兼容 src-2.0 现有表结构
-- ============================================================================

-- ============================================================================
-- 1. 核心用户相关表
-- ============================================================================

-- -----------------------------------------------------------------------------
-- 1.1 user_accounts (用户账号主表)
-- -----------------------------------------------------------------------------
-- Phase 1: users 表重新命名，作为统一用户入口
-- 兼容 src-2.0: user_accounts 表
CREATE TABLE user_accounts (
    -- 主键策略: UUID v4，支持分布式生成
    user_id TEXT PRIMARY KEY,  -- SQLite 兼容格式，PostgreSQL 可用 UUID 类型

    -- 基础信息
    nickname VARCHAR(100) NOT NULL DEFAULT '',
    email VARCHAR(255),
    phone VARCHAR(20),
    avatar_url TEXT,

    -- 账号状态
    status VARCHAR(20) DEFAULT 'active',  -- 'active' | 'inactive' | 'suspended'

    -- 时间戳 (ISO 8601 格式，SQLite 兼容)
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),

    -- CHECK 约束
    CONSTRAINT chk_user_status CHECK (status IN ('active', 'inactive', 'suspended'))
);

-- 索引
CREATE INDEX idx_user_accounts_status ON user_accounts(status);
CREATE INDEX idx_user_accounts_created ON user_accounts(created_at);
CREATE INDEX idx_user_accounts_email ON user_accounts(email) WHERE email IS NOT NULL;
CREATE INDEX idx_user_accounts_phone ON user_accounts(phone) WHERE phone IS NOT NULL;

-- -----------------------------------------------------------------------------
-- 1.2 user_identities (用户身份凭证表)
-- -----------------------------------------------------------------------------
-- Phase 1: wechat_bindings 表重构
-- 用途: 支持多种身份提供者 (微信、手机号、邮箱等)
CREATE TABLE user_identities (
    -- 主键
    identity_id TEXT PRIMARY KEY,  -- UUID v4

    -- 外键
    user_id TEXT NOT NULL,

    -- 身份提供者信息
    provider VARCHAR(50) NOT NULL,      -- 'wechat', 'phone', 'email', 'apple', 'google'
    provider_id VARCHAR(128) NOT NULL,  -- 微信ID、手机号、邮箱等
    channel_id VARCHAR(64),             -- 子渠道 (如 wechat_main, wechat_test)
    channel_name VARCHAR(100),          -- 渠道显示名

    -- 认证数据
    auth_data TEXT,                     -- JSON 格式存储额外认证信息

    -- 绑定状态
    is_primary BOOLEAN DEFAULT FALSE,   -- 是否主身份
    bound_at TEXT NOT NULL DEFAULT (datetime('now')),
    unbound_at TEXT,                    -- 解绑时间

    -- 唯一约束: 同一provider下同一ID只能绑定一个用户
    -- 注意: SQLite 支持条件UNIQUE需要特定版本，这里用唯一索引替代

    -- 外键约束
    FOREIGN KEY (user_id) REFERENCES user_accounts(user_id) ON DELETE CASCADE
);

-- 索引
CREATE UNIQUE INDEX idx_identities_lookup ON user_identities(provider, provider_id, channel_id) WHERE unbound_at IS NULL;
CREATE INDEX idx_identities_user ON user_identities(user_id);
CREATE INDEX idx_identities_provider ON user_identities(provider, channel_id);
CREATE INDEX idx_identities_primary ON user_identities(user_id, is_primary) WHERE is_primary = TRUE;

-- -----------------------------------------------------------------------------
-- 1.3 user_profiles (用户画像表)
-- -----------------------------------------------------------------------------
-- Phase 1: 原 users 表中的投资画像字段
-- 兼容 src-2.0: user_profiles 表
CREATE TABLE user_profiles (
    -- 主键 (与用户表 1:1)
    user_id TEXT PRIMARY KEY,

    -- 问卷采集的投资画像
    investment_experience VARCHAR(20),  -- 'newbie' | 'junior' | 'intermediate' | 'expert'
    risk_profile VARCHAR(20),           -- 'conservative' | 'moderate' | 'aggressive' | 'radical'
    investment_style VARCHAR(20),       -- 'value' | 'growth' | 'dividend' | 'swing' | 'daytrade'
    focus_sectors TEXT,                 -- JSON 数组 ["technology", "finance", ...]

    -- 扩展画像 (Agent 学习积累)
    preferences TEXT,                   -- JSON 用户偏好设置
    tags TEXT,                          -- JSON 标签数组

    -- 时间戳
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),

    -- CHECK 约束
    CONSTRAINT chk_experience CHECK (investment_experience IN ('newbie', 'junior', 'intermediate', 'expert')),
    CONSTRAINT chk_risk CHECK (risk_profile IN ('conservative', 'moderate', 'aggressive', 'radical')),
    CONSTRAINT chk_style CHECK (investment_style IN ('value', 'growth', 'dividend', 'swing', 'daytrade')),

    -- 外键
    FOREIGN KEY (user_id) REFERENCES user_accounts(user_id) ON DELETE CASCADE
);

-- 索引
CREATE INDEX idx_profiles_experience ON user_profiles(investment_experience);
CREATE INDEX idx_profiles_risk ON user_profiles(risk_profile);
CREATE INDEX idx_profiles_style ON user_profiles(investment_style);

-- -----------------------------------------------------------------------------
-- 1.4 user_agents (用户-Agent绑定表)
-- -----------------------------------------------------------------------------
-- Phase 1: agents 表
-- 用途: 每个用户可以有一个专属 Client Agent
CREATE TABLE user_agents (
    -- 主键
    agent_id TEXT PRIMARY KEY,  -- UUID v4

    -- 外键 (1:1 关系)
    user_id TEXT NOT NULL UNIQUE,

    -- Agent 配置
    agent_name VARCHAR(100),            -- 默认: "StockAI_{昵称}"
    config TEXT,                        -- JSON Agent 个性化配置

    -- 运行时状态
    status VARCHAR(20) DEFAULT 'stopped',  -- 'running' | 'stopped' | 'error'
    last_active_at TEXT,

    -- 时间戳
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),

    -- CHECK 约束
    CONSTRAINT chk_agent_status CHECK (status IN ('running', 'stopped', 'error')),

    -- 外键
    FOREIGN KEY (user_id) REFERENCES user_accounts(user_id) ON DELETE CASCADE
);

-- 索引
CREATE INDEX idx_user_agents_status ON user_agents(status);
CREATE INDEX idx_user_agents_user ON user_agents(user_id);

-- -----------------------------------------------------------------------------
-- 1.5 user_sessions (用户会话状态表)
-- -----------------------------------------------------------------------------
-- Phase 1: user_sessions 表
-- 用途: 保存用户当前会话的临时状态
CREATE TABLE user_sessions (
    -- 主键
    session_id TEXT PRIMARY KEY,  -- UUID v4

    -- 外键
    user_id TEXT NOT NULL UNIQUE,  -- 1:1 关系
    agent_id TEXT,

    -- 会话状态
    context TEXT,                       -- JSON 会话上下文
    last_message_at TEXT,
    message_count INTEGER DEFAULT 0,    -- 本轮会话消息数

    -- 临时状态
    pending_action VARCHAR(50),         -- 待完成的操作 (如: 'awaiting_stock_code')
    temp_data TEXT,                     -- JSON 临时数据存储

    -- 时间戳
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),

    -- 外键
    FOREIGN KEY (user_id) REFERENCES user_accounts(user_id) ON DELETE CASCADE,
    FOREIGN KEY (agent_id) REFERENCES user_agents(agent_id) ON DELETE SET NULL
);

-- 索引
CREATE INDEX idx_sessions_agent ON user_sessions(agent_id);
CREATE INDEX idx_sessions_updated ON user_sessions(updated_at);

-- ============================================================================
-- 2. 投资相关表
-- ============================================================================

-- -----------------------------------------------------------------------------
-- 2.1 user_watchlist (自选股表)
-- -----------------------------------------------------------------------------
-- 兼容 src-2.0: user_watchlist 表
-- Phase 1: watchlists 表
CREATE TABLE user_watchlist (
    -- 主键
    watchlist_id TEXT PRIMARY KEY,  -- UUID v4

    -- 外键
    user_id TEXT NOT NULL,

    -- 股票信息
    stock_code VARCHAR(20) NOT NULL,    -- '000001.SZ', '600519.SH'
    stock_name VARCHAR(100),

    -- 用户设置
    alert_high DECIMAL(10, 4),          -- 高价预警
    alert_low DECIMAL(10, 4),           -- 低价预警
    notes TEXT,                         -- 备注

    -- 排序
    sort_order INTEGER DEFAULT 0,

    -- 时间戳
    created_at TEXT NOT NULL DEFAULT (datetime('now')),

    -- 唯一约束: 同一用户不能重复添加同一只股票
    UNIQUE(user_id, stock_code),

    -- 外键
    FOREIGN KEY (user_id) REFERENCES user_accounts(user_id) ON DELETE CASCADE
);

-- 索引
CREATE INDEX idx_watchlist_user ON user_watchlist(user_id);
CREATE INDEX idx_watchlist_stock ON user_watchlist(stock_code);
CREATE INDEX idx_watchlist_sort ON user_watchlist(user_id, sort_order);

-- -----------------------------------------------------------------------------
-- 2.2 user_holdings (持仓表)
-- -----------------------------------------------------------------------------
-- 兼容 src-2.0: user_holdings 表 (来自 user_memory.py)
-- 简化设计: 单层持仓，不区分组合
CREATE TABLE user_holdings (
    -- 主键
    holding_id TEXT PRIMARY KEY,  -- UUID v4

    -- 外键
    user_id TEXT NOT NULL,

    -- 股票信息
    stock_code VARCHAR(20) NOT NULL,    -- '000001.SZ', '600519.SH'
    stock_name VARCHAR(100),

    -- 持仓数据
    shares INTEGER NOT NULL DEFAULT 0,           -- 持仓数量
    avg_cost DECIMAL(10, 4) DEFAULT 0,           -- 平均成本
    current_price DECIMAL(10, 4),                -- 当前价格 (缓存)

    -- 收益计算 (冗余字段，便于查询)
    total_cost DECIMAL(15, 2) GENERATED ALWAYS AS (shares * avg_cost) STORED,
    market_value DECIMAL(15, 2) GENERATED ALWAYS AS (shares * current_price) STORED,
    unrealized_pnl DECIMAL(15, 2) GENERATED ALWAYS AS (shares * current_price - shares * avg_cost) STORED,

    -- 时间戳
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),

    -- 唯一约束: 同一用户同一股票只有一条持仓记录
    UNIQUE(user_id, stock_code),

    -- 外键
    FOREIGN KEY (user_id) REFERENCES user_accounts(user_id) ON DELETE CASCADE
);

-- 索引
CREATE INDEX idx_holdings_user ON user_holdings(user_id);
CREATE INDEX idx_holdings_stock ON user_holdings(stock_code);
CREATE INDEX idx_holdings_unrealized ON user_holdings(user_id, unrealized_pnl);

-- ============================================================================
-- 3. 消息与日志表
-- ============================================================================

-- -----------------------------------------------------------------------------
-- 3.1 messages (消息记录表)
-- -----------------------------------------------------------------------------
-- Phase 1: messages 表
-- 注意: 此表数据量大，建议按 created_at 分区 (PostgreSQL) 或分表 (SQLite)
CREATE TABLE messages (
    -- 主键
    message_id TEXT PRIMARY KEY,  -- UUID v4

    -- 外键
    user_id TEXT NOT NULL,
    agent_id TEXT,

    -- 消息来源
    channel_id VARCHAR(64) NOT NULL,    -- 'wechat_main', 'wechat_test', 'web'
    wechat_id VARCHAR(64),              -- 发送者微信ID

    -- 消息内容
    direction VARCHAR(10) NOT NULL,     -- 'inbound' | 'outbound'
    message_type VARCHAR(20) DEFAULT 'text',  -- 'text' | 'image' | 'file' | 'voice' | 'markdown'
    content TEXT NOT NULL,

    -- 处理状态
    processed BOOLEAN DEFAULT FALSE,
    processing_time_ms INTEGER,         -- 处理耗时

    -- 引用关系
    reply_to_message_id TEXT,           -- 回复的消息ID

    -- 元数据
    metadata TEXT,                      -- JSON 额外信息

    -- 时间戳
    created_at TEXT NOT NULL DEFAULT (datetime('now')),

    -- 外键
    FOREIGN KEY (user_id) REFERENCES user_accounts(user_id) ON DELETE CASCADE,
    FOREIGN KEY (agent_id) REFERENCES user_agents(agent_id) ON DELETE SET NULL
);

-- 索引 (针对高频查询场景)
CREATE INDEX idx_messages_user_time ON messages(user_id, created_at DESC);
CREATE INDEX idx_messages_channel_time ON messages(channel_id, created_at DESC);
CREATE INDEX idx_messages_unprocessed ON messages(processed) WHERE processed = FALSE;
CREATE INDEX idx_messages_created ON messages(created_at DESC);

-- 分区建议 (PostgreSQL):
-- CREATE TABLE messages_y2024m01 PARTITION OF messages
--     FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');

-- -----------------------------------------------------------------------------
-- 3.2 routing_log (路由日志表)
-- -----------------------------------------------------------------------------
-- Phase 1: routing_log 表
-- 用途: 记录消息路由决策过程，用于调试和优化
CREATE TABLE routing_log (
    -- 主键
    log_id TEXT PRIMARY KEY,  -- UUID v4

    -- 外键
    message_id TEXT,
    user_id TEXT NOT NULL,

    -- 路由决策信息
    routing_type VARCHAR(50) NOT NULL,   -- 'llm', 'rule', 'intent'
    source VARCHAR(50) DEFAULT 'wechat', -- 'wechat', 'web', 'system'

    -- 输入输出
    input_content TEXT,                  -- 原始输入
    intent VARCHAR(50),                  -- 识别到的意图
    confidence DECIMAL(3, 2),            -- 置信度
    target_agent_id TEXT,                -- 路由到的Agent
    target_skill VARCHAR(100),           -- 调用的技能

    -- 决策详情
    decision_data TEXT,                  -- JSON 决策过程详情

    -- 执行结果
    success BOOLEAN DEFAULT TRUE,
    error_message TEXT,
    execution_time_ms INTEGER,

    -- 时间戳
    created_at TEXT NOT NULL DEFAULT (datetime('now')),

    -- 外键
    FOREIGN KEY (user_id) REFERENCES user_accounts(user_id) ON DELETE CASCADE,
    FOREIGN KEY (message_id) REFERENCES messages(message_id) ON DELETE SET NULL
);

-- 索引
CREATE INDEX idx_routing_user ON routing_log(user_id, created_at DESC);
CREATE INDEX idx_routing_message ON routing_log(message_id);
CREATE INDEX idx_routing_intent ON routing_log(intent);
CREATE INDEX idx_routing_skill ON routing_log(target_skill);
CREATE INDEX idx_routing_success ON routing_log(success) WHERE success = FALSE;

-- ============================================================================
-- 4. 注册流程表
-- ============================================================================

-- -----------------------------------------------------------------------------
-- 4.1 onboarding_progress (问卷进度表)
-- -----------------------------------------------------------------------------
-- 兼容 src-2.0: onboarding_progress 表
-- Phase 1: onboarding_logs 表重命名
CREATE TABLE onboarding_progress (
    -- 主键
    progress_id TEXT PRIMARY KEY,  -- UUID v4

    -- 关联 (可能还没有 user_id，用微信ID标识)
    user_id TEXT,                       -- 完成后回填
    wechat_id VARCHAR(64) NOT NULL,
    channel_id VARCHAR(64) NOT NULL DEFAULT 'wechat_main',

    -- 问卷进度
    current_question INTEGER DEFAULT 0, -- 当前问题索引
    answers TEXT,                       -- JSON 所有答案

    -- 状态
    status VARCHAR(20) DEFAULT 'in_progress',  -- 'in_progress' | 'completed' | 'abandoned'

    -- 时间戳
    start_time TEXT NOT NULL DEFAULT (datetime('now')),
    complete_time TEXT,

    -- CHECK 约束
    CONSTRAINT chk_onboarding_status CHECK (status IN ('in_progress', 'completed', 'abandoned')),

    -- 外键
    FOREIGN KEY (user_id) REFERENCES user_accounts(user_id) ON DELETE SET NULL
);

-- 索引
CREATE INDEX idx_onboarding_wechat ON onboarding_progress(wechat_id, channel_id);
CREATE INDEX idx_onboarding_user ON onboarding_progress(user_id);
CREATE INDEX idx_onboarding_status ON onboarding_progress(status);

-- ============================================================================
-- 5. 长期记忆表 (Phase 1)
-- ============================================================================

-- -----------------------------------------------------------------------------
-- 5.1 user_memories (用户长期记忆表)
-- -----------------------------------------------------------------------------
-- Phase 1: memories 表
CREATE TABLE user_memories (
    -- 主键
    memory_id TEXT PRIMARY KEY,  -- UUID v4

    -- 外键
    user_id TEXT NOT NULL,

    -- 记忆分类
    memory_type VARCHAR(50) NOT NULL,   -- 'preference' | 'fact' | 'event' | 'insight'
    category VARCHAR(50),               -- 细分类别

    -- 记忆内容
    memory_key VARCHAR(200) NOT NULL,   -- 记忆键
    memory_value TEXT NOT NULL,         -- JSON 记忆值
    summary TEXT,                       -- 摘要

    -- 元数据
    source VARCHAR(50),                 -- 来源
    confidence DECIMAL(3, 2) DEFAULT 1.0,  -- 置信度 0-1

    -- 生命周期
    expires_at TEXT,                    -- 过期时间
    access_count INTEGER DEFAULT 0,     -- 访问次数
    last_accessed_at TEXT,

    -- 时间戳
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),

    -- 外键
    FOREIGN KEY (user_id) REFERENCES user_accounts(user_id) ON DELETE CASCADE
);

-- 索引
CREATE INDEX idx_memories_user ON user_memories(user_id);
CREATE INDEX idx_memories_type ON user_memories(user_id, memory_type);
CREATE INDEX idx_memories_key ON user_memories(user_id, memory_key);
CREATE INDEX idx_memories_expires ON user_memories(expires_at);

-- ============================================================================
-- 6. 技能调用记录表 (Phase 1)
-- ============================================================================

-- -----------------------------------------------------------------------------
-- 6.1 skill_usage (技能调用记录表)
-- -----------------------------------------------------------------------------
-- Phase 1: skills_usage 表
CREATE TABLE skill_usage (
    -- 主键
    usage_id TEXT PRIMARY KEY,  -- UUID v4

    -- 外键
    user_id TEXT NOT NULL,
    agent_id TEXT,
    message_id TEXT,

    -- 技能信息
    skill_name VARCHAR(100) NOT NULL,
    skill_version VARCHAR(20),

    -- 调用详情
    input_params TEXT,                  -- JSON 输入参数
    output_result TEXT,                 -- JSON 输出结果

    -- 性能
    execution_time_ms INTEGER,
    success BOOLEAN DEFAULT TRUE,
    error_message TEXT,

    -- 时间戳
    created_at TEXT NOT NULL DEFAULT (datetime('now')),

    -- 外键
    FOREIGN KEY (user_id) REFERENCES user_accounts(user_id) ON DELETE CASCADE,
    FOREIGN KEY (agent_id) REFERENCES user_agents(agent_id) ON DELETE SET NULL
);

-- 索引
CREATE INDEX idx_skill_usage_user ON skill_usage(user_id, created_at DESC);
CREATE INDEX idx_skill_usage_skill ON skill_usage(skill_name, created_at DESC);
CREATE INDEX idx_skill_usage_success ON skill_usage(success) WHERE success = FALSE;

-- ============================================================================
-- 7. 视图 (可选，便于查询)
-- ============================================================================

-- 用户完整信息视图
CREATE VIEW v_user_full_info AS
SELECT
    ua.user_id,
    ua.nickname,
    ua.email,
    ua.phone,
    ua.status as user_status,
    ua.created_at as user_created_at,
    up.investment_experience,
    up.risk_profile,
    up.investment_style,
    up.focus_sectors,
    ua_agg.agent_count,
    uw_agg.watchlist_count,
    uh_agg.holding_count,
    msg_agg.message_count
FROM user_accounts ua
LEFT JOIN user_profiles up ON ua.user_id = up.user_id
LEFT JOIN (
    SELECT user_id, COUNT(*) as agent_count
    FROM user_agents
    GROUP BY user_id
) ua_agg ON ua.user_id = ua_agg.user_id
LEFT JOIN (
    SELECT user_id, COUNT(*) as watchlist_count
    FROM user_watchlist
    GROUP BY user_id
) uw_agg ON ua.user_id = uw_agg.user_id
LEFT JOIN (
    SELECT user_id, COUNT(*) as holding_count
    FROM user_holdings
    GROUP BY user_id
) uh_agg ON ua.user_id = uh_agg.user_id
LEFT JOIN (
    SELECT user_id, COUNT(*) as message_count
    FROM messages
    WHERE created_at >= datetime('now', '-30 days')
    GROUP BY user_id
) msg_agg ON ua.user_id = msg_agg.user_id;

-- ============================================================================
-- 8. 触发器 (SQLite 自动更新时间戳)
-- ============================================================================

-- 自动更新 updated_at 触发器
CREATE TRIGGER trg_user_accounts_updated
AFTER UPDATE ON user_accounts
FOR EACH ROW
BEGIN
    UPDATE user_accounts SET updated_at = datetime('now') WHERE user_id = OLD.user_id;
END;

CREATE TRIGGER trg_user_profiles_updated
AFTER UPDATE ON user_profiles
FOR EACH ROW
BEGIN
    UPDATE user_profiles SET updated_at = datetime('now') WHERE user_id = OLD.user_id;
END;

CREATE TRIGGER trg_user_agents_updated
AFTER UPDATE ON user_agents
FOR EACH ROW
BEGIN
    UPDATE user_agents SET updated_at = datetime('now') WHERE agent_id = OLD.agent_id;
END;

CREATE TRIGGER trg_user_sessions_updated
AFTER UPDATE ON user_sessions
FOR EACH ROW
BEGIN
    UPDATE user_sessions SET updated_at = datetime('now') WHERE session_id = OLD.session_id;
END;

CREATE TRIGGER trg_user_holdings_updated
AFTER UPDATE ON user_holdings
FOR EACH ROW
BEGIN
    UPDATE user_holdings SET updated_at = datetime('now') WHERE holding_id = OLD.holding_id;
END;

CREATE TRIGGER trg_user_memories_updated
AFTER UPDATE ON user_memories
FOR EACH ROW
BEGIN
    UPDATE user_memories SET updated_at = datetime('now') WHERE memory_id = OLD.memory_id;
END;
