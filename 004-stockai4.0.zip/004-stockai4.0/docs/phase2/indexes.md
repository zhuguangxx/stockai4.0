# StockAI 2.0 数据库索引设计说明

## 设计原则

1. **读写平衡**: 消息类表侧重写性能，用户表侧重读性能
2. **复合索引优先**: 减少回表次数，提高查询效率
3. **覆盖索引**: 高频查询字段组合建索引
4. **分区键索引**: 大表按时间分区，分区键放最前

---

## 索引清单

### 1. user_accounts (用户主表)

| 索引名 | 字段 | 类型 | 说明 |
|-------|------|-----|------|
| PRIMARY KEY | user_id | UNIQUE | UUID 主键 |
| idx_user_accounts_status | status | 普通 | 按状态筛选 |
| idx_user_accounts_created | created_at | 普通 | 按注册时间排序 |
| idx_user_accounts_email | email | 部分 | 邮箱唯一 (WHERE email IS NOT NULL) |
| idx_user_accounts_phone | phone | 部分 | 手机号唯一 (WHERE phone IS NOT NULL) |

**查询场景**:
- 按 user_id 精确查找 (PRIMARY KEY)
- 按 email/phone 登录 (部分索引)
- 按注册时间排序 (created_at)
- 筛选活跃用户 (status = 'active')

---

### 2. user_identities (身份凭证表)

| 索引名 | 字段 | 类型 | 说明 |
|-------|------|-----|------|
| PRIMARY KEY | identity_id | UNIQUE | UUID 主键 |
| idx_identities_lookup | (provider, provider_id, channel_id) | 唯一条件 | 身份唯一性约束 |
| idx_identities_user | user_id | 普通 | 用户身份列表 |
| idx_identities_provider | (provider, channel_id) | 普通 | 按渠道统计 |
| idx_identities_primary | (user_id, is_primary) | 部分 | 主身份筛选 |

**查询场景**:
- 微信登录: `SELECT * FROM user_identities WHERE provider='wechat' AND provider_id=? AND channel_id=?`
- 用户身份列表: `SELECT * FROM user_identities WHERE user_id=?`
- 获取主身份: `SELECT * FROM user_identities WHERE user_id=? AND is_primary=TRUE`

---

### 3. user_profiles (用户画像表)

| 索引名 | 字段 | 类型 | 说明 |
|-------|------|-----|------|
| PRIMARY KEY | user_id | UNIQUE | 与用户表 1:1 |
| idx_profiles_experience | investment_experience | 普通 | 按投资经验分组 |
| idx_profiles_risk | risk_profile | 普通 | 按风险偏好分组 |
| idx_profiles_style | investment_style | 普通 | 按投资风格分组 |

**查询场景**:
- 筛选高风险用户: `WHERE risk_profile IN ('aggressive', 'radical')`
- 统计投资风格分布: `GROUP BY investment_style`
- 推荐系统: 相似画像用户匹配

---

### 4. user_agents (Agent绑定表)

| 索引名 | 字段 | 类型 | 说明 |
|-------|------|-----|------|
| PRIMARY KEY | agent_id | UNIQUE | UUID 主键 |
| idx_user_agents_user | user_id | 唯一 | 1:1 关系 |
| idx_user_agents_status | status | 普通 | 运行状态筛选 |

**查询场景**:
- 获取用户Agent: `SELECT * FROM user_agents WHERE user_id=?` (覆盖索引)
- 统计运行中Agent: `WHERE status='running'`

---

### 5. user_sessions (会话状态表)

| 索引名 | 字段 | 类型 | 说明 |
|-------|------|-----|------|
| PRIMARY KEY | session_id | UNIQUE | UUID 主键 |
| idx_sessions_user | user_id | 唯一 | 1:1 关系 |
| idx_sessions_agent | agent_id | 普通 | Agent会话列表 |
| idx_sessions_updated | updated_at | 普通 | 过期清理 |

**查询场景**:
- 获取用户会话: `WHERE user_id=?`
- 清理过期会话: `WHERE updated_at < DATE_SUB(NOW(), INTERVAL 7 DAY)`
- Agent会话列表: `WHERE agent_id=?`

---

### 6. user_watchlist (自选股表)

| 索引名 | 字段 | 类型 | 说明 |
|-------|------|-----|------|
| PRIMARY KEY | watchlist_id | UNIQUE | UUID 主键 |
| UNIQUE | (user_id, stock_code) | 唯一 | 不能重复添加 |
| idx_watchlist_user | user_id | 普通 | 用户自选股列表 |
| idx_watchlist_stock | stock_code | 普通 | 股票被关注统计 |
| idx_watchlist_sort | (user_id, sort_order) | 普通 | 按排序获取 |

**查询场景**:
- 获取用户自选股: `SELECT * FROM user_watchlist WHERE user_id=? ORDER BY sort_order`
- 股票热度排行: `SELECT stock_code, COUNT(*) FROM user_watchlist GROUP BY stock_code`
- 检查是否已添加: `WHERE user_id=? AND stock_code=?`

---

### 7. user_holdings (持仓表)

| 索引名 | 字段 | 类型 | 说明 |
|-------|------|-----|------|
| PRIMARY KEY | holding_id | UNIQUE | UUID 主键 |
| UNIQUE | (user_id, stock_code) | 唯一 | 每只股票一条记录 |
| idx_holdings_user | user_id | 普通 | 用户持仓列表 |
| idx_holdings_stock | stock_code | 普通 | 股票持仓统计 |
| idx_holdings_unrealized | (user_id, unrealized_pnl) | 普通 | 盈亏排序 |

**查询场景**:
- 获取用户持仓: `SELECT * FROM user_holdings WHERE user_id=?`
- 股票持仓人数: `SELECT COUNT(DISTINCT user_id) WHERE stock_code=?`
- 持仓盈亏排行: `WHERE user_id=? ORDER BY unrealized_pnl DESC`

---

### 8. messages (消息记录表) ⚠️ 大表

| 索引名 | 字段 | 类型 | 说明 |
|-------|------|-----|------|
| PRIMARY KEY | message_id | UNIQUE | UUID 主键 |
| idx_messages_user_time | (user_id, created_at DESC) | 复合 | 用户消息历史 |
| idx_messages_channel_time | (channel_id, created_at DESC) | 复合 | 渠道消息流 |
| idx_messages_unprocessed | (processed) | 部分 | 未处理消息 |
| idx_messages_created | created_at DESC | 普通 | 时间排序 |

**查询场景**:
- 用户聊天历史: `WHERE user_id=? ORDER BY created_at DESC LIMIT 50`
- 获取未处理消息: `WHERE processed=FALSE`
- 统计日活: `SELECT COUNT(DISTINCT user_id) WHERE created_at >= TODAY`

**优化建议**:
- PostgreSQL: 按 `created_at` 按月分区
- SQLite: 按年月分表 (messages_2024_01, messages_2024_02...)
- 保留最近3个月热数据，旧数据归档

---

### 9. routing_log (路由日志表)

| 索引名 | 字段 | 类型 | 说明 |
|-------|------|-----|------|
| PRIMARY KEY | log_id | UNIQUE | UUID 主键 |
| idx_routing_user | (user_id, created_at DESC) | 复合 | 用户路由历史 |
| idx_routing_message | message_id | 普通 | 消息路由详情 |
| idx_routing_intent | intent | 普通 | 意图分布分析 |
| idx_routing_skill | target_skill | 普通 | 技能调用统计 |
| idx_routing_success | (success) | 部分 | 失败日志筛选 |

**查询场景**:
- 用户路由历史: `WHERE user_id=? ORDER BY created_at DESC`
- 意图识别准确率: `WHERE intent=? AND success=TRUE`
- 技能调用频率: `GROUP BY target_skill`
- 错误日志排查: `WHERE success=FALSE`

---

### 10. onboarding_progress (问卷进度表)

| 索引名 | 字段 | 类型 | 说明 |
|-------|------|-----|------|
| PRIMARY KEY | progress_id | UNIQUE | UUID 主键 |
| idx_onboarding_wechat | (wechat_id, channel_id) | 普通 | 微信ID查询 |
| idx_onboarding_user | user_id | 普通 | 用户进度查询 |
| idx_onboarding_status | status | 普通 | 状态筛选 |

**查询场景**:
- 微信ID查进度: `WHERE wechat_id=? AND channel_id=?`
- 统计转化率: `WHERE status='completed'`
- 待跟进用户: `WHERE status='in_progress'`

---

### 11. user_memories (长期记忆表)

| 索引名 | 字段 | 类型 | 说明 |
|-------|------|-----|------|
| PRIMARY KEY | memory_id | UNIQUE | UUID 主键 |
| idx_memories_user | user_id | 普通 | 用户记忆列表 |
| idx_memories_type | (user_id, memory_type) | 复合 | 按类型筛选 |
| idx_memories_key | (user_id, memory_key) | 复合 | 记忆键查找 |
| idx_memories_expires | expires_at | 普通 | 过期清理 |

**查询场景**:
- 获取用户记忆: `WHERE user_id=?`
- 特定类型记忆: `WHERE user_id=? AND memory_type='preference'`
- 记忆键查找: `WHERE user_id=? AND memory_key=?`
- 清理过期记忆: `WHERE expires_at < NOW()`

---

### 12. skill_usage (技能调用记录表)

| 索引名 | 字段 | 类型 | 说明 |
|-------|------|-----|------|
| PRIMARY KEY | usage_id | UNIQUE | UUID 主键 |
| idx_skill_usage_user | (user_id, created_at DESC) | 复合 | 用户调用历史 |
| idx_skill_usage_skill | (skill_name, created_at DESC) | 复合 | 技能调用统计 |
| idx_skill_usage_success | (success) | 部分 | 失败记录筛选 |

**查询场景**:
- 用户技能历史: `WHERE user_id=? ORDER BY created_at DESC`
- 技能使用频率: `GROUP BY skill_name`
- 技能成功率: `WHERE skill_name=? AND success=TRUE`
- 慢查询排查: `WHERE execution_time_ms > 5000`

---

## 索引使用建议

### EXPLAIN 查询分析

```sql
-- 检查索引是否命中
EXPLAIN QUERY PLAN
SELECT * FROM messages 
WHERE user_id = 'xxx' 
ORDER BY created_at DESC 
LIMIT 50;

-- 预期输出: SEARCH messages USING INDEX idx_messages_user_time
```

### 索引维护

```sql
-- SQLite: 分析索引使用情况
SELECT * FROM sqlite_stat1;

-- PostgreSQL: 查看索引使用统计
SELECT schemaname, tablename, indexname, idx_scan, idx_tup_read
FROM pg_stat_user_indexes
WHERE schemaname = 'public'
ORDER BY idx_scan DESC;

-- 重建索引 (PostgreSQL)
REINDEX INDEX idx_messages_user_time;

-- 分析表 (更新统计信息)
ANALYZE messages;
```

### 慢查询优化

```sql
-- 查找慢查询 (PostgreSQL)
SELECT query, mean_exec_time, calls
FROM pg_stat_statements
ORDER BY mean_exec_time DESC
LIMIT 10;

-- 常见优化
-- 1. 确保 JOIN 字段有索引
-- 2. 避免 SELECT *，使用覆盖索引
-- 3. 大表查询加时间范围限制
-- 4. 考虑分区表
```

---

## 性能基准

| 表名 | 预估行数 | 查询 QPS | 索引策略 |
|-----|---------|---------|---------|
| user_accounts | 10万 | 1000 | 主键 + 唯一索引 |
| user_identities | 15万 | 500 | 复合唯一索引 |
| user_watchlist | 50万 | 500 | 复合索引 |
| user_holdings | 30万 | 300 | 复合索引 |
| messages | 1000万+/月 | 2000 | 分区 + 复合索引 |
| routing_log | 500万/月 | 100 | 时间索引 + 部分索引 |
| skill_usage | 200万/月 | 50 | 复合索引 |

---

## 存储优化

### 表分区建议

```sql
-- PostgreSQL 分区示例 (messages表)
CREATE TABLE messages (
    message_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,
    -- ... 其他字段
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
) PARTITION BY RANGE (created_at);

-- 按月分区
CREATE TABLE messages_y2024m01 PARTITION OF messages
    FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');

CREATE TABLE messages_y2024m02 PARTITION OF messages
    FOR VALUES FROM ('2024-02-01') TO ('2024-03-01');
```

### 归档策略

```sql
-- 归档3个月前数据
INSERT INTO messages_archive
SELECT * FROM messages 
WHERE created_at < DATE_TRUNC('month', NOW() - INTERVAL '3 months');

-- 删除已归档数据
DELETE FROM messages 
WHERE created_at < DATE_TRUNC('month', NOW() - INTERVAL '3 months');

-- 保留最近3个月热数据
```
