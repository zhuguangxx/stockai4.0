# StockAI 2.0 Phase 2 数据库设计 - 验收文档

## 交付清单

| 文件 | 路径 | 状态 |
|-----|------|------|
| 完整建表 SQL | `/root/.openclaw/workspace/003-new-stockai/design-validation/phase2/schema.sql` | ✅ 已交付 |
| 迁移说明 | `/root/.openclaw/workspace/003-new-stockai/design-validation/phase2/migrations.md` | ✅ 已交付 |
| 索引设计说明 | `/root/.openclaw/workspace/003-new-stockai/design-validation/phase2/indexes.md` | ✅ 已交付 |

---

## 设计概览

### 表清单 (共 13 张表)

| 表名 | 说明 | Phase 1 对应 | src-2.0 兼容 |
|------|------|-------------|-------------|
| `user_accounts` | 用户账号主表 | users | ✅ user_accounts |
| `user_identities` | 身份凭证表 | wechat_bindings | ✅ 重构扩展 |
| `user_profiles` | 用户画像 | users 拆分 | ✅ user_profiles |
| `user_agents` | Agent绑定 | agents | ❌ 新增 |
| `user_sessions` | 会话状态 | user_sessions | ❌ 新增 |
| `user_watchlist` | 自选股 | watchlists | ✅ user_watchlist |
| `user_holdings` | 持仓 | portfolio_holdings | ✅ user_holdings |
| `messages` | 消息记录 | messages | ❌ 新增 |
| `routing_log` | 路由日志 | routing_log | ❌ 新增 |
| `onboarding_progress` | 问卷进度 | onboarding_logs | ✅ onboarding_progress |
| `user_memories` | 长期记忆 | memories | ❌ 新增 |
| `skill_usage` | 技能调用 | skills_usage | ❌ 新增 |

---

## 关键设计决策

### 1. 主键策略: UUID

**决策**: 所有表使用 TEXT 类型的 UUID (兼容 SQLite/PostgreSQL)

```sql
-- SQLite
user_id TEXT PRIMARY KEY

-- PostgreSQL 可改为
user_id UUID PRIMARY KEY DEFAULT gen_random_uuid()
```

**理由**:
- ✅ 分布式系统友好，无需中央ID生成器
- ✅ 合并数据时不会冲突
- ✅ 支持离线生成
- ⚠️ 索引稍大，但现代数据库优化良好

**替代方案对比**:
| 策略 | 优点 | 缺点 | 适用场景 |
|-----|------|------|---------|
| 自增ID | 紧凑、有序 | 分布式冲突、需DB生成 | 单机、无需分片 |
| UUID | 分布式、离线生成 | 较大、无序 | ✅ 微服务、分片 |
| 雪花ID | 有序、分布式 | 需时钟同步 | 高并发、时序要求 |

---

### 2. 外键关系: 启用级联删除

| 父子关系 | 删除行为 | 理由 |
|---------|---------|------|
| user_accounts → user_identities | CASCADE | 用户删除，身份同步清理 |
| user_accounts → user_profiles | CASCADE | 用户删除，画像同步清理 |
| user_accounts → user_agents | CASCADE | 用户删除，Agent同步清理 |
| user_accounts → user_sessions | CASCADE | 用户删除，会话同步清理 |
| user_accounts → user_watchlist | CASCADE | 用户删除，自选同步清理 |
| user_accounts → user_holdings | CASCADE | 用户删除，持仓同步清理 |
| user_accounts → messages | CASCADE | 用户删除，消息同步清理 |
| user_accounts → routing_log | CASCADE | 用户删除，日志同步清理 |
| user_agents → user_sessions | SET NULL | Agent删除，会话保留可重新绑定 |
| user_agents → messages | SET NULL | Agent删除，消息保留历史 |

**循环依赖检查**: ✅ 无循环依赖

---

### 3. 索引设计策略

**高频查询场景覆盖**:
1. **用户登录**: `user_identities(provider, provider_id, channel_id)` 唯一索引
2. **消息历史**: `messages(user_id, created_at DESC)` 复合索引
3. **自选股**: `user_watchlist(user_id, sort_order)` 复合索引
4. **路由日志**: `routing_log(user_id, created_at DESC)` 复合索引

**部分索引优化**:
```sql
-- 只索引未处理消息，减少索引大小
CREATE INDEX idx_messages_unprocessed ON messages(processed) 
WHERE processed = FALSE;

-- 只索引失败日志
CREATE INDEX idx_routing_success ON routing_log(success) 
WHERE success = FALSE;
```

---

### 4. 分区策略

**推荐分区表**:

| 表名 | 预估数据量 | 分区策略 |
|-----|-----------|---------|
| `messages` | 1000万+/月 | 按月分区 |
| `routing_log` | 500万/月 | 按月分区 |
| `skill_usage` | 200万/月 | 按月分区 |

**PostgreSQL 分区实现**:
```sql
CREATE TABLE messages (...) PARTITION BY RANGE (created_at);
CREATE TABLE messages_y2024m01 PARTITION OF messages
    FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');
```

**SQLite 分表实现**:
```sql
-- 创建月表
CREATE TABLE messages_2024_01 AS SELECT * FROM messages WHERE 1=0;
-- 应用层路由写入对应月表
```

---

## 与 Phase 1 架构一致性

| Phase 1 定义 | Phase 2 实现 | 一致性 |
|-------------|-------------|--------|
| users 表 | user_accounts + user_profiles | ✅ 拆分明细 |
| wechat_bindings 表 | user_identities | ✅ 扩展为通用身份 |
| agents 表 | user_agents | ✅ 一致 |
| messages 表 | messages | ✅ 一致 |
| user_sessions 表 | user_sessions | ✅ 一致 |
| portfolios 表 | 简化为 user_holdings | ⚠️ 单层设计 |
| portfolio_holdings 表 | 合并到 user_holdings | ⚠️ 简化 |
| watchlists 表 | user_watchlist | ✅ 一致 |
| memories 表 | user_memories | ✅ 命名调整 |
| skills_usage 表 | skill_usage | ✅ 命名调整 |
| onboarding_logs 表 | onboarding_progress | ✅ 命名调整 |

---

## 与 src-2.0 兼容性

### 完全兼容的表
- `user_accounts` - 字段扩展，数据可迁移
- `user_profiles` - 字段映射后兼容
- `user_watchlist` - 增加字段，完全兼容
- `onboarding_progress` - 字段调整，数据可迁移

### 结构变更的表
- `user_holdings` - src-2.0 支持多次加仓，2.0 合并为一条记录
  - 迁移时需要合并计算

### 新增的表
- `user_identities` - 统一身份管理
- `user_agents` - Agent绑定
- `user_sessions` - 会话状态
- `messages` - 消息记录
- `routing_log` - 路由日志
- `user_memories` - 长期记忆
- `skill_usage` - 技能调用

---

## 验证清单

### ✅ SQL 可在 SQLite/PostgreSQL 执行
- 使用标准 SQL 语法
- 避免数据库特有函数 (除触发器外)
- 提供 PostgreSQL 专用注释

### ✅ 与 Phase 1 架构设计一致
- 所有 Phase 1 实体已映射
- 关系定义准确
- 字段命名统一

### ✅ 兼容现有 src-2.0 的数据结构
- 提供完整迁移脚本
- 字段映射清晰
- 数据无损迁移方案

### ✅ 外键关系清晰，无循环依赖
- 依赖方向: user_accounts → 其他表
- 无相互引用
- 级联删除策略合理

---

## 执行 SQL 测试

```bash
# 1. 创建测试数据库
sqlite3 /tmp/test_stockai_v2.db < schema.sql

# 2. 验证表创建
sqlite3 /tmp/test_stockai_v2.db ".tables"

# 3. 验证索引
sqlite3 /tmp/test_stockai_v2.db ".indexes user_accounts"

# 4. 验证外键
sqlite3 /tmp/test_stockai_v2.db "PRAGMA foreign_key_list('user_profiles');"
```

---

## 下一步建议

1. **数据库选型**: 确定使用 SQLite (开发/单机) 或 PostgreSQL (生产/分布式)
2. **ORM 映射**: 基于 schema 创建 SQLAlchemy/Tortoise-ORM 模型
3. **迁移测试**: 在测试环境运行迁移脚本，验证数据完整性
4. **性能基准**: 建立查询性能基线，配置监控告警
