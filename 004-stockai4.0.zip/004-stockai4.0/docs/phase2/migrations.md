# StockAI 2.0 数据库迁移说明

## 概述

本文档描述从 StockAI 1.0 (src-2.0) 数据结构迁移到 2.0 新 Schema 的详细步骤。

---

## 1. 表映射关系

| src-2.0 表名 | StockAI 2.0 表名 | 变化说明 |
|-------------|-----------------|---------|
| `user_accounts` | `user_accounts` | 字段扩展，保留兼容 |
| `user_profiles` | `user_profiles` | 字段重命名，数据类型优化 |
| `user_watchlist` | `user_watchlist` | 增加字段，保留兼容 |
| `user_holdings` | `user_holdings` | 结构简化，增加计算字段 |
| `onboarding_progress` | `onboarding_progress` | 字段调整，保留兼容 |
| `kline` | `kline` | 保持不变 |
| `stock_list` | `stock_list` | 保持不变 |
| `fetch_log` | `fetch_log` | 保持不变 |
| - | `user_identities` | 新增：统一身份凭证管理 |
| - | `user_agents` | 新增：Agent绑定 |
| - | `user_sessions` | 新增：会话状态 |
| - | `messages` | 新增：消息记录 |
| - | `routing_log` | 新增：路由日志 |
| - | `user_memories` | 新增：长期记忆 |
| - | `skill_usage` | 新增：技能调用记录 |

---

## 2. 详细迁移步骤

### 2.1 user_accounts 迁移

```sql
-- 检查 src-2.0 结构
.schema user_accounts

-- 典型 src-2.0 结构:
-- CREATE TABLE user_accounts (
--     user_id TEXT PRIMARY KEY,
--     wechat_id TEXT,
--     phone TEXT,
--     email TEXT,
--     bind_time TEXT
-- );

-- 迁移 SQL
-- Step 1: 创建新表 (按 schema.sql)
-- Step 2: 迁移数据
INSERT INTO user_accounts (
    user_id, nickname, email, phone, status, created_at, updated_at
)
SELECT 
    user_id,
    COALESCE(wechat_id, '') as nickname,
    email,
    phone,
    'active' as status,
    COALESCE(bind_time, datetime('now')) as created_at,
    datetime('now') as updated_at
FROM old_user_accounts;

-- Step 3: 迁移 wechat_id 到 user_identities 表
INSERT INTO user_identities (
    identity_id, user_id, provider, provider_id, channel_id, 
    is_primary, bound_at
)
SELECT 
    lower(hex(randomblob(16))) as identity_id,
    user_id,
    'wechat' as provider,
    wechat_id as provider_id,
    'wechat_main' as channel_id,
    1 as is_primary,
    COALESCE(bind_time, datetime('now')) as bound_at
FROM old_user_accounts
WHERE wechat_id IS NOT NULL;
```

### 2.2 user_profiles 迁移

```sql
-- src-2.0 结构:
-- CREATE TABLE user_profiles (
--     user_id TEXT PRIMARY KEY,
--     name TEXT,
--     experience TEXT,
--     risk_level TEXT,
--     style TEXT,
--     focus_sectors TEXT,  -- 可能是逗号分隔字符串或JSON
--     create_time TEXT,
--     update_time TEXT
-- );

-- 字段映射:
-- experience → investment_experience
-- risk_level → risk_profile  
-- style → investment_style
-- focus_sectors → focus_sectors (JSON格式转换)

-- 迁移 SQL
INSERT INTO user_profiles (
    user_id, investment_experience, risk_profile, investment_style,
    focus_sectors, created_at, updated_at
)
SELECT 
    user_id,
    experience as investment_experience,
    risk_level as risk_profile,
    style as investment_style,
    CASE 
        WHEN focus_sectors IS NULL THEN NULL
        WHEN json_valid(focus_sectors) THEN focus_sectors
        ELSE json_array(focus_sectors)  -- 逗号分隔转为JSON数组
    END as focus_sectors,
    COALESCE(create_time, datetime('now')) as created_at,
    COALESCE(update_time, datetime('now')) as updated_at
FROM old_user_profiles;
```

**值转换映射**:

| src-2.0 experience | 2.0 investment_experience |
|-------------------|--------------------------|
| 'newbie' | 'newbie' |
| 'junior' | 'junior' |
| 'intermediate' | 'intermediate' |
| 'expert' | 'expert' |
| NULL/其他 | 'intermediate' (默认值) |

| src-2.0 risk_level | 2.0 risk_profile |
|-------------------|-----------------|
| 'conservative' | 'conservative' |
| 'moderate' | 'moderate' |
| 'aggressive' | 'aggressive' |
| 'radical' | 'radical' |
| NULL/其他 | 'moderate' (默认值) |

| src-2.0 style | 2.0 investment_style |
|--------------|---------------------|
| 'value' | 'value' |
| 'growth' | 'growth' |
| 'dividend' | 'dividend' |
| 'swing' | 'swing' |
| 'daytrade' | 'daytrade' |
| NULL/其他 | 'value' (默认值) |

### 2.3 user_watchlist 迁移

```sql
-- src-2.0 结构:
-- CREATE TABLE user_watchlist (
--     user_id TEXT,
--     stock_code TEXT,
--     stock_name TEXT,
--     add_time TEXT,
--     PRIMARY KEY (user_id, stock_code)
-- );

-- 迁移 SQL
INSERT INTO user_watchlist (
    watchlist_id, user_id, stock_code, stock_name, 
    sort_order, created_at
)
SELECT 
    lower(hex(randomblob(16))) as watchlist_id,
    user_id,
    stock_code,
    stock_name,
    ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY add_time) as sort_order,
    COALESCE(add_time, datetime('now')) as created_at
FROM old_user_watchlist;
```

### 2.4 user_holdings 迁移

```sql
-- src-2.0 结构 (来自 user_memory.py):
-- CREATE TABLE user_holdings (
--     user_id TEXT,
--     stock_code TEXT,
--     stock_name TEXT,
--     shares INTEGER,
--     avg_cost DECIMAL,
--     add_time TEXT
-- );

-- 注意: src-2.0 支持加仓逻辑 (更新持仓)
-- 2.0 简化设计: 每个用户每只股票只有一条记录

-- 迁移 SQL (需要先合并同一用户同一股票的多次记录)
INSERT INTO user_holdings (
    holding_id, user_id, stock_code, stock_name,
    shares, avg_cost, created_at, updated_at
)
SELECT 
    lower(hex(randomblob(16))) as holding_id,
    user_id,
    stock_code,
    MAX(stock_name) as stock_name,
    SUM(shares) as shares,  -- 合并多次持仓
    SUM(shares * avg_cost) / SUM(shares) as avg_cost,  -- 加权平均成本
    MIN(add_time) as created_at,
    MAX(add_time) as updated_at
FROM old_user_holdings
GROUP BY user_id, stock_code
HAVING SUM(shares) > 0;  -- 只保留有持仓的
```

### 2.5 onboarding_progress 迁移

```sql
-- src-2.0 结构:
-- CREATE TABLE onboarding_progress (
--     user_id TEXT,
--     current_question INTEGER,
--     answers TEXT,  -- JSON
--     status TEXT,
--     start_time TEXT,
--     complete_time TEXT
-- );

-- 迁移 SQL
INSERT INTO onboarding_progress (
    progress_id, user_id, wechat_id, current_question,
    answers, status, start_time, complete_time
)
SELECT 
    lower(hex(randomblob(16))) as progress_id,
    user_id,
    user_id as wechat_id,  -- 需要回填或从 user_identities 获取
    current_question,
    answers,
    status,
    COALESCE(start_time, datetime('now')) as start_time,
    complete_time
FROM old_onboarding_progress;
```

---

## 3. 数据迁移脚本 (完整)

```python
#!/usr/bin/env python3
"""
StockAI 1.0 → 2.0 数据迁移脚本
"""
import sqlite3
import json
from datetime import datetime
from typing import Optional

OLD_DB = "data/stock.db"
NEW_DB = "data/stockai_v2.db"

def migrate():
    old_conn = sqlite3.connect(OLD_DB)
    new_conn = sqlite3.connect(NEW_DB)
    
    # 1. 迁移 user_accounts
    print("Migrating user_accounts...")
    cursor = old_conn.execute("SELECT user_id, wechat_id, phone, email, bind_time FROM user_accounts")
    for row in cursor:
        user_id, wechat_id, phone, email, bind_time = row
        created_at = bind_time or datetime.now().isoformat()
        
        # 插入 user_accounts
        new_conn.execute("""
            INSERT INTO user_accounts (user_id, nickname, email, phone, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, 'active', ?, datetime('now'))
        """, (user_id, wechat_id or user_id[:8], email, phone, created_at))
        
        # 插入 user_identities
        if wechat_id:
            new_conn.execute("""
                INSERT INTO user_identities (identity_id, user_id, provider, provider_id, channel_id, is_primary, bound_at)
                VALUES (lower(hex(randomblob(16))), ?, 'wechat', ?, 'wechat_main', 1, ?)
            """, (user_id, wechat_id, created_at))
    
    # 2. 迁移 user_profiles
    print("Migrating user_profiles...")
    cursor = old_conn.execute("""
        SELECT user_id, name, experience, risk_level, style, focus_sectors, create_time, update_time
        FROM user_profiles
    """)
    for row in cursor:
        user_id, name, exp, risk, style, sectors, create_t, update_t = row
        
        # 处理 focus_sectors
        focus_sectors = None
        if sectors:
            try:
                focus_sectors = sectors if json.loads(sectors) else json.dumps(sectors.split(','))
            except:
                focus_sectors = json.dumps(sectors.split(','))
        
        new_conn.execute("""
            INSERT INTO user_profiles (user_id, investment_experience, risk_profile, investment_style, 
                                      focus_sectors, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, COALESCE(?, datetime('now')), COALESCE(?, datetime('now')))
        """, (user_id, exp or 'intermediate', risk or 'moderate', style or 'value', 
              focus_sectors, create_t, update_t))
    
    # 3. 迁移 user_watchlist
    print("Migrating user_watchlist...")
    cursor = old_conn.execute("SELECT user_id, stock_code, stock_name, add_time FROM user_watchlist")
    for idx, row in enumerate(cursor):
        user_id, stock_code, stock_name, add_time = row
        new_conn.execute("""
            INSERT INTO user_watchlist (watchlist_id, user_id, stock_code, stock_name, created_at)
            VALUES (lower(hex(randomblob(16))), ?, ?, ?, COALESCE(?, datetime('now')))
        """, (user_id, stock_code, stock_name, add_time))
    
    # 4. 迁移 user_holdings (合并)
    print("Migrating user_holdings...")
    cursor = old_conn.execute("""
        SELECT user_id, stock_code, stock_name, shares, avg_cost, add_time
        FROM user_holdings
    """)
    
    holdings_map = {}
    for row in cursor:
        user_id, stock_code, stock_name, shares, avg_cost, add_time = row
        key = (user_id, stock_code)
        if key not in holdings_map:
            holdings_map[key] = {
                'stock_name': stock_name,
                'total_cost': shares * avg_cost,
                'total_shares': shares,
                'min_time': add_time,
                'max_time': add_time
            }
        else:
            h = holdings_map[key]
            h['total_cost'] += shares * avg_cost
            h['total_shares'] += shares
            h['stock_name'] = stock_name or h['stock_name']
            h['min_time'] = min(h['min_time'], add_time) if add_time else h['min_time']
            h['max_time'] = max(h['max_time'], add_time) if add_time else h['max_time']
    
    for (user_id, stock_code), h in holdings_map.items():
        if h['total_shares'] <= 0:
            continue
        avg = h['total_cost'] / h['total_shares']
        new_conn.execute("""
            INSERT INTO user_holdings (holding_id, user_id, stock_code, stock_name, shares, avg_cost, created_at, updated_at)
            VALUES (lower(hex(randomblob(16))), ?, ?, ?, ?, ?, COALESCE(?, datetime('now')), COALESCE(?, datetime('now')))
        """, (user_id, stock_code, h['stock_name'], h['total_shares'], avg, h['min_time'], h['max_time']))
    
    # 5. 迁移 onboarding_progress
    print("Migrating onboarding_progress...")
    cursor = old_conn.execute("""
        SELECT user_id, current_question, answers, status, start_time, complete_time
        FROM onboarding_progress
    """)
    for row in cursor:
        user_id, curr_q, answers, status, start_t, complete_t = row
        new_conn.execute("""
            INSERT INTO onboarding_progress (progress_id, user_id, wechat_id, current_question, answers, status, start_time, complete_time)
            VALUES (lower(hex(randomblob(16))), ?, ?, ?, ?, ?, COALESCE(?, datetime('now')), ?)
        """, (user_id, user_id, curr_q, answers, status, start_t, complete_t))
    
    # 提交
    new_conn.commit()
    old_conn.close()
    new_conn.close()
    print("Migration complete!")

if __name__ == "__main__":
    migrate()
```

---

## 4. 回滚方案

如果迁移失败，可通过以下方式回滚：

1. **保留旧数据库**: 迁移前完整备份 `stock.db`
2. **蓝绿部署**: 新数据写入 `stockai_v2.db`，旧系统继续使用 `stock.db`
3. **双写验证**: 迁移后同时写入新旧数据库，验证一致性后再切换

---

## 5. 迁移后验证

```sql
-- 验证用户数量
SELECT COUNT(*) FROM user_accounts;
SELECT COUNT(*) FROM old_user_accounts;  -- 应该相等

-- 验证自选股数量
SELECT COUNT(*) FROM user_watchlist;
SELECT COUNT(*) FROM old_user_watchlist;

-- 验证持仓数量 (注意合并后数量可能减少)
SELECT COUNT(DISTINCT user_id || stock_code) FROM old_user_holdings;
SELECT COUNT(*) FROM user_holdings;

-- 验证外键完整性
SELECT * FROM user_identities WHERE user_id NOT IN (SELECT user_id FROM user_accounts);
SELECT * FROM user_profiles WHERE user_id NOT IN (SELECT user_id FROM user_accounts);
```
