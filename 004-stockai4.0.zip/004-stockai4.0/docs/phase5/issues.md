# Phase 5 - 问题及修复建议

## 问题清单

### 总体评估

经过完整的端到端测试，**所有核心功能均正常工作**，未发现阻塞性问题。以下是测试过程中观察到的一些轻微改进点：

---

## 问题分类

### 🔵 轻微改进 (Enhancements)

#### 1. 日志重复问题

**描述：** 用户识别日志在同一次请求中重复打印多次

**日志示例：**
```
INFO:services.user_service:New user detected: wechat_id=wxid_xxx, channel=wechat_main
INFO:services.user_service:New user detected: wechat_id=wxid_xxx, channel=wechat_main
```

**影响：** 不影响功能，但会增加日志体积

**修复建议：**
```python
# 在 main_router.py 中，缓存用户识别结果
self._identity_cache = {}  # 添加缓存

def handle_message(self, ...):
    # 使用缓存避免重复查询
    cache_key = f"{wechat_id}:{channel_id}"
    if cache_key not in self._identity_cache:
        identity = self.identity_service.identify_user(wechat_id, channel_id)
        self._identity_cache[cache_key] = identity
```

**优先级：** 低

---

#### 2. 空消息处理行为

**描述：** 空消息会触发新用户流程

**当前行为：**
```python
result = router.handle_message("wxid_empty", "wechat_main", "")
# 结果: start_onboarding
```

**建议改进：**
```python
# 在 handle_message 开头添加空消息检查
if not message or not message.strip():
    return RoutingResult(
        success=False,
        action="error",
        error_code="EMPTY_MESSAGE",
        response="请输入有效内容",
        reason="Empty message received"
    )
```

**优先级：** 低

---

#### 3. 事务支持缺失

**描述：** 用户注册过程中没有数据库事务保护

**当前代码：**
```python
def register_user(self, ...):
    # 1. 创建用户账号
    user_id = self.db.create_user_account(nickname=nickname)
    # 2. 绑定微信 - 如果失败，用户账号已创建但未回滚
    bind_result = self.identity_service.bind_wechat(...)
```

**修复建议：**
```python
def register_user(self, ...):
    try:
        with self.db.transaction() as conn:
            user_id = self.db.create_user_account(nickname=nickname, conn=conn)
            self.identity_service.bind_wechat(..., conn=conn)
            # 自动回滚
    except:
        # 事务自动回滚
```

**优先级：** 中

---

### 🟢 优化建议 (Optimizations)

#### 4. 工作空间路径可配置化

**当前实现：**
```python
class AgentService:
    CLIENTS_DIR = "/opt/new-stockai/clients"  # 硬编码
```

**建议改进：**
```python
import os

class AgentService:
    CLIENTS_DIR = os.getenv("STOCKAI_CLIENTS_DIR", "/opt/new-stockai/clients")
```

**优先级：** 低

---

#### 5. 问卷答案验证增强

**当前问题：** 单选题答案验证较弱

**建议改进：**
```python
def _process_answer(self, answer: str, question: Dict) -> Any:
    if question_type == QuestionType.SINGLE_CHOICE:
        # 增强验证
        try:
            idx = int(answer.strip()) - 1
            if 0 <= idx < len(options):
                return options[idx]["value"]
            else:
                raise ValueError(f"选项编号必须在1-{len(options)}之间")
        except ValueError as e:
            # 返回错误提示
            return {"error": str(e), "retry": True}
```

**优先级：** 低

---

### 🟡 生产准备建议

#### 6. 数据库连接池配置

**当前配置：**
```python
class DatabasePool:
    def __init__(self, db_path: str, max_connections: int = 10):
```

**生产建议：**
```python
# 根据实际负载调整
max_connections = int(os.getenv("DB_MAX_CONNECTIONS", 20))
connection_timeout = int(os.getenv("DB_TIMEOUT", 30))
```

**优先级：** 中

---

#### 7. 错误监控和告警

**当前实现：** 仅打印日志

**生产建议：**
```python
import sentry_sdk  # 或类似服务

sentry_sdk.init(
    dsn=os.getenv("SENTRY_DSN"),
    traces_sample_rate=0.1,
)

# 在异常处理中
try:
    ...
except Exception as e:
    sentry_sdk.capture_exception(e)
    logger.error(f"Error: {e}")
```

**优先级：** 中

---

#### 8. API限流保护

**建议添加：** 针对 Webhook 接口的限流

```python
from functools import wraps
import time

class RateLimiter:
    def __init__(self, max_requests=100, window=60):
        self.max_requests = max_requests
        self.window = window
        self.requests = {}
    
    def is_allowed(self, key):
        now = time.time()
        if key not in self.requests:
            self.requests[key] = []
        # 清理过期请求
        self.requests[key] = [t for t in self.requests[key] if now - t < self.window]
        # 检查限制
        if len(self.requests[key]) >= self.max_requests:
            return False
        self.requests[key].append(now)
        return True
```

**优先级：** 高（生产环境必需）

---

## 修复优先级汇总

| 优先级 | 问题 | 类型 |
|--------|------|------|
| 高 | API限流保护 | 生产必需 |
| 中 | 数据库事务支持 | 数据一致性 |
| 中 | 错误监控和告警 | 运维必需 |
| 中 | 连接池配置化 | 性能优化 |
| 低 | 日志重复问题 | 日志优化 |
| 低 | 空消息处理 | 体验优化 |
| 低 | 工作空间配置化 | 部署优化 |
| 低 | 答案验证增强 | 体验优化 |

---

## 结论

**系统核心功能完整，无阻塞性问题。上述建议均为优化项，不影响系统可用性。**

建议按优先级逐步实施改进，特别是生产部署前必须完成高优先级项。
