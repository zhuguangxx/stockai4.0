# StockAI 4.0 设计验证总结（统一 Main Agent）

## 1. 设计完成状态

| 阶段 | 文档 | 状态 | 关键决策 |
|------|------|------|---------|
| Phase 1 | architecture-v2.md | ✅ | 统一 Main Agent，静态配置 |
| Phase 2 | database-v2.md | ✅ | 5张表（从12张简化） |
| Phase 3 | 接口设计 | ⏳ | 待完成 |
| Phase 4 | 代码实现 | ⏳ | 待完成 |
| Phase 5 | 测试验证 | ⏳ | 待完成 |

## 2. 核心架构决策

### 2.1 统一 Main Agent 方案

```
003 方案（Multi-Agent）                    004 方案（Unified Main）
─────────────────────────────────          ─────────────────────────────────
微信用户A ──▶ Main Agent                   微信用户A ──▶ Main Agent
                  │                                     │
                  ▼                                     ▼
          sessions_send                          直接处理（加载上下文）
                  │                                     │
                  ▼                                     ▼
          Client Agent A                           Sub-Agent (spawn)
          （独立Agent，绑定微信）                    （临时计算，无绑定）
```

### 2.2 与 OpenClaw 官方文档对照

| 官方文档 | 核心原则 | 4.0 应用 |
|---------|---------|---------|
| `concepts/multi-agent.md` | 静态配置优于动态配置 | ✅ 单一 Main Agent，bindings 静态 |
| `channels/channel-routing.md` | channel match 路由 | ✅ 所有 weixin → Main |
| `tools/subagents.md` | sessions_spawn 计算 | ✅ 深度分析用 spawn |
| `concepts/agent.md` | Agent 独立状态 | ✅ Main 统一状态管理 |

### 2.3 数据模型简化

```
003: 12 张表                    004: 5 张表
├─ users                        ├─ users
├─ user_agents ❌ 删除          ├─ onboarding_progress
├─ channel_bindings ❌ 删除     ├─ user_profiles
├─ agent_registry ❌ 删除       ├─ watchlists
├─ agent_sessions ❌ 删除       ├─ positions
├─ conversation_routing ❌ 删除 ├─ query_history
└─ ... 其他 ❌ 删除

简化: 58% 表数量减少
```

## 3. 关键设计决策

### 3.1 为什么不用 Client Agent？

| 问题 | Client Agent 方案 | 统一 Main 方案 |
|------|------------------|---------------|
| 微信绑定 | 每个用户需扫码绑定 Client | 只需绑定 Main 一次 |
| Gateway reload | 频繁（动态创建 Agent） | 永不（静态配置） |
| 配置复杂度 | 高（N+1 个 bindings） | 低（1 个 binding） |
| 官方支持 | 需动态修改 openclaw.json | 完全静态，官方推荐 |

### 3.2 用户隔离如何保障？

```
进程级隔离（003）              逻辑级隔离（004）
───────────────────           ───────────────────
Client A 进程                  Main Agent 进程
├── 只能访问 A 的数据          ├── 可访问所有数据
└── 天然隔离                   └── 代码层过滤（user_id）

安全性：代码必须严格检查 user_id
SELECT * FROM watchlists WHERE user_id = ?  -- ✅ 正确
SELECT * FROM watchlists                     -- ❌ 危险
```

### 3.3 复杂计算怎么办？

```
用户请求深度分析
        ↓
Main Agent 识别为复杂请求
        ↓
sessions_spawn(
    task="深度研究...",
    runtime="subagent",
    timeout=120
)
        ↓
临时 Sub-Agent 执行计算
        ↓
返回结果给 Main Agent
        ↓
回复用户

特点：
- Sub-Agent 无微信绑定
- 纯计算，用完即销毁
- 符合官方工具规范
```

## 4. 配置文件对比

### 4.1 003 配置（动态）

```json
{
  "agents": {
    "list": [
      { "id": "main", ... },
      { "id": "client-001", ... },  // 动态添加
      { "id": "client-002", ... },  // 动态添加
      ...
    ]
  },
  "bindings": [
    { "agentId": "main", "match": { "channel": "weixin" } },
    { "agentId": "client-001", "match": { "channel": "weixin", "accountId": "user1" } },
    ...  // 动态添加
  ]
}
```

### 4.2 004 配置（静态）

```json
{
  "agents": {
    "list": [
      { "id": "main", "workspace": "...", "default": true }
    ]
  },
  "bindings": [
    { 
      "agentId": "main", 
      "match": { "channel": "openclaw-weixin" }
    }
  ]
}
```

**简化程度**: 配置量减少 90%+

## 5. 数据流对比

### 5.1 003 数据流

```
微信消息
    ↓
Main Agent
    ↓
1. 识别用户
2. 查询绑定哪个 Client Agent
3. sessions_send 转发
    ↓
Client Agent
    ↓
处理消息
    ↓
回复（直接发送）
```

### 5.2 004 数据流

```
微信消息
    ↓
Main Agent
    ↓
1. 识别用户（open_id → user_id）
2. 加载用户上下文
3. 处理消息（Main 内部完成）
4. 简单查询：直接回复
5. 复杂查询：spawn Sub-Agent
    ↓
回复用户
```

**差异**: 004 少了一层转发，所有处理在 Main 内完成。

## 6. 待完成工作

### Phase 3: 接口设计

- [ ] Identity Service 接口
- [ ] Context Loader 接口
- [ ] Router 接口
- [ ] Sub-Agent Dispatcher 接口
- [ ] 与官方工具接口对照

### Phase 4: 代码实现

- [ ] 数据库初始化
- [ ] Identity Service 实现
- [ ] Context Loader 实现
- [ ] Router 实现
- [ ] 业务处理器实现
- [ ] Sub-Agent 调用封装

### Phase 5: 测试验证

- [ ] 新用户注册流程
- [ ] 问卷流程
- [ ] 股票分析（简单）
- [ ] 股票分析（深度，spawn）
- [ ] 持仓管理
- [ ] 并发测试

## 7. 风险与缓解

| 风险 | 等级 | 缓解措施 |
|------|------|---------|
| 用户数据隔离漏洞 | P0 | 代码审查，所有查询强制 user_id 过滤 |
| 投资建议合规 | P0 | 免责声明，内容过滤 |
| Main Agent 负载过高 | P1 | 监控，必要时优化或拆分 |
| Sub-Agent 超时 | P2 | 超时处理，降级策略 |

## 8. 下一步行动

1. **Phase 3**: 完成接口设计文档
2. **Phase 4**: 实现核心代码
3. **Phase 5**: 全流程测试
4. **部署**: 在 R720 部署验证

## 9. 参考文档

- OpenClaw 官方: https://docs.openclaw.ai
- Multi-Agent: `concepts/multi-agent.md`
- Channel Routing: `channels/channel-routing.md`
- Sub-Agents: `tools/subagents.md`

---

**当前状态**: Phase 1-2 完成，等待继续 Phase 3-5。
