# StockAI 4.0 架构设计（统一 Main Agent 方案）

> 基于 OpenClaw 官方文档设计，所有微信绑定到单一 Main Agent

## 1. 官方架构基础

### 1.1 OpenClaw 核心概念（来自官方文档）

```
Agent: 独立的工作空间 + 会话存储 + 人格配置
├── Workspace: 文件、SOUL.md、AGENTS.md、USER.md
├── AgentDir: 认证配置、模型注册表
└── Sessions: 聊天历史、路由状态

Gateway: 消息路由中枢
├── 接收所有渠道消息
├── 根据 bindings 配置路由到 Agent
└── 支持单 Agent 或多 Agent 模式

Bindings: 路由规则
├── channel: 渠道类型 (weixin/telegram/discord...)
├── accountId: 账号实例
└── agentId: 目标 Agent
```

### 1.2 官方推荐模式

根据 `docs.openclaw.ai/concepts/multi-agent.md`：

```json
{
  "agents": {
    "list": [
      { "id": "main", "workspace": "...", "default": true }
    ]
  },
  "bindings": [
    { "agentId": "main", "match": { "channel": "weixin" } }
  ]
}
```

**关键原则**：静态配置优于动态配置，避免频繁 Gateway reload。

## 2. StockAI 4.0 架构设计

### 2.1 核心设计决策

| 决策项 | 3.0 方案 | 4.0 方案（统一Main） | 理由 |
|--------|---------|---------------------|------|
| Agent 数量 | N+1 (Main + N个Client) | 1 (仅Main) | 简化，避免动态创建 |
| 微信绑定 | 每个用户绑定Client | 所有用户绑定Main | 一次绑定，永不reload |
| 用户识别 | agentId | open_id + 数据库 | 官方支持，稳定 |
| 用户隔离 | 进程级 | 上下文级 | 足够安全，性能更好 |
| 复杂计算 | Client Agent处理 | sessions_spawn Sub-Agent | 官方工具，临时进程 |

### 2.2 系统架构图

```
┌─────────────────────────────────────────────────────────────────┐
│                      微信服务端（官方）                           │
│              （个人微信 / 企业微信 / 多个微信号）                    │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    OpenClaw Gateway                             │
│                    ┌─────────────┐                              │
│                    │  消息接收层  │                              │
│                    │  - 所有微信  │                              │
│                    │  - 提取元数据 │                              │
│                    └──────┬──────┘                              │
│                           │                                     │
│                    ┌──────▼──────┐                              │
│                    │  路由决策层  │                              │
│                    │  - bindings │                              │
│                    │  - channel  │  weixin                      │
│                    │  - account  │  * (所有账号)                 │
│                    └──────┬──────┘                              │
│                           │                                     │
│                    ┌──────▼──────┐                              │
│                    │   Main Agent │  ← 唯一Agent，静态配置       │
│                    │   (agent:main)│                              │
│                    └─────────────┘                              │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Main Agent 内部架构                          │
│                                                                  │
│  ┌───────────────┐    ┌───────────────┐    ┌───────────────┐   │
│  │  Identity层   │    │   Router层    │    │  Context层    │   │
│  │  身份识别服务  │───▶│   消息路由    │───▶│  用户上下文   │   │
│  │               │    │               │    │   加载服务     │   │
│  │ - 提取open_id │    │ - 新用户检测  │    │               │   │
│  │ - 查询数据库  │    │ - 问卷路由    │    │ - 用户画像    │   │
│  │ - 返回状态    │    │ - 指令解析    │    │ - 自选股      │   │
│  └───────────────┘    └───────┬───────┘    │ - 持仓        │   │
│                               │            └───────┬───────┘   │
│                               │                    │           │
│                    ┌──────────┴──────────┐        │           │
│                    ▼                     ▼        │           │
│              ┌─────────┐          ┌──────────┐   │           │
│              │ 新用户   │          │  老用户   │◀──┘           │
│              │ Onboard │          │ 业务处理  │               │
│              │ 问卷6问 │          └────┬─────┘               │
│              └────┬────┘               │                     │
│                   │                    ▼                     │
│              完成后标记active    ┌──────────────┐            │
│                                   │ 业务处理器  │            │
│                                   │ - 股票分析  │            │
│                                   │ - 自选管理  │            │
│                                   │ - 持仓记录  │            │
│                                   └──────┬─────┘            │
│                                          │                  │
│                    ┌─────────────────────┼─────────────┐    │
│                    ▼                     ▼             ▼    │
│              ┌─────────┐        ┌──────────┐   ┌──────────┐ │
│              │ 简单查询 │        │ 深度研究  │   │ 策略回测  │ │
│              │ Main处理│        │ Sub-Agent│   │ Sub-Agent│ │
│              └─────────┘        └──────────┘   └──────────┘ │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 2.3 与官方文档的对照

#### 对照 1: Agent 配置

```
官方文档推荐:
{
  "agents": {
    "list": [
      { "id": "main", "workspace": "~/.openclaw/workspace", "default": true }
    ]
  }
}

4.0 配置:
{
  "agents": {
    "list": [
      { 
        "id": "main", 
        "workspace": "~/.openclaw/workspace",
        "default": true,
        "model": "kimi-coding/k2p5"
      }
    ]
  }
}
✅ 完全符合
```

#### 对照 2: Bindings 配置

```
官方文档示例:
{
  "bindings": [
    { 
      "agentId": "support", 
      "match": { "channel": "slack", "teamId": "T123" } 
    },
    { 
      "agentId": "main", 
      "match": { "channel": "telegram" } 
    }
  ]
}

4.0 配置:
{
  "bindings": [
    { 
      "agentId": "main", 
      "match": { "channel": "openclaw-weixin" }
      // 所有微信消息都路由到 main
    }
  ]
}
✅ 完全符合（使用 channel match）
```

#### 对照 3: Sub-Agent 调用

```
官方 sessions_spawn 接口:
sessions_spawn(
  task: str,              # 任务描述
  runtime: "subagent",    # 运行时类型
  agentId?: string,       # 可选，指定Agent类型
  timeout?: number        # 超时时间
) -> str                  # 返回结果

4.0 使用:
# 深度研究
result = sessions_spawn(
    task=f"深度研究 {stock_code}...",
    runtime="subagent",
    timeout=120
)

# 策略回测
result = sessions_spawn(
    task=f"回测策略...",
    runtime="subagent",
    timeout=300
)
✅ 完全符合官方接口
```

### 2.4 多微信频道处理

根据官方 Channel Routing 文档，`match` 支持多种模式：

```json
{
  "bindings": [
    // 方案A: 所有微信绑定到同一个Main Agent（推荐）
    {
      "agentId": "main",
      "match": { "channel": "openclaw-weixin" }
    }
    
    // 方案B: 区分主号/测试号（如需）
    {
      "agentId": "main",
      "match": { 
        "channel": "openclaw-weixin",
        "accountId": "wechat-main"
      }
    },
    {
      "agentId": "main-test",
      "match": { 
        "channel": "openclaw-weixin",
        "accountId": "wechat-test"
      }
    }
  ]
}
```

**4.0 选择方案A**：所有微信统一路由到 Main Agent，内部通过 `open_id` 区分用户。

### 2.5 数据流设计

```
用户A（微信ID: ou_aaa）发送消息:
    ↓
OpenClaw Gateway 接收
    - channel: openclaw-weixin
    - sender_id: ou_aaa
    - content: "000001"
    ↓
Binding 匹配: channel=weixin → agentId=main
    ↓
Main Agent 收到消息
    ↓
Identity Service 处理:
    1. 提取 open_id = "ou_aaa"
    2. 查询 users 表: SELECT * FROM users WHERE open_id='ou_aaa'
    3. 返回: user_id='user_xxx', status='active'
    ↓
Context Loader 加载:
    - user_profiles: 风险偏好、投资风格
    - watchlists: 自选股列表
    - positions: 持仓情况
    ↓
Router 处理消息 "000001":
    1. 识别为股票代码
    2. 调用 StockAnalyzer.analyze()
    3. 传入: stock_code='000001.SZ', risk_level='moderate'
    ↓
生成分析报告
    ↓
返回给用户A

用户B（微信ID: ou_bbb）发送消息:
    同样的流程，通过 open_id='ou_bbb' 识别不同用户
    加载用户B的上下文，互不干扰
```

### 2.6 模块职责

| 模块 | 职责 | 官方文档依据 |
|------|------|-------------|
| Main Agent | 统一入口，身份识别，消息路由 | Single-agent mode (default) |
| Identity Service | open_id → user_id 映射 | 自定义服务 |
| Context Loader | 加载用户专属上下文 | 自定义服务 |
| Router | 指令解析，业务分发 | 自定义服务 |
| Sub-Agent (spawn) | 深度计算，无状态 | sessions_spawn 工具 |

## 3. 与 003 设计的核心差异

| 维度 | 003 设计 | 004 设计（统一Main） | 差异说明 |
|------|---------|---------------------|---------|
| **Agent 数量** | 1 Main + N Client | 1 Main only | 删除 Client Agent 概念 |
| **微信绑定** | 用户扫码绑定 Client | 统一绑定 Main | 避免动态绑定 |
| **消息转发** | Main → sessions_send → Client | Main 直接处理 | 减少一层转发 |
| **用户识别** | agentId 区分 | open_id + 数据库 | 更符合官方 |
| **复杂计算** | Client Agent 处理 | sessions_spawn Sub-Agent | 临时进程，无绑定 |
| **配置稳定性** | 需动态修改 bindings | 静态配置，永不 reload | 官方推荐 |

## 4. 配置文件示例

### 4.1 openclaw.json（静态配置）

```json
{
  "meta": {
    "lastTouchedVersion": "2026.4.1"
  },
  "agents": {
    "defaults": {
      "model": "kimi-coding/k2p5",
      "contextTokens": 256000
    },
    "list": [
      {
        "id": "main",
        "name": "StockAI-Main",
        "workspace": "~/.openclaw/workspace",
        "default": true
      }
    ]
  },
  "bindings": [
    {
      "agentId": "main",
      "match": {
        "channel": "openclaw-weixin"
      }
    }
  ],
  "session": {
    "dmScope": "main"
  }
}
```

### 4.2 项目结构

```
004-stockai4.0/
├── docs/                       # 设计文档
│   ├── phase1/                 # 架构设计
│   ├── phase2/                 # 数据库设计
│   ├── phase3/                 # 接口设计
│   └── phase4/                 # 代码实现
├── src/                        # 核心源码
│   ├── __init__.py
│   ├── main.py                 # 入口
│   ├── identity_service.py     # 身份识别
│   ├── context_loader.py       # 上下文加载
│   ├── router.py               # 消息路由
│   ├── onboarding.py           # 问卷系统
│   ├── user_memory.py          # 用户数据
│   ├── stock_analyzer.py       # 股票分析
│   └── subagent_dispatcher.py  # Sub-Agent调度
├── config/
│   └── settings.py             # 配置
├── data/                       # 数据库
│   └── stockai.db
├── tests/                      # 测试
└── README.md
```

## 5. 官方文档引用

| 概念 | 官方文档 | 4.0 应用 |
|------|---------|---------|
| Agent 定义 | `concepts/agent.md` | Main Agent 唯一 |
| Multi-Agent | `concepts/multi-agent.md` | 不使用多 Agent |
| Channel Routing | `channels/channel-routing.md` | channel match |
| sessions_spawn | `tools/subagents.md` | 复杂计算 |
| Bindings | `concepts/multi-agent.md` | 静态配置 |

## 6. 下一步

1. **Phase 2**: 数据库设计（基于统一 Main 架构）
2. **Phase 3**: 接口设计
3. **Phase 4**: 代码实现
4. **Phase 5**: 全流程测试
