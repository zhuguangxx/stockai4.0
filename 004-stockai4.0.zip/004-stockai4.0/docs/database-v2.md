# StockAI 4.0 数据库设计（统一 Main Agent 方案）

> 基于统一 Main Agent 架构，简化数据模型

## 1. 设计原则

### 1.1 与 003 的核心差异

| 维度 | 003 设计 | 004 设计（统一Main） | 变化 |
|------|---------|---------------------|------|
| 用户标识 | user_id (UUID) | user_id (UUID) | 不变 |
| Agent 绑定 | user_agents 表绑定 Client Agent | 无绑定表 | 删除 |
| 微信标识 | wechat_id 多对一映射 | open_id 一对一 | 简化 |
| 频道管理 | channel_bindings 表 | 无需单独表 | 删除 |

### 1.2 简化后的表结构

```
003 表数量: 12 张
004 表数量: 5 张（减少 58%）

删除的表:
- user_agents (Agent 绑定，不需要)
- channel_bindings (频道管理，不需要)
- agent_registry (Agent 注册，不需要)
- agent_sessions (Agent 会话，不需要)
- conversation_routing (路由表，不需要)
- message_queue (消息队列，不需要)
- webhook_logs (日志，可合并)
```

## 2. 数据库 Schema

### 2.1 核心表清单

| 表名 | 用途 | 记录数预估 |
|------|------|-----------|
| users | 用户主表 | 100-1000 |
| user_profiles | 用户画像 | 100-1000 |
| watchlists | 自选股 | 1000-5000 |
| positions | 持仓记录 | 500-2000 |
| query_history | 查询历史 | 10000+ |

### 2.2 建表 SQL

```sql
-- ===========================================
-- 1. 用户主表 (users)
-- ===========================================
CREATE TABLE users (
    user_id TEXT PRIMARY KEY,           -- UUID v4，内部唯一标识
    open_id TEXT UNIQUE NOT NULL,       -- 微信 open_id，外部标识
    name TEXT DEFAULT '用户',            -- 用户称呼
    status TEXT DEFAULT 'new',          -- new/onboarding/active
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active TIMESTAMP,
    
    -- 约束
    CHECK (status IN ('new', 'onboarding', 'active', 'inactive'))
);

CREATE INDEX idx_users_open_id ON users(open_id);
CREATE INDEX idx_users_status ON users(status);

-- ===========================================
-- 2. 问卷进度表 (onboarding_progress)
-- ===========================================
CREATE TABLE onboarding_progress (
    open_id TEXT PRIMARY KEY,           -- 与 users.open_id 关联
    current_question INTEGER DEFAULT 0, -- 当前问题序号 (0-6)
    answers TEXT,                       -- JSON 格式答案
    status TEXT DEFAULT 'in_progress',  -- in_progress/completed
    start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    complete_time TIMESTAMP,
    
    -- 约束
    CHECK (current_question BETWEEN 0 AND 6),
    CHECK (status IN ('in_progress', 'completed'))
);

-- ===========================================
-- 3. 用户画像表 (user_profiles)
-- ===========================================
CREATE TABLE user_profiles (
    user_id TEXT PRIMARY KEY,           -- 与 users.user_id 关联
    name TEXT DEFAULT '用户',
    experience TEXT,                    -- newbie/junior/intermediate/expert
    risk_level TEXT,                    -- conservative/moderate/aggressive/radical
    style TEXT,                         -- value/growth/dividend/swing/daytrade
    focus_sectors TEXT,                 -- JSON 数组 ["tech", "finance", ...]
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- 约束
    CHECK (experience IN ('newbie', 'junior', 'intermediate', 'expert')),
    CHECK (risk_level IN ('conservative', 'moderate', 'aggressive', 'radical')),
    CHECK (style IN ('value', 'growth', 'dividend', 'swing', 'daytrade')),
    
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ===========================================
-- 4. 自选股表 (watchlists)
-- ===========================================
CREATE TABLE watchlists (
    user_id TEXT,
    stock_code TEXT,                    -- 如: 000001.SZ
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    PRIMARY KEY (user_id, stock_code),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE INDEX idx_watchlists_user ON watchlists(user_id);

-- ===========================================
-- 5. 持仓表 (positions)
-- ===========================================
CREATE TABLE positions (
    user_id TEXT,
    stock_code TEXT,
    shares REAL DEFAULT 0,              -- 持仓股数
    avg_cost REAL DEFAULT 0,            -- 平均成本
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    PRIMARY KEY (user_id, stock_code),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    
    -- 约束
    CHECK (shares >= 0),
    CHECK (avg_cost >= 0)
);

CREATE INDEX idx_positions_user ON positions(user_id);

-- ===========================================
-- 6. 查询历史表 (query_history)
-- ===========================================
CREATE TABLE query_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    stock_code TEXT,
    query_type TEXT DEFAULT 'analysis', -- analysis/research/compare
    result_summary TEXT,                -- 结果摘要
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE INDEX idx_query_history_user ON query_history(user_id);
CREATE INDEX idx_query_history_time ON query_history(created_at);
```

## 3. ER 图

```
┌─────────────┐       ┌─────────────────────┐
│    users    │◀──────┤ onboarding_progress │
│─────────────│  1:1  │─────────────────────│
│ user_id(PK) │       │ open_id(PK/FK)      │
│ open_id(UK) │       │ current_question    │
│ name        │       │ answers(JSON)       │
│ status      │       │ status              │
│ created_at  │       └─────────────────────┘
│ last_active │
└──────┬──────┘
       │
       │ 1:N
       ▼
┌─────────────────────┐
│    user_profiles    │
│─────────────────────│
│ user_id(PK/FK)      │
│ name                │
│ experience          │
│ risk_level          │
│ style               │
│ focus_sectors(JSON) │
│ updated_at          │
└─────────────────────┘
       │
       │ 1:N
       ▼
┌─────────────┐       ┌─────────────┐       ┌─────────────────┐
│  watchlists │       │  positions  │       │  query_history  │
│─────────────│       │─────────────│       │─────────────────│
│ user_id(FK) │       │ user_id(FK) │       │ id(PK)          │
│ stock_code  │       │ stock_code  │       │ user_id(FK)     │
│ added_at    │       │ shares      │       │ stock_code      │
└─────────────┘       │ avg_cost    │       │ query_type      │
                      │ updated_at  │       │ result_summary  │
                      └─────────────┘       │ created_at      │
                                            └─────────────────┘
```

## 4. 关键数据流

### 4.1 新用户注册

```sql
-- Step 1: 创建用户（新消息到达时自动创建）
INSERT INTO users (user_id, open_id, status)
VALUES ('uuid-xxx', 'ou_wechat_xxx', 'new');

-- Step 2: 初始化问卷进度
INSERT INTO onboarding_progress (open_id, current_question, answers, status)
VALUES ('ou_wechat_xxx', 0, '{}', 'in_progress');

-- Step 3: 每回答一题更新
UPDATE onboarding_progress 
SET current_question = 1, 
    answers = '{"name": "张三"}'
WHERE open_id = 'ou_wechat_xxx';

-- Step 4: 完成问卷
UPDATE onboarding_progress 
SET status = 'completed', 
    complete_time = CURRENT_TIMESTAMP
WHERE open_id = 'ou_wechat_xxx';

INSERT INTO user_profiles (user_id, name, experience, risk_level, style)
VALUES ('uuid-xxx', '张三', 'intermediate', 'moderate', 'value');

UPDATE users 
SET status = 'active', name = '张三'
WHERE open_id = 'ou_wechat_xxx';
```

### 4.2 用户查询流程

```sql
-- Main Agent 收到消息，提取 open_id = 'ou_wechat_xxx'

-- 1. 识别用户
SELECT user_id, status 
FROM users 
WHERE open_id = 'ou_wechat_xxx';
-- 返回: user_id='uuid-xxx', status='active'

-- 2. 加载上下文（并行）
SELECT * FROM user_profiles WHERE user_id = 'uuid-xxx';
SELECT stock_code FROM watchlists WHERE user_id = 'uuid-xxx';
SELECT * FROM positions WHERE user_id = 'uuid-xxx';

-- 3. 处理请求（如股票分析）
-- ... 业务逻辑 ...

-- 4. 记录查询历史
INSERT INTO query_history (user_id, stock_code, query_type, result_summary)
VALUES ('uuid-xxx', '000001.SZ', 'analysis', '综合评分: 75');

-- 5. 更新活跃时间
UPDATE users SET last_active = CURRENT_TIMESTAMP WHERE user_id = 'uuid-xxx';
```

### 4.3 持仓管理

```sql
-- 买入股票（加仓或新建）
-- 场景：用户买入 000001.SZ 1000股 @ 10.5元

-- 1. 查询现有持仓
SELECT shares, avg_cost 
FROM positions 
WHERE user_id = 'uuid-xxx' AND stock_code = '000001.SZ';

-- 2a. 如果无持仓，新建
INSERT INTO positions (user_id, stock_code, shares, avg_cost)
VALUES ('uuid-xxx', '000001.SZ', 1000, 10.5);

-- 2b. 如果有持仓，计算加权平均成本
-- 原持仓: 500股 @ 10.0元
-- 新增: 1000股 @ 10.5元
-- 新成本 = (500*10.0 + 1000*10.5) / 1500 = 10.33
UPDATE positions 
SET shares = 1500, 
    avg_cost = 10.33,
    updated_at = CURRENT_TIMESTAMP
WHERE user_id = 'uuid-xxx' AND stock_code = '000001.SZ';

-- 卖出股票（减仓或清仓）
-- 场景：用户卖出 000001.SZ 500股

-- 1. 查询持仓
SELECT shares FROM positions 
WHERE user_id = 'uuid-xxx' AND stock_code = '000001.SZ';
-- 返回: shares = 1500

-- 2a. 部分卖出
UPDATE positions 
SET shares = 1000,
    updated_at = CURRENT_TIMESTAMP
WHERE user_id = 'uuid-xxx' AND stock_code = '000001.SZ';

-- 2b. 全部卖出（删除记录）
DELETE FROM positions 
WHERE user_id = 'uuid-xxx' AND stock_code = '000001.SZ';
```

## 5. 与 003 的对比

### 5.1 删除的表

| 表名 | 003 用途 | 004 为什么不需要 |
|------|---------|-----------------|
| user_agents | 记录 user_id → agent_id 绑定 | 没有 Client Agent |
| channel_bindings | 记录 wechat_id → user_id 跨频道绑定 | 统一 Main 处理，无需跨频道 |
| agent_registry | 注册 Client Agent 元数据 | 没有动态 Agent |
| agent_sessions | 存储 Client Agent 会话状态 | 使用 sessions_spawn 临时进程 |
| conversation_routing | 消息路由规则 | Main 内部处理 |
| message_queue | 异步消息队列 | 简化设计，同步处理 |
| webhook_logs | Webhook 调用日志 | 简化日志设计 |

### 5.2 保留的表（复用 003）

| 表名 | 003 结构 | 004 变化 |
|------|---------|---------|
| users | ✅ | 无变化 |
| user_profiles | ✅ | 无变化 |
| watchlists | ✅ | 无变化 |
| positions | ✅ | 无变化 |
| query_history | ✅ | 无变化 |

## 6. 性能优化

### 6.1 索引设计

```sql
-- 高频查询场景优化

-- 1. 用户识别（每次消息都查）
CREATE INDEX idx_users_open_id ON users(open_id);  -- 已创建

-- 2. 活跃用户查询（定时任务用）
CREATE INDEX idx_users_last_active ON users(last_active) 
WHERE status = 'active';

-- 3. 查询历史（用户查看历史时用）
CREATE INDEX idx_query_history_user_time ON query_history(user_id, created_at DESC);
```

### 6.2 数据清理策略

```sql
-- 查询历史保留 90 天
DELETE FROM query_history 
WHERE created_at < datetime('now', '-90 days');

-- 非活跃用户标记（1年未登录）
UPDATE users 
SET status = 'inactive' 
WHERE last_active < datetime('now', '-365 days');
```

## 7. 备份策略

```sql
-- 每日备份（通过 cron 执行）
-- .backup 命令在 sqlite3 命令行中
.backup '/data/backup/stockai_$(date +%Y%m%d).db'
```

## 8. 验证清单

| 检查项 | 状态 |
|--------|------|
| 表数量从 12 减少到 5 | ✅ |
| 无外键循环依赖 | ✅ |
| 所有查询使用索引 | ✅ |
| 支持事务操作 | ✅ |
| 备份策略明确 | ✅ |
