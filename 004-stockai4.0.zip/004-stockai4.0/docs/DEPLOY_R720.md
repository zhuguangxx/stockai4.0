# StockAI 4.0 R720 部署指南

## 1. 环境准备

### 1.1 R720 现有资源

| 资源 | 路径 | 状态 |
|------|------|------|
| 五年股票数据库 | `/data/stockai/db/stock.db` (638M) | ✅ 已恢复 |
| 用户数据库 | `/opt/stockai4.0/data/stockai.db` | 待初始化 |
| core 模块 | `core/` | ✅ 已复制 |
| backtest 模块 | `backtest/` | ✅ 已复制 |

### 1.2 目录结构（R720）

```
/opt/stockai4.0/              # 004 部署目录
├── src/
│   ├── entry.py              # Gateway 入口
│   ├── router.py             # 消息路由
│   ├── data_access.py        # 数据访问层
│   └── services/             # 服务层
├── core/                     # 核心分析模块（从 001/003 复制）
│   ├── experts.py            # 六大专家系统
│   ├── indicators.py         # 技术指标
│   ├── analyzer.py           # 分析器
│   └── ...
├── backtest/                 # 回测模块（从 001/003 复制）
│   ├── engine.py             # 回测引擎
│   ├── portfolio_engine.py   # 组合引擎
│   └── report.py             # 报告生成
├── data/                     # 用户数据
│   └── stockai.db            # SQLite 用户库
├── config/
│   └── openclaw-r720.json    # R720 配置模板
└── scripts/
    └── init_db_r720.py       # 数据库初始化

/data/stockai/db/
└── stock.db                  # 五年股票数据（638M，只读）
```

## 2. 部署步骤

### 2.1 复制代码到 R720

```bash
# 在本地打包
cd ~/.openclaw/workspace
tar czf stockai4.tar.gz 004-stockai4.0/

# 上传到 R720
scp stockai4.tar.gz root@r720:/opt/

# 在 R720 解压
ssh root@r720
cd /opt
tar xzf stockai4.tar.gz
mv 004-stockai4.0 stockai4.0
```

### 2.2 初始化数据库

```bash
cd /opt/stockai4.0
python3 scripts/init_db_r720.py
```

### 2.3 配置 OpenClaw

```bash
# 备份原配置
cp ~/.openclaw/openclaw.json ~/.openclaw/openclaw.json.bak

# 复制新配置
cp /opt/stockai4.0/config/openclaw-r720.json ~/.openclaw/openclaw.json

# 重启 Gateway
openclaw gateway restart
```

### 2.4 验证部署

```bash
# 1. 检查 Gateway 状态
openclaw gateway status

# 2. 运行测试
cd /opt/stockai4.0
python3 tests/test_basic.py

# 3. 检查微信绑定
openclaw channels list
```

## 3. 数据源配置

### 3.1 本地五年数据库（主数据源）

```python
# src/data_access.py
STOCK_DB_PATH = "/data/stockai/db/stock.db"

# 自动使用本地数据：
# - 历史 K 线（5年，600万+条）
# - 技术指标计算
# - 选股筛选
```

### 3.2 kimi_finance（实时数据补充）

```python
# 实时行情（需接入 kimi_finance）
from kimi_finance import kimi_finance

# 获取实时价格
result = kimi_finance(
    ticker="600519.SH",
    time="2026-04-05 14:30:00",
    type="realtime_price"
)
```

## 4. 服务启动

### 4.1 Systemd 服务（可选）

```bash
# 创建服务文件
cat > /etc/systemd/system/stockai4.service <> EOF
[Unit]
Description=StockAI 4.0
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/stockai4.0
ExecStart=/usr/bin/python3 /opt/stockai4.0/src/entry.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

# 启用服务
systemctl daemon-reload
systemctl enable stockai4
systemctl start stockai4
```

## 5. 监控与维护

### 5.1 日志查看

```bash
# OpenClaw 日志
tail -f ~/.openclaw/logs/gateway.log

# 应用日志（如配置了）
tail -f /opt/stockai4.0/logs/app.log
```

### 5.2 数据库备份

```bash
# 用户数据库备份
cp /opt/stockai4.0/data/stockai.db /data/backup/stockai_$(date +%Y%m%d).db

# 股票数据库备份（已有时 Timeshift 备份）
ls /data/stock_backup_*.db
```

### 5.3 性能监控

```bash
# 查看数据库大小
du -sh /opt/stockai4.0/data/*.db
du -sh /data/stockai/db/*.db

# 查看活跃用户数
sqlite3 /opt/stockai4.0/data/stockai.db \
    "SELECT COUNT(*) FROM users WHERE status='active';"
```

## 6. 故障排查

### 6.1 数据库连接失败

```bash
# 检查文件权限
ls -la /opt/stockai4.0/data/
ls -la /data/stockai/db/

# 检查数据库完整性
sqlite3 /data/stockai/db/stock.db "PRAGMA integrity_check;"
```

### 6.2 Gateway 无法启动

```bash
# 检查配置
openclaw config validate

# 查看错误日志
tail ~/.openclaw/logs/gateway.log
```

### 6.3 微信消息无响应

```bash
# 检查微信绑定
openclaw channels status

# 检查 Agent 状态
openclaw agents list
```

## 7. 更新维护

### 7.1 代码更新

```bash
cd /opt/stockai4.0
git pull origin master  # 如果从 git 更新
# 或重新上传代码
```

### 7.2 重启服务

```bash
openclaw gateway restart
# 或
systemctl restart stockai4
```

## 8. 回滚方案

如部署失败，回滚到 003：

```bash
# 恢复 OpenClaw 配置
cp ~/.openclaw/openclaw.json.bak ~/.openclaw/openclaw.json

# 重启 Gateway
openclaw gateway restart

# 003 服务在 /data/stockai/ 保持不变
```

---

**部署完成标志**: 
- ✅ 用户数据库初始化成功
- ✅ 股票数据库连接正常
- ✅ OpenClaw Gateway 运行正常
- ✅ 微信消息能正常响应
- ✅ 测试用例全部通过
