# StockAI 2.0 错误码定义

## 目录
1. [错误码设计原则](#错误码设计原则)
2. [错误码格式](#错误码格式)
3. [错误码列表](#错误码列表)
4. [异常处理策略](#异常处理策略)
5. [错误响应示例](#错误响应示例)

---

## 错误码设计原则

1. **分层设计**: 按服务模块划分错误码前缀
2. **语义明确**: 错误码能直接反映问题类型
3. **可追踪**: 包含 request_id 便于日志追踪
4. **用户友好**: 区分内部错误和用户可处理错误

---

## 错误码格式

```
[模块前缀]_[错误类别]_[具体错误]

示例:
- IDENTITY_USER_NOT_FOUND    (Identity服务-用户相关-未找到)
- AGENT_CREATE_FAILED        (Agent服务-创建操作-失败)
- DB_CONNECTION_TIMEOUT      (数据库-连接-超时)
```

### 模块前缀

| 前缀 | 模块 | 说明 |
|------|------|------|
| `IDENTITY` | Identity Service | 用户身份服务 |
| `AGENT` | Agent Manager | Agent 管理服务 |
| `ONBOARDING` | Onboarding Service | 注册流程服务 |
| `MEMORY` | User Memory Service | 用户记忆服务 |
| `MESSAGE` | Message Service | 消息服务 |
| `ROUTING` | Routing Service | 路由服务 |
| `DB` | Database | 数据库层 |
| `VALIDATION` | Validation | 参数校验 |
| `SYSTEM` | System | 系统级错误 |
| `WEBHOOK` | Webhook | Webhook 接收 |

### 错误类别

| 类别 | 说明 | HTTP 状态码 |
|------|------|------------|
| `USER` | 用户相关错误 | 404 |
| `AUTH` | 认证授权错误 | 401/403 |
| `VALIDATION` | 参数校验错误 | 400 |
| `CREATE` | 创建操作错误 | 500 |
| `UPDATE` | 更新操作错误 | 500 |
| `DELETE` | 删除操作错误 | 500 |
| `QUERY` | 查询操作错误 | 500 |
| `CONNECTION` | 连接错误 | 503 |
| `TIMEOUT` | 超时错误 | 504 |
| `RATE_LIMIT` | 限流错误 | 429 |
| `INTERNAL` | 内部错误 | 500 |

---

## 错误码列表

### Identity Service 错误码

| 错误码 | 说明 | 用户提示 | 处理建议 |
|--------|------|---------|---------|
| `IDENTITY_USER_NOT_FOUND` | 用户不存在 | "您还未注册，请完成注册流程" | 引导至 onboarding |
| `IDENTITY_BIND_FAILED` | 绑定失败 | "账号绑定失败，请稍后重试" | 重试或联系客服 |
| `IDENTITY_UNBIND_FAILED` | 解绑失败 | "解绑操作失败" | 检查是否有其他主身份 |
| `IDENTITY_ALREADY_BOUND` | 已绑定其他用户 | "该微信已绑定其他账号" | 提示联系客服处理 |
| `IDENTITY_PROVIDER_INVALID` | 身份提供者无效 | "不支持的登录方式" | 检查 provider 参数 |
| `IDENTITY_CHANNEL_INVALID` | 渠道标识无效 | "非法请求来源" | 检查 channel_id |

### Agent Manager 错误码

| 错误码 | 说明 | 用户提示 | 处理建议 |
|--------|------|---------|---------|
| `AGENT_NOT_FOUND` | Agent 不存在 | "服务暂时不可用" | 自动创建或重启 |
| `AGENT_CREATE_FAILED` | 创建失败 | "初始化服务失败" | 检查磁盘/内存资源 |
| `AGENT_START_FAILED` | 启动失败 | "服务启动失败" | 检查配置和依赖 |
| `AGENT_STOP_FAILED` | 停止失败 | "服务停止异常" | 强制重启 |
| `AGENT_ALREADY_RUNNING` | 已在运行 | - | 无需处理 |
| `AGENT_ROUTE_TIMEOUT` | 路由超时 | "响应超时，请稍后重试" | 增加超时时间或降级 |
| `AGENT_ROUTE_FAILED` | 路由失败 | "消息发送失败" | 重试或切换到备用 |
| `AGENT_USER_LIMIT_EXCEEDED` | 用户数量超限 | "系统繁忙，请稍后" | 扩容或限流 |

### Onboarding Service 错误码

| 错误码 | 说明 | 用户提示 | 处理建议 |
|--------|------|---------|---------|
| `ONBOARDING_PROGRESS_NOT_FOUND` | 进度不存在 | "注册会话已过期" | 重新开始注册 |
| `ONBOARDING_ALREADY_COMPLETE` | 已完成 | "您已注册完成" | 直接走正常流程 |
| `ONBOARDING_ANSWER_INVALID` | 答案无效 | "请输入有效的选项" | 重新提示问题 |
| `ONBOARDING_COMPLETE_FAILED` | 完成失败 | "注册失败，请重试" | 回滚并重新开始 |
| `ONBOARDING_QUESTION_NOT_FOUND` | 问题不存在 | "问题加载失败" | 重新开始注册 |
| `ONBOARDING_EXPIRED` | 会话过期 | "注册会话已过期(30分钟)" | 重新开始 |

### User Memory Service 错误码

| 错误码 | 说明 | 用户提示 | 处理建议 |
|--------|------|---------|---------|
| `MEMORY_PROFILE_NOT_FOUND` | 画像不存在 | "用户信息加载失败" | 从 onboarding 数据重建 |
| `MEMORY_PROFILE_UPDATE_FAILED` | 更新失败 | "保存失败" | 重试 |
| `MEMORY_WATCHLIST_DUPLICATE` | 自选股重复 | "该股票已在自选列表" | 提示已存在 |
| `MEMORY_WATCHLIST_NOT_FOUND` | 自选股不存在 | "未找到该自选股" | 检查股票代码 |
| `MEMORY_WATCHLIST_LIMIT_EXCEEDED` | 超出限制 | "自选列表已满(100只)" | 提示删除后再添加 |
| `MEMORY_HOLDING_NOT_FOUND` | 持仓不存在 | "未找到该持仓" | 检查持仓记录 |
| `MEMORY_HOLDING_INVALID_DATA` | 持仓数据无效 | "持仓数据有误" | 检查 shares/avg_cost |

### Message Service 错误码

| 错误码 | 说明 | 用户提示 | 处理建议 |
|--------|------|---------|---------|
| `MESSAGE_CREATE_FAILED` | 消息保存失败 | - | 记录日志，不影响主流程 |
| `MESSAGE_NOT_FOUND` | 消息不存在 | "未找到该消息" | 检查 message_id |
| `MESSAGE_TOO_LARGE` | 消息过大 | "消息太长" | 截断或分批发送 |
| `MESSAGE_TYPE_INVALID` | 消息类型无效 | "不支持的消息类型" | 检查 message_type |

### Routing Service 错误码

| 错误码 | 说明 | 用户提示 | 处理建议 |
|--------|------|---------|---------|
| `ROUTING_INTENT_NOT_FOUND` | 未识别意图 | "我不理解您的意思" | 使用通用回复 |
| `ROUTING_CONFIDENCE_LOW` | 置信度低 | "您是想...吗？" | 请求确认 |
| `ROUTING_SKILL_NOT_FOUND` | 技能不存在 | "该功能暂时不可用" | 使用备用方案 |
| `ROUTING_CIRCUIT_OPEN` | 熔断器开启 | "服务暂时不可用" | 等待恢复或降级 |

### Database 错误码

| 错误码 | 说明 | 用户提示 | 处理建议 |
|--------|------|---------|---------|
| `DB_CONNECTION_FAILED` | 连接失败 | "服务暂时不可用" | 重试连接 |
| `DB_CONNECTION_TIMEOUT` | 连接超时 | "响应较慢，请稍后" | 增加超时时间 |
| `DB_QUERY_FAILED` | 查询失败 | "数据加载失败" | 重试或返回缓存 |
| `DB_INSERT_FAILED` | 插入失败 | "保存失败" | 重试或事务回滚 |
| `DB_UPDATE_FAILED` | 更新失败 | "更新失败" | 重试 |
| `DB_DELETE_FAILED` | 删除失败 | "删除失败" | 重试 |
| `DB_CONSTRAINT_VIOLATION` | 约束冲突 | "数据冲突" | 检查唯一约束 |
| `DB_POOL_EXHAUSTED` | 连接池耗尽 | "系统繁忙" | 等待或扩容 |

### Validation 错误码

| 错误码 | 说明 | 用户提示 | 处理建议 |
|--------|------|---------|---------|
| `VALIDATION_REQUIRED_FIELD` | 必填字段缺失 | "请填写必要信息" | 检查必填字段 |
| `VALIDATION_INVALID_FORMAT` | 格式无效 | "格式不正确" | 提示正确格式 |
| `VALIDATION_INVALID_LENGTH` | 长度无效 | "内容长度不符合要求" | 检查长度限制 |
| `VALIDATION_INVALID_RANGE` | 范围无效 | "数值超出范围" | 检查范围限制 |
| `VALIDATION_INVALID_ENUM` | 枚举值无效 | "无效的选项" | 检查枚举值 |

### System 错误码

| 错误码 | 说明 | 用户提示 | 处理建议 |
|--------|------|---------|---------|
| `SYSTEM_INTERNAL_ERROR` | 内部错误 | "系统错误" | 记录日志，告警 |
| `SYSTEM_NOT_IMPLEMENTED` | 未实现 | "功能开发中" | 返回待实现提示 |
| `SYSTEM_MAINTENANCE` | 系统维护 | "系统维护中" | 返回维护页面 |
| `SYSTEM_RATE_LIMIT` | 系统限流 | "请求过于频繁" | 提示稍后再试 |

### Webhook 错误码

| 错误码 | 说明 | 用户提示 | 处理建议 |
|--------|------|---------|---------|
| `WEBHOOK_INVALID_SIGNATURE` | 签名无效 | - | 拒绝请求 |
| `WEBHOOK_TIMESTAMP_INVALID` | 时间戳无效 | - | 拒绝请求 |
| `WEBHOOK_REPLAY_DETECTED` | 重放攻击 | - | 拒绝请求 |
| `WEBHOOK_PARSE_FAILED` | 解析失败 | - | 记录错误日志 |

---

## 异常处理策略

### 1. 重试策略

```python
RETRY_CONFIG = {
    "DB_CONNECTION_FAILED": {
        "max_retries": 3,
        "backoff_factor": 2,  # 1s, 2s, 4s
        "max_delay": 10
    },
    "AGENT_ROUTE_TIMEOUT": {
        "max_retries": 2,
        "backoff_factor": 1.5,
        "max_delay": 5
    },
    "IDENTITY_BIND_FAILED": {
        "max_retries": 3,
        "backoff_factor": 1,
        "max_delay": 3
    }
}
```

### 2. 熔断策略

```python
CIRCUIT_BREAKER_CONFIG = {
    "AGENT_ROUTE": {
        "failure_threshold": 5,      # 5次失败
        "recovery_timeout": 30,       # 30秒后尝试恢复
        "half_open_max_calls": 3      # 半开状态允许3次测试
    },
    "DB_QUERY": {
        "failure_threshold": 10,
        "recovery_timeout": 60,
        "half_open_max_calls": 5
    }
}
```

### 3. 降级策略

| 原功能 | 降级方案 | 触发条件 |
|--------|---------|---------|
| 个性化分析 | 通用市场分析 | Agent 超时 |
| 长期记忆 | 仅使用会话上下文 | Memory 服务不可用 |
| 实时数据 | 使用缓存数据 | 数据服务超时 |
| LLM 回复 | 预设模板回复 | LLM 服务不可用 |

### 4. 错误恢复流程

```
发生错误
    │
    ▼
┌─────────────────────────────────┐
│ 1. 捕获并分类错误                │
│    - 用户错误 → 直接返回提示     │
│    - 服务错误 → 进入恢复流程     │
└──────────────────┬──────────────┘
                   │
                   ▼
┌─────────────────────────────────┐
│ 2. 检查是否需要重试              │
│    - 配置中定义了重试策略?       │
│    - 重试次数未超限?             │
└──────────────────┬──────────────┘
                   │
         ┌─────────┴─────────┐
         ▼                   ▼
    [需要重试]            [不重试]
         │                   │
         ▼                   ▼
┌─────────────────┐   ┌─────────────────┐
│ 3a. 指数退避重试 │   │ 3b. 检查熔断器   │
│    等待后重试    │   │    触发熔断?     │
└────────┬────────┘   └────────┬────────┘
         │                     │
         │            ┌────────┴────────┐
         │            ▼                 ▼
         │       [熔断开启]        [熔断关闭]
         │            │                 │
         │            ▼                 ▼
         │       ┌──────────────┐  ┌──────────────┐
         │       │ 返回降级响应  │  │ 记录错误日志  │
         │       └──────────────┘  └──────────────┘
         │                              │
         └──────────────────────────────┘
                        │
                        ▼
         ┌──────────────────────────────┐
         │ 4. 通知监控/告警              │
         │    - 记录结构化日志           │
         │    - 触发告警(如需要)         │
         └──────────────────────────────┘
```

---

## 错误响应示例

### 标准错误响应格式

```json
{
    "success": false,
    "error_code": "IDENTITY_USER_NOT_FOUND",
    "error_message": "用户未注册",
    "error_details": {
        "wechat_id": "wxid_abc123",
        "channel_id": "wechat_main",
        "suggestion": "请完成注册流程"
    },
    "timestamp": "2024-04-05T12:34:56Z",
    "request_id": "req_xxx-xxx-xxx"
}
```

### 具体场景示例

#### 场景1: 新用户首次发消息

```json
{
    "success": false,
    "error_code": "IDENTITY_USER_NOT_FOUND",
    "error_message": "您还未注册 StockAI 服务",
    "error_details": {
        "wechat_id": "wxid_newuser",
        "channel_id": "wechat_main",
        "action": "start_onboarding",
        "onboarding_url": "/onboarding/start"
    },
    "timestamp": "2024-04-05T12:34:56Z",
    "request_id": "req_onboarding_001"
}
```

用户看到的回复:
```
欢迎！我是 StockAI 智能助手。

看起来您是第一次使用，我需要花 1 分钟了解您的投资偏好，以便为您提供更精准的服务。

[开始注册]
```

#### 场景2: Agent 路由超时

```json
{
    "success": false,
    "error_code": "AGENT_ROUTE_TIMEOUT",
    "error_message": "响应超时",
    "error_details": {
        "agent_id": "agt_yyy-yyy-yyy",
        "timeout_seconds": 30,
        "retryable": true
    },
    "timestamp": "2024-04-05T12:34:56Z",
    "request_id": "req_route_001"
}
```

用户看到的回复:
```
抱歉，当前响应较慢。我已经收到您的消息，正在处理中...

请稍等片刻，或通过 "查询" 查看最新结果。
```

#### 场景3: 数据库连接失败

```json
{
    "success": false,
    "error_code": "DB_CONNECTION_FAILED",
    "error_message": "数据服务暂时不可用",
    "error_details": {
        "host": "db.stockai.internal",
        "retry_count": 3,
        "fallback_enabled": true
    },
    "timestamp": "2024-04-05T12:34:56Z",
    "request_id": "req_db_001"
}
```

用户看到的回复:
```
抱歉，系统正在维护中，请稍后重试。

如问题持续，请联系客服：support@stockai.com
```

#### 场景4: 自选股重复添加

```json
{
    "success": false,
    "error_code": "MEMORY_WATCHLIST_DUPLICATE",
    "error_message": "该股票已在您的自选列表",
    "error_details": {
        "stock_code": "600519.SH",
        "stock_name": "贵州茅台",
        "watchlist_id": "wl_xxx-xxx-xxx",
        "added_at": "2024-04-01T10:00:00Z"
    },
    "timestamp": "2024-04-05T12:34:56Z",
    "request_id": "req_watchlist_001"
}
```

用户看到的回复:
```
贵州茅台(600519.SH) 已经在您的自选列表中了！

您可以发送 "查看自选" 来浏览所有关注的股票。
```

---

## 错误监控与告警

### 错误分级

| 级别 | 说明 | 响应时间 | 通知方式 |
|------|------|---------|---------|
| P0 - Critical | 系统不可用 | 立即 | 电话+短信+邮件 |
| P1 - High | 核心功能故障 | 5分钟内 | 短信+邮件 |
| P2 - Medium | 非核心功能故障 | 30分钟内 | 邮件 |
| P3 - Low | 轻微问题/优化 | 24小时内 | 邮件汇总 |

### 错误码映射到分级

| 错误码 | 分级 | 说明 |
|--------|------|------|
| `SYSTEM_INTERNAL_ERROR` | P0 | 系统内部错误 |
| `DB_CONNECTION_FAILED` | P0 | 数据库连接失败 |
| `AGENT_ROUTE_TIMEOUT` | P1 | Agent 路由超时 |
| `IDENTITY_BIND_FAILED` | P1 | 身份绑定失败 |
| `MEMORY_WATCHLIST_DUPLICATE` | P3 | 自选股重复 |
| `VALIDATION_INVALID_FORMAT` | P3 | 参数格式错误 |

### 日志记录格式

```json
{
    "level": "error",
    "timestamp": "2024-04-05T12:34:56.789Z",
    "request_id": "req_xxx-xxx-xxx",
    "error_code": "AGENT_ROUTE_TIMEOUT",
    "error_message": "Agent 路由超时",
    "service": "agent_manager",
    "method": "route_to_agent",
    "user_id": "usr_xxx-xxx-xxx",
    "context": {
        "agent_id": "agt_yyy-yyy-yyy",
        "timeout": 30,
        "elapsed": 30.5
    },
    "stack_trace": "...",
    "retry_info": {
        "attempt": 3,
        "max_retries": 3,
        "will_retry": false
    }
}
```
