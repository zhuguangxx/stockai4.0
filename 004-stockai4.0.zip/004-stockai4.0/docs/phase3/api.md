# StockAI 2.0 API 调用示例和流程说明

## 目录
1. [核心流程概览](#核心流程概览)
2. [老用户消息处理流程](#老用户消息处理流程)
3. [新用户注册流程](#新用户注册流程)
4. [接口调用示例](#接口调用示例)
5. [数据流转序列图](#数据流转序列图)

---

## 核心流程概览

```
┌─────────────┐     ┌──────────────┐     ┌─────────────────────────────────────────┐
│  微信用户    │     │  Main Agent  │     │           内部服务层                     │
│  (User)     │────▶│   Router     │────▶│  Identity → Agent Manager → Onboarding  │
└─────────────┘     └──────────────┘     └─────────────────────────────────────────┘
                                                              │
                                                              ▼
                                                    ┌──────────────────┐
                                                    │  Client Agent    │
                                                    │  (用户专属)       │
                                                    └──────────────────┘
```

### 流程分支说明

| 场景 | 触发条件 | 处理流程 |
|------|---------|---------|
| **老用户流程** | `wechat_id` 已绑定 | `identify_user` → `get_client_agent` → `route_to_agent` |
| **新用户流程** | `wechat_id` 未绑定 | `start_onboarding` → 问卷 → `complete_onboarding` → `create_client_agent` |
| **异常流程** | 服务不可用/超时 | 返回友好错误提示，记录日志 |

---

## 老用户消息处理流程

### 流程图

```
微信消息进入
    │
    ▼
┌─────────────────────────────────────────┐
│ MainAgentRouter.handle_message()        │
│ POST /webhook/wechat                    │
└──────────────────┬──────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────┐
│ IdentityService.identify_user()         │
│ 查询: wechat_id + channel_id            │
│ 返回: {exists: true, user_id, agent_id} │
└──────────────────┬──────────────────────┘
                   │
                   ▼ (用户存在)
┌─────────────────────────────────────────┐
│ AgentManager.get_client_agent()         │
│ 检查 Agent 状态                          │
└──────────────────┬──────────────────────┘
                   │
         ┌─────────┴─────────┐
         ▼                   ▼
    [状态: running]      [状态: stopped]
         │                   │
         │                   ▼
         │           start_agent()
         │                   │
         └─────────┬─────────┘
                   ▼
┌─────────────────────────────────────────┐
│ AgentManager.route_to_agent()           │
│ 转发消息到 Client Agent                  │
└──────────────────┬──────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────┐
│ Client Agent 处理消息                    │
│ 1. 加载用户记忆                         │
│ 2. 执行技能/分析                        │
│ 3. 生成回复                             │
└──────────────────┬──────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────┐
│ 返回响应给微信用户                       │
└─────────────────────────────────────────┘
```

### 完整调用链示例

```python
# 1. 接收微信消息
request = {
    "wechat_id": "wxid_abc123",
    "channel_id": "wechat_main",
    "message": "帮我看看贵州茅台的走势",
    "message_type": "text",
    "timestamp": 1712300400,
    "msg_id": "msg_123456"
}

# 2. 识别用户身份
identity_result = identity_service.identify_user(
    wechat_id="wxid_abc123",
    channel_id="wechat_main"
)
# 返回:
# {
#     "exists": True,
#     "user_id": "usr_xxx-xxx-xxx",
#     "agent_id": "agt_yyy-yyy-yyy",
#     "identity_id": "idt_zzz-zzz-zzz",
#     "status": "active",
#     "is_primary": True
# }

# 3. 获取 Client Agent 信息
agent_info = agent_manager.get_client_agent(user_id="usr_xxx-xxx-xxx")
# 返回:
# {
#     "agent_id": "agt_yyy-yyy-yyy",
#     "user_id": "usr_xxx-xxx-xxx",
#     "agent_name": "StockAI_小明",
#     "status": "running",
#     "config": {...},
#     "created_at": "2024-01-15T10:30:00Z"
# }

# 4. 检查并确保 Agent 运行中
if agent_info["status"] != "running":
    agent_manager.start_agent(agent_id="agt_yyy-yyy-yyy")

# 5. 路由消息到 Client Agent
route_result = agent_manager.route_to_agent(
    agent_id="agt_yyy-yyy-yyy",
    message="帮我看看贵州茅台的走势",
    context={
        "user_id": "usr_xxx-xxx-xxx",
        "wechat_id": "wxid_abc123",
        "channel_id": "wechat_main",
        "message_id": "msg_123456",
        "session_id": "sess_aaa-aaa-aaa",
        "timestamp": 1712300400
    }
)
# 返回:
# {
#     "status": "delivered",
#     "response": "根据最新数据，贵州茅台(600519.SH)今日...",
#     "response_type": "text",
#     "processing_time_ms": 2500
# }

# 6. 记录消息
message_service.record_message(
    user_id="usr_xxx-xxx-xxx",
    agent_id="agt_yyy-yyy-yyy",
    channel_id="wechat_main",
    wechat_id="wxid_abc123",
    direction="inbound",
    content="帮我看看贵州茅台的走势",
    message_type="text"
)

message_service.record_message(
    user_id="usr_xxx-xxx-xxx",
    agent_id="agt_yyy-yyy-yyy",
    channel_id="wechat_main",
    wechat_id="wxid_abc123",
    direction="outbound",
    content=route_result["response"],
    message_type="text",
    reply_to="msg_123456"
)

# 7. 记录路由日志
routing_log_service.log_routing_decision(
    user_id="usr_xxx-xxx-xxx",
    message_id="msg_xxx",
    routing_type="rule",
    source="wechat",
    input_content="帮我看看贵州茅台的走势",
    intent="stock_inquiry",
    confidence=0.95,
    target_agent_id="agt_yyy-yyy-yyy",
    target_skill="stock_analysis",
    decision_data={"pattern_matched": "看股票走势"},
    success=True,
    execution_time_ms=2500
)
```

---

## 新用户注册流程

### 流程图

```
微信消息进入
    │
    ▼
┌─────────────────────────────────────────┐
│ MainAgentRouter.handle_message()        │
└──────────────────┬──────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────┐
│ IdentityService.identify_user()         │
│ 返回: {exists: false}                   │
└──────────────────┬──────────────────────┘
                   │
                   ▼ (新用户)
┌─────────────────────────────────────────┐
│ OnboardingService.start_onboarding()    │
│ 创建问卷进度记录                         │
└──────────────────┬──────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────┐
│ 发送欢迎语和第一个问题                   │
└──────────────────┬──────────────────────┘
                   │
                   ▼ (用户提交答案)
┌─────────────────────────────────────────┐
│ OnboardingService.save_answer()         │
│ 保存答案，返回下一个问题                 │
└──────────────────┬──────────────────────┘
                   │
         ┌─────────┴─────────┐
         ▼                   ▼
    [还有问题]            [问卷完成]
         │                   │
         │                   ▼
         │           complete_onboarding()
         │           1. 创建 user_accounts
         │           2. 创建 user_profiles
         │           3. 绑定微信身份
         │           4. 创建 Client Agent
         │                   │
         └───────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────┐
│ 发送完成消息给用户                       │
│ "注册完成！我是您的专属 StockAI 助手..."  │
└─────────────────────────────────────────┘
```

### 完整调用链示例

```python
# ========== 第1步: 识别到新用户 ==========
identity_result = identity_service.identify_user(
    wechat_id="wxid_newuser",
    channel_id="wechat_main"
)
# 返回: {"exists": False, ...}

# ========== 第2步: 开始注册流程 ==========
onboarding_result = onboarding_service.start_onboarding(
    wechat_id="wxid_newuser",
    channel_id="wechat_main"
)
# 返回:
# {
#     "progress_id": "prg_xxx-xxx-xxx",
#     "first_question": {
#         "question_id": "q1",
#         "question_type": "single_choice",
#         "question_text": "您好！欢迎注册 StockAI。请问您的投资经验如何？",
#         "options": [
#             {"value": "newbie", "label": "刚入门，是投资小白"},
#             {"value": "junior", "label": "有一些基础了解"},
#             {"value": "intermediate", "label": "有1-3年投资经验"},
#             {"value": "expert", "label": "资深投资者，3年以上经验"}
#         ],
#         "is_last": False
#     },
#     "welcome_message": "欢迎加入 StockAI！..."
}

# ========== 第3步: 用户提交答案 ==========
# 用户回复: "刚入门，是投资小白"
save_result = onboarding_service.save_answer(
    progress_id="prg_xxx-xxx-xxx",
    question_id="q1",
    answer="newbie"
)
# 返回:
# {
#     "success": True,
#     "is_complete": False,
#     "next_question": {
#         "question_id": "q2",
#         "question_type": "single_choice",
#         "question_text": "您的风险偏好是？",
#         "options": [...],
#         "is_last": False
#     },
#     "progress": 25.0
# }

# ... 继续回答问题 q2, q3, q4 ...

# ========== 第4步: 完成问卷 ==========
final_answer = onboarding_service.save_answer(
    progress_id="prg_xxx-xxx-xxx",
    question_id="q4",
    answer=["technology", "finance"]  # 关注板块
)
# 返回:
# {
#     "success": True,
#     "is_complete": True,
#     "progress": 100.0,
#     "next_question": None
# }

# ========== 第5步: 完成注册 ==========
complete_result = onboarding_service.complete_onboarding(
    progress_id="prg_xxx-xxx-xxx",
    create_user=True
)
# 返回:
# {
#     "success": True,
#     "user_id": "usr_new-user-uuid",
#     "agent_id": "agt_new-agent-uuid",
#     "error": None
# }

# 此步骤内部执行的 SQL 操作:
# 1. INSERT INTO user_accounts (user_id, nickname, status, ...)
# 2. INSERT INTO user_profiles (user_id, investment_experience, risk_profile, ...)
#    VALUES ('usr_new-user-uuid', 'newbie', 'moderate', ...)
# 3. INSERT INTO user_identities (identity_id, user_id, provider, provider_id, ...)
#    VALUES ('idt_xxx', 'usr_new-user-uuid', 'wechat', 'wxid_newuser', ...)
# 4. INSERT INTO user_agents (agent_id, user_id, agent_name, config, status, ...)
#    VALUES ('agt_new-agent-uuid', 'usr_new-user-uuid', 'StockAI_用户', {...}, 'running', ...)
# 5. UPDATE onboarding_progress SET status='completed', user_id='usr_new-user-uuid', complete_time=NOW()

# ========== 第6步: 首次对话 ==========
# 此时用户已成为"老用户"，后续消息走老用户流程
route_result = agent_manager.route_to_agent(
    agent_id="agt_new-agent-uuid",
    message="你好",
    context={"user_id": "usr_new-user-uuid", ...}
)
```

---

## 接口调用示例

### 1. Identity Service

```python
# 识别用户
identity = identity_service.identify_user(
    wechat_id="wxid_abc123",
    channel_id="wechat_main"
)

# 绑定新微信账号
result = identity_service.bind_wechat(
    user_id="usr_xxx",
    wechat_id="wxid_def456",
    channel_id="wechat_test",
    is_primary=False
)

# 获取用户所有身份
identities = identity_service.get_user_identities(user_id="usr_xxx")
```

### 2. Agent Manager

```python
# 创建 Client Agent
result = agent_manager.create_client_agent(
    user_id="usr_xxx",
    user_profile={
        "investment_experience": "intermediate",
        "risk_profile": "moderate",
        "investment_style": "value"
    },
    agent_config={
        "model": "kimi-coding/k2p5",
        "temperature": 0.7,
        "skills_enabled": ["stock_analysis", "market_sentiment"]
    }
)

# 获取 Agent 信息
agent = agent_manager.get_client_agent(user_id="usr_xxx")

# 启动 Agent
result = agent_manager.start_agent(agent_id="agt_yyy")

# 路由消息
result = agent_manager.route_to_agent(
    agent_id="agt_yyy",
    message="分析贵州茅台",
    context={
        "user_id": "usr_xxx",
        "wechat_id": "wxid_abc123",
        "channel_id": "wechat_main",
        "message_id": "msg_123",
        "timestamp": 1712300400
    }
)
```

### 3. User Memory Service

```python
# 获取用户画像
profile = memory_service.get_profile(user_id="usr_xxx")

# 更新画像
result = memory_service.update_profile(
    user_id="usr_xxx",
    profile_update={
        "risk_profile": "aggressive",
        "tags": ["活跃交易者", "偏好科技股"]
    }
)

# 自选股操作
watchlist = memory_service.get_watchlist(user_id="usr_xxx")
memory_service.add_watchlist(
    user_id="usr_xxx",
    stock_code="600519.SH",
    stock_name="贵州茅台",
    alert_high=1800.0,
    alert_low=1500.0
)

# 持仓操作
holdings = memory_service.get_holdings(user_id="usr_xxx")
memory_service.add_holding(
    user_id="usr_xxx",
    stock_code="000001.SZ",
    stock_name="平安银行",
    shares=1000,
    avg_cost=12.5
)

# 长期记忆
memory_service.add_memory(
    user_id="usr_xxx",
    memory_type="preference",
    memory_key="preferred_analysis_method",
    memory_value="technical",
    category="analysis",
    source="user_explicit",
    confidence=0.95
)
```

### 4. Message Service

```python
# 记录消息
msg = message_service.record_message(
    user_id="usr_xxx",
    agent_id="agt_yyy",
    channel_id="wechat_main",
    wechat_id="wxid_abc123",
    direction="inbound",
    content="帮我看看茅台",
    message_type="text",
    metadata={"raw_msg_id": "wx_msg_123"}
)

# 获取历史
history = message_service.get_message_history(
    user_id="usr_xxx",
    limit=50
)

# 更新状态
message_service.update_message_status(
    message_id="msg_xxx",
    processed=True,
    processing_time_ms=2500
)
```

---

## 数据流转序列图

### 老用户完整序列

```
微信用户     Gateway    MainAgent   Identity   AgentMgr   ClientAgent   Supabase
   │           │           │           │           │           │           │
   │──────────发送消息──────▶│           │           │           │           │
   │           │           │           │           │           │           │
   │           │           │────────identify_user───────────────▶│           │
   │           │           │           │           │           │           │
   │           │           │◀─────────{exists:true}──────────────│           │
   │           │           │           │           │           │           │
   │           │           │──────────get_client_agent──────────▶│           │
   │           │           │           │           │           │           │
   │           │           │◀─────────AgentInfo──────────────────│           │
   │           │           │           │           │           │           │
   │           │           │───────────route_to_agent────────────▶│           │
   │           │           │           │           │           │           │
   │           │           │           │           │           │────读取记忆──▶
   │           │           │           │           │           │◀────────────│
   │           │           │           │           │           │           │
   │           │           │           │           │           │ [处理消息...]
   │           │           │           │           │           │           │
   │           │           │◀──────────处理结果───────────────────│           │
   │           │           │           │           │           │           │
   │◀──────────────────────发送回复──────────────────────────────────────────│
   │           │           │           │           │           │           │
   │           │           │────────────────保存消息────────────────────────▶
   │           │           │◀────────────────────────────────────────────────│
   │           │           │           │           │           │           │
```

### 新用户注册序列

```
微信用户     Gateway    MainAgent   Identity   Onboarding   AgentMgr   Supabase
   │           │           │           │           │           │           │
   │──────────发送消息──────▶│           │           │           │           │
   │           │           │           │           │           │           │
   │           │           │────────identify_user──────────────────────────▶
   │           │           │           │           │           │           │
   │           │           │◀─────────{exists:false}────────────────────────│
   │           │           │           │           │           │           │
   │           │           │──────start_onboarding────────────────────────▶
   │           │           │           │           │           │           │
   │           │           │◀─────────{progress_id, question}───────────────│
   │           │           │           │           │           │           │
   │◀──────────────────────欢迎语+问题1───────────────────────────────────────│
   │           │           │           │           │           │           │
   │──────────答案1─────────▶│           │           │           │           │
   │           │           │           │           │           │           │
   │           │           │──────────save_answer──────────────────────────▶
   │           │           │           │           │           │           │
   │           │           │◀─────────{progress, question2}─────────────────│
   │           │           │           │           │           │           │
   │◀──────────────────────问题2──────────────────────────────────────────────│
   │           │           │           │           │           │           │
   │... (重复直到完成)                                                      │
   │           │           │           │           │           │           │
   │           │           │──────────complete_onboarding──────────────────▶
   │           │           │           │           │           │           │
   │           │           │           │           │           │ 创建 user_account
   │           │           │           │           │           │ 创建 user_profile
   │           │           │           │           │           │ 创建 user_identity
   │           │           │           │           │           │ 创建 user_agent
   │           │           │           │           │           │           │
   │           │           │◀─────────{user_id, agent_id}────────────────────│
   │           │           │           │           │           │           │
   │◀──────────────────────注册完成通知───────────────────────────────────────│
```

---

## 快速参考表

### 表与模型映射

| 数据库表 | Pydantic 模型 | 主要接口 |
|---------|--------------|---------|
| user_accounts | UserAccount | IdentityService |
| user_identities | UserIdentity | IdentityService |
| user_profiles | UserProfile | UserMemoryService |
| user_agents | UserAgent | AgentManager |
| user_sessions | UserSession | AgentManager |
| user_watchlist | UserWatchlist | UserMemoryService |
| user_holdings | UserHolding | UserMemoryService |
| messages | Message | MessageService |
| routing_log | RoutingLog | RoutingLogService |
| onboarding_progress | OnboardingProgress | OnboardingService |
| user_memories | UserMemory | UserMemoryService |
| skill_usage | SkillUsage | SkillUsageService |

### 核心方法速查

| 功能 | 方法 | 返回值关键字段 |
|------|------|--------------|
| 识别用户 | `IdentityService.identify_user` | exists, user_id, agent_id, status |
| 创建 Agent | `AgentManager.create_client_agent` | agent_id, workspace_path, status |
| 路由消息 | `AgentManager.route_to_agent` | status, response, processing_time_ms |
| 保存答案 | `OnboardingService.save_answer` | is_complete, next_question, progress |
| 完成注册 | `OnboardingService.complete_onboarding` | user_id, agent_id |
| 获取画像 | `UserMemoryService.get_profile` | investment_experience, risk_profile... |
| 添加自选 | `UserMemoryService.add_watchlist` | watchlist_id |
