"""
StockAI 2.0 - 模块接口定义
============================
基于 Phase 1 架构设计和 Phase 2 数据库 Schema 的完整接口定义
"""

from abc import ABC, abstractmethod
from typing import Optional, List, Dict, Any
from datetime import datetime


# =============================================================================
# 1. Main Agent 接口
# =============================================================================

class MainAgentRouterInterface(ABC):
    """Main Agent 路由模块接口
    
    职责:
    - 接收所有微信消息入口
    - 识别用户身份
    - 路由消息到新用户流程或 Client Agent
    - 统一错误处理和响应格式化
    """
    
    @abstractmethod
    def handle_message(
        self,
        wechat_id: str,
        channel_id: str,
        message: str,
        message_type: str = "text",
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """处理微信消息入口 - 核心方法
        
        Args:
            wechat_id: 微信用户ID (如: wxid_xxx)
            channel_id: 频道标识 ('wechat_main' | 'wechat_test')
            message: 消息内容文本
            message_type: 消息类型 ('text' | 'image' | 'voice' | 'file')
            metadata: 额外元数据 (timestamp, msg_id等)
            
        Returns:
            {
                "success": bool,
                "action": "route_to_client" | "start_onboarding" | "error",
                "target_agent_id": str | None,
                "user_id": str | None,
                "response": str | None,  # 直接回复给用户的内容
                "reason": str,
                "error_code": str | None
            }
        """
        pass
    
    @abstractmethod
    def health_check(self) -> Dict[str, Any]:
        """服务健康检查
        
        Returns:
            {
                "status": "healthy" | "degraded" | "unhealthy",
                "version": str,
                "services": {
                    "identity_service": bool,
                    "agent_manager": bool,
                    "onboarding_service": bool,
                    "database": bool
                }
            }
        """
        pass


# =============================================================================
# 2. Identity Service 接口
# =============================================================================

class IdentityServiceInterface(ABC):
    """用户身份识别服务接口
    
    职责:
    - 通过微信ID + 渠道ID识别用户
    - 管理用户身份绑定关系
    - 处理多身份提供者(微信/手机号/邮箱)
    """
    
    @abstractmethod
    def identify_user(
        self,
        wechat_id: str,
        channel_id: str
    ) -> Dict[str, Any]:
        """识别用户身份 - 核心方法
        
        查询 user_identities 表，根据 provider='wechat' 和 provider_id 匹配
        
        Args:
            wechat_id: 微信用户ID
            channel_id: 频道标识
            
        Returns:
            {
                "exists": bool,
                "user_id": str | None,      # 对应 user_accounts.user_id
                "agent_id": str | None,     # 对应 user_agents.agent_id
                "identity_id": str | None,  # 对应 user_identities.identity_id
                "status": "active" | "onboarding" | "inactive" | "suspended",
                "is_primary": bool          # 是否主身份
            }
        """
        pass
    
    @abstractmethod
    def bind_wechat(
        self,
        user_id: str,
        wechat_id: str,
        channel_id: str,
        is_primary: bool = False,
        auth_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """绑定微信账号到用户
        
        在 user_identities 表中创建新记录
        
        Args:
            user_id: 用户ID (user_accounts.user_id)
            wechat_id: 微信用户ID
            channel_id: 频道标识
            is_primary: 是否设为主身份
            auth_data: 额外认证数据 (unionid等)
            
        Returns:
            {
                "success": bool,
                "identity_id": str | None,
                "error": str | None
            }
        """
        pass
    
    @abstractmethod
    def unbind_wechat(
        self,
        user_id: str,
        wechat_id: str,
        channel_id: str
    ) -> Dict[str, Any]:
        """解绑微信账号
        
        更新 user_identities 表的 unbound_at 字段
        
        Returns:
            {"success": bool, "error": str | None}
        """
        pass
    
    @abstractmethod
    def get_user_identities(
        self,
        user_id: str
    ) -> List[Dict[str, Any]]:
        """获取用户的所有身份绑定
        
        Returns:
            [
                {
                    "identity_id": str,
                    "provider": str,
                    "provider_id": str,
                    "channel_id": str,
                    "is_primary": bool,
                    "bound_at": str
                }
            ]
        """
        pass


# =============================================================================
# 3. Agent Manager 接口
# =============================================================================

class AgentManagerInterface(ABC):
    """Client Agent 管理器接口
    
    职责:
    - 创建/销毁用户专属的 Client Agent
    - 管理 Agent 生命周期 (running/stopped/error)
    - 消息路由到指定 Agent
    - Agent 状态监控
    """
    
    @abstractmethod
    def create_client_agent(
        self,
        user_id: str,
        user_profile: Dict[str, Any],
        agent_config: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """创建用户专属的 Client Agent
        
        在 user_agents 表中创建记录，并初始化 Agent 工作空间
        
        Args:
            user_id: 用户ID
            user_profile: 用户画像数据
            agent_config: Agent 个性化配置
            
        Returns:
            {
                "success": bool,
                "agent_id": str | None,         # UUID v4
                "workspace_path": str | None,   # Agent 工作空间路径
                "status": "created" | "error",
                "message": str
            }
        """
        pass
    
    @abstractmethod
    def get_client_agent(
        self,
        user_id: str
    ) -> Optional[Dict[str, Any]]:
        """获取用户的 Client Agent 信息
        
        查询 user_agents 表
        
        Returns:
            {
                "agent_id": str,
                "user_id": str,
                "agent_name": str,
                "status": "running" | "stopped" | "error",
                "config": Dict[str, Any],
                "created_at": str,
                "last_active_at": str | None
            } | None
        """
        pass
    
    @abstractmethod
    def route_to_agent(
        self,
        agent_id: str,
        message: str,
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """将消息路由到指定 Client Agent - 核心方法
        
        Args:
            agent_id: Agent ID
            message: 用户消息内容
            context: 上下文信息
                {
                    "user_id": str,
                    "wechat_id": str,
                    "channel_id": str,
                    "message_id": str,
                    "session_id": str | None,
                    "timestamp": int
                }
            
        Returns:
            {
                "status": "delivered" | "error" | "timeout",
                "response": str | None,     # Agent 生成的回复
                "response_type": "text" | "markdown" | "image" | "card",
                "processing_time_ms": int,
                "error": str | None,
                "error_code": str | None
            }
        """
        pass
    
    @abstractmethod
    def start_agent(self, agent_id: str) -> Dict[str, Any]:
        """启动 Client Agent
        
        Returns:
            {"success": bool, "status": str, "error": str | None}
        """
        pass
    
    @abstractmethod
    def stop_agent(self, agent_id: str) -> Dict[str, Any]:
        """停止 Client Agent
        
        Returns:
            {"success": bool, "status": str, "error": str | None}
        """
        pass
    
    @abstractmethod
    def get_agent_status(self, agent_id: str) -> Dict[str, Any]:
        """获取 Agent 运行状态
        
        Returns:
            {
                "agent_id": str,
                "status": "running" | "stopped" | "error",
                "uptime_seconds": int | None,
                "memory_usage_mb": float | None,
                "last_error": str | None
            }
        """
        pass


# =============================================================================
# 4. Onboarding Service 接口
# =============================================================================

class OnboardingServiceInterface(ABC):
    """问卷流程服务接口
    
    职责:
    - 管理新用户注册问卷流程
    - 保存用户答案
    - 生成用户画像
    - 与 Client Agent 创建联动
    """
    
    @abstractmethod
    def start_onboarding(
        self,
        wechat_id: str,
        channel_id: str
    ) -> Dict[str, Any]:
        """开始新用户注册流程
        
        在 onboarding_progress 表创建记录
        
        Returns:
            {
                "progress_id": str,
                "first_question": Dict[str, Any],
                "welcome_message": str
            }
        """
        pass
    
    @abstractmethod
    def get_next_question(
        self,
        progress_id: str
    ) -> Optional[Dict[str, Any]]:
        """获取下一个问题
        
        根据 onboarding_progress.current_question 计算
        
        Returns:
            {
                "question_id": str,
                "question_type": "single_choice" | "multiple_choice" | "text" | "number",
                "question_text": str,
                "options": List[Dict] | None,
                "hint": str | None,
                "is_last": bool
            } | None (表示已完成)
        """
        pass
    
    @abstractmethod
    def save_answer(
        self,
        progress_id: str,
        question_id: str,
        answer: Any
    ) -> Dict[str, Any]:
        """保存用户答案，返回下一个问题或完成状态
        
        更新 onboarding_progress.answers 和 current_question
        
        Args:
            progress_id: 进度记录ID
            question_id: 问题ID
            answer: 用户答案
            
        Returns:
            {
                "success": bool,
                "is_complete": bool,
                "next_question": Dict | None,  # 如果未完成
                "progress": float,              # 完成进度 0-100
                "error": str | None
            }
        """
        pass
    
    @abstractmethod
    def is_complete(
        self,
        progress_id: str
    ) -> bool:
        """检查问卷是否完成"""
        pass
    
    @abstractmethod
    def get_answers(
        self,
        progress_id: str
    ) -> Dict[str, Any]:
        """获取所有答案
        
        Returns:
            {
                "progress_id": str,
                "answers": Dict[str, Any],
                "completed_at": str | None,
                "user_profile": Dict[str, Any]  # 解析后的画像数据
            }
        """
        pass
    
    @abstractmethod
    def complete_onboarding(
        self,
        progress_id: str,
        create_user: bool = True
    ) -> Dict[str, Any]:
        """完成注册流程
        
        1. 创建 user_accounts 记录
        2. 创建 user_profiles 记录
        3. 绑定微信身份
        4. 创建 Client Agent
        5. 更新 onboarding_progress 状态
        
        Returns:
            {
                "success": bool,
                "user_id": str | None,
                "agent_id": str | None,
                "error": str | None
            }
        """
        pass


# =============================================================================
# 5. User Memory Service 接口
# =============================================================================

class UserMemoryServiceInterface(ABC):
    """用户记忆服务接口
    
    职责:
    - 管理用户画像 (profile)
    - 管理自选股 (watchlist)
    - 管理持仓 (holdings)
    - 管理长期记忆 (memories)
    - 提供记忆检索和更新
    """
    
    # ----- 用户画像 -----
    
    @abstractmethod
    def get_profile(self, user_id: str) -> Optional[Dict[str, Any]]:
        """获取用户完整画像
        
        关联查询 user_accounts + user_profiles
        
        Returns:
            {
                "user_id": str,
                "nickname": str,
                "email": str | None,
                "phone": str | None,
                "status": str,
                "investment_experience": str,
                "risk_profile": str,
                "investment_style": str,
                "focus_sectors": List[str],
                "preferences": Dict[str, Any],
                "tags": List[str]
            } | None
        """
        pass
    
    @abstractmethod
    def update_profile(
        self,
        user_id: str,
        profile_update: Dict[str, Any]
    ) -> Dict[str, Any]:
        """更新用户画像
        
        Returns:
            {"success": bool, "updated_fields": List[str], "error": str | None}
        """
        pass
    
    # ----- 自选股 -----
    
    @abstractmethod
    def get_watchlist(
        self,
        user_id: str,
        include_stock_info: bool = False
    ) -> List[Dict[str, Any]]:
        """获取自选股列表
        
        查询 user_watchlist 表
        
        Args:
            include_stock_info: 是否包含实时股票信息
            
        Returns:
            [
                {
                    "watchlist_id": str,
                    "stock_code": str,
                    "stock_name": str,
                    "alert_high": float | None,
                    "alert_low": float | None,
                    "notes": str | None,
                    "sort_order": int,
                    "added_at": str
                }
            ]
        """
        pass
    
    @abstractmethod
    def add_watchlist(
        self,
        user_id: str,
        stock_code: str,
        stock_name: Optional[str] = None,
        alert_high: Optional[float] = None,
        alert_low: Optional[float] = None,
        notes: Optional[str] = None
    ) -> Dict[str, Any]:
        """添加自选股
        
        Returns:
            {"success": bool, "watchlist_id": str | None, "error": str | None}
        """
        pass
    
    @abstractmethod
    def remove_watchlist(
        self,
        user_id: str,
        stock_code: str
    ) -> Dict[str, Any]:
        """移除自选股
        
        Returns:
            {"success": bool, "error": str | None}
        """
        pass
    
    @abstractmethod
    def update_watchlist(
        self,
        user_id: str,
        stock_code: str,
        updates: Dict[str, Any]
    ) -> Dict[str, Any]:
        """更新自选股设置
        
        Args:
            updates: {alert_high, alert_low, notes, sort_order}
        """
        pass
    
    # ----- 持仓 -----
    
    @abstractmethod
    def get_holdings(
        self,
        user_id: str,
        include_metrics: bool = True
    ) -> List[Dict[str, Any]]:
        """获取持仓列表
        
        查询 user_holdings 表
        
        Returns:
            [
                {
                    "holding_id": str,
                    "stock_code": str,
                    "stock_name": str,
                    "shares": int,
                    "avg_cost": float,
                    "current_price": float | None,
                    "total_cost": float,        # 计算字段
                    "market_value": float,      # 计算字段
                    "unrealized_pnl": float,    # 计算字段
                    "unrealized_pnl_pct": float # 计算字段
                }
            ]
        """
        pass
    
    @abstractmethod
    def add_holding(
        self,
        user_id: str,
        stock_code: str,
        shares: int,
        avg_cost: float,
        stock_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """添加持仓记录
        
        Returns:
            {"success": bool, "holding_id": str | None, "error": str | None}
        """
        pass
    
    @abstractmethod
    def update_holding(
        self,
        user_id: str,
        stock_code: str,
        updates: Dict[str, Any]
    ) -> Dict[str, Any]:
        """更新持仓
        
        Args:
            updates: {shares, avg_cost, current_price}
        """
        pass
    
    @abstractmethod
    def remove_holding(
        self,
        user_id: str,
        stock_code: str
    ) -> Dict[str, Any]:
        """移除持仓记录"""
        pass
    
    # ----- 长期记忆 -----
    
    @abstractmethod
    def add_memory(
        self,
        user_id: str,
        memory_type: str,
        memory_key: str,
        memory_value: Any,
        category: Optional[str] = None,
        source: Optional[str] = None,
        confidence: float = 1.0,
        expires_at: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """添加长期记忆
        
        在 user_memories 表中创建记录
        
        Args:
            memory_type: 'preference' | 'fact' | 'event' | 'insight'
            memory_key: 记忆键
            memory_value: 记忆值 (会被JSON序列化)
            category: 细分类别
            source: 来源
            confidence: 置信度 0-1
            expires_at: 过期时间
        """
        pass
    
    @abstractmethod
    def get_memories(
        self,
        user_id: str,
        memory_type: Optional[str] = None,
        category: Optional[str] = None,
        query: Optional[str] = None,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """检索用户记忆"""
        pass
    
    @abstractmethod
    def update_memory(
        self,
        memory_id: str,
        updates: Dict[str, Any]
    ) -> Dict[str, Any]:
        """更新记忆"""
        pass
    
    @abstractmethod
    def delete_memory(self, memory_id: str) -> Dict[str, Any]:
        """删除记忆"""
        pass


# =============================================================================
# 6. Message Service 接口
# =============================================================================

class MessageServiceInterface(ABC):
    """消息服务接口
    
    职责:
    - 记录所有进出消息
    - 查询消息历史
    - 消息状态追踪
    """
    
    @abstractmethod
    def record_message(
        self,
        user_id: str,
        agent_id: Optional[str],
        channel_id: str,
        wechat_id: str,
        direction: str,  # 'inbound' | 'outbound'
        content: str,
        message_type: str = "text",
        reply_to: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """记录消息
        
        在 messages 表中创建记录
        
        Returns:
            {"success": bool, "message_id": str | None}
        """
        pass
    
    @abstractmethod
    def get_message_history(
        self,
        user_id: str,
        limit: int = 50,
        before_message_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """获取用户消息历史"""
        pass
    
    @abstractmethod
    def update_message_status(
        self,
        message_id: str,
        processed: bool,
        processing_time_ms: Optional[int] = None
    ) -> Dict[str, Any]:
        """更新消息处理状态"""
        pass


# =============================================================================
# 7. Routing Log Service 接口
# =============================================================================

class RoutingLogServiceInterface(ABC):
    """路由日志服务接口
    
    职责:
    - 记录所有路由决策过程
    - 支持调试和路由优化分析
    """
    
    @abstractmethod
    def log_routing_decision(
        self,
        user_id: str,
        message_id: Optional[str],
        routing_type: str,  # 'llm' | 'rule' | 'intent'
        source: str,
        input_content: str,
        intent: Optional[str],
        confidence: float,
        target_agent_id: Optional[str],
        target_skill: Optional[str],
        decision_data: Dict[str, Any],
        success: bool = True,
        error_message: Optional[str] = None,
        execution_time_ms: Optional[int] = None
    ) -> Dict[str, Any]:
        """记录路由决策"""
        pass
    
    @abstractmethod
    def get_routing_logs(
        self,
        user_id: Optional[str] = None,
        intent: Optional[str] = None,
        skill: Optional[str] = None,
        success_only: bool = False,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """查询路由日志"""
        pass


# =============================================================================
# 8. Skill Usage Service 接口
# =============================================================================

class SkillUsageServiceInterface(ABC):
    """技能调用记录服务接口"""
    
    @abstractmethod
    def record_skill_usage(
        self,
        user_id: str,
        agent_id: Optional[str],
        message_id: Optional[str],
        skill_name: str,
        skill_version: Optional[str],
        input_params: Dict[str, Any],
        output_result: Optional[Dict[str, Any]],
        execution_time_ms: int,
        success: bool,
        error_message: Optional[str] = None
    ) -> Dict[str, Any]:
        """记录技能调用"""
        pass
    
    @abstractmethod
    def get_skill_usage_stats(
        self,
        user_id: Optional[str] = None,
        skill_name: Optional[str] = None,
        days: int = 7
    ) -> Dict[str, Any]:
        """获取技能使用统计"""
        pass
