"""
StockAI 2.0 - 数据模型定义 (Pydantic)
=====================================
基于 Phase 2 数据库 Schema 的完整类型定义
"""

from datetime import datetime
from typing import Optional, List, Dict, Any, Literal
from pydantic import BaseModel, Field, field_validator
from enum import Enum


# =============================================================================
# 枚举类型定义
# =============================================================================

class UserStatus(str, Enum):
    """用户状态"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"


class IdentityProvider(str, Enum):
    """身份提供者"""
    WECHAT = "wechat"
    PHONE = "phone"
    EMAIL = "email"
    APPLE = "apple"
    GOOGLE = "google"


class AgentStatus(str, Enum):
    """Agent 运行状态"""
    RUNNING = "running"
    STOPPED = "stopped"
    ERROR = "error"


class OnboardingStatus(str, Enum):
    """注册流程状态"""
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    ABANDONED = "abandoned"


class InvestmentExperience(str, Enum):
    """投资经验等级"""
    NEWBIE = "newbie"           # 新手
    JUNIOR = "junior"           # 入门
    INTERMEDIATE = "intermediate"  # 中级
    EXPERT = "expert"           # 专家


class RiskProfile(str, Enum):
    """风险偏好"""
    CONSERVATIVE = "conservative"  # 保守
    MODERATE = "moderate"          # 均衡
    AGGRESSIVE = "aggressive"      # 激进
    RADICAL = "radical"            # 极度激进


class InvestmentStyle(str, Enum):
    """投资风格"""
    VALUE = "value"         # 价值投资
    GROWTH = "growth"       # 成长投资
    DIVIDEND = "dividend"   # 股息投资
    SWING = "swing"         # 波段交易
    DAYTRADE = "daytrade"   # 日内交易


class MessageDirection(str, Enum):
    """消息方向"""
    INBOUND = "inbound"     # 用户 -> 系统
    OUTBOUND = "outbound"   # 系统 -> 用户


class MessageType(str, Enum):
    """消息类型"""
    TEXT = "text"
    IMAGE = "image"
    VOICE = "voice"
    FILE = "file"
    MARKDOWN = "markdown"
    CARD = "card"


class MemoryType(str, Enum):
    """记忆类型"""
    PREFERENCE = "preference"  # 用户偏好
    FACT = "fact"              # 事实
    EVENT = "event"            # 事件
    INSIGHT = "insight"        # 洞察


class RoutingType(str, Enum):
    """路由类型"""
    LLM = "llm"
    RULE = "rule"
    INTENT = "intent"


class QuestionType(str, Enum):
    """问题类型"""
    SINGLE_CHOICE = "single_choice"
    MULTIPLE_CHOICE = "multiple_choice"
    TEXT = "text"
    NUMBER = "number"


class ChannelId(str, Enum):
    """频道标识"""
    WECHAT_MAIN = "wechat_main"
    WECHAT_TEST = "wechat_test"
    WEB = "web"


# =============================================================================
# 基础模型
# =============================================================================

class TimestampMixin(BaseModel):
    """时间戳混入"""
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None


# =============================================================================
# 用户相关模型
# =============================================================================

class UserAccount(BaseModel):
    """用户账号主表模型 (user_accounts)"""
    user_id: str = Field(..., description="UUID v4 主键")
    nickname: str = Field(default="", max_length=100)
    email: Optional[str] = Field(default=None, max_length=255)
    phone: Optional[str] = Field(default=None, max_length=20)
    avatar_url: Optional[str] = None
    status: UserStatus = Field(default=UserStatus.ACTIVE)
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None


class UserIdentity(BaseModel):
    """用户身份凭证表模型 (user_identities)"""
    identity_id: str = Field(..., description="UUID v4 主键")
    user_id: str = Field(..., description="关联 user_accounts.user_id")
    provider: IdentityProvider
    provider_id: str = Field(..., max_length=128, description="微信ID/手机号/邮箱等")
    channel_id: Optional[str] = Field(default=None, max_length=64)
    channel_name: Optional[str] = Field(default=None, max_length=100)
    auth_data: Optional[Dict[str, Any]] = Field(default=None, description="JSON 额外认证信息")
    is_primary: bool = Field(default=False, description="是否主身份")
    bound_at: datetime = Field(default_factory=datetime.now)
    unbound_at: Optional[datetime] = None


class UserProfile(BaseModel):
    """用户画像表模型 (user_profiles)"""
    user_id: str = Field(..., description="与用户表 1:1 关系")
    
    # 问卷采集的基础画像
    investment_experience: Optional[InvestmentExperience] = None
    risk_profile: Optional[RiskProfile] = None
    investment_style: Optional[InvestmentStyle] = None
    focus_sectors: List[str] = Field(default_factory=list, description="关注板块 JSON 数组")
    
    # 扩展画像 (Agent 学习积累)
    preferences: Dict[str, Any] = Field(default_factory=dict, description="用户偏好设置")
    tags: List[str] = Field(default_factory=list, description="标签数组")
    
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None


class UserAgent(BaseModel):
    """用户-Agent 绑定表模型 (user_agents)"""
    agent_id: str = Field(..., description="UUID v4 主键")
    user_id: str = Field(..., description="关联 user_accounts.user_id")
    agent_name: Optional[str] = Field(default=None, max_length=100)
    config: Dict[str, Any] = Field(default_factory=dict, description="JSON Agent 个性化配置")
    status: AgentStatus = Field(default=AgentStatus.STOPPED)
    last_active_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None


class UserSession(BaseModel):
    """用户会话状态表模型 (user_sessions)"""
    session_id: str = Field(..., description="UUID v4 主键")
    user_id: str = Field(..., description="关联 user_accounts.user_id")
    agent_id: Optional[str] = Field(default=None, description="关联 user_agents.agent_id")
    context: Dict[str, Any] = Field(default_factory=dict, description="JSON 会话上下文")
    last_message_at: Optional[datetime] = None
    message_count: int = Field(default=0, description="本轮会话消息数")
    pending_action: Optional[str] = Field(default=None, max_length=50)
    temp_data: Optional[Dict[str, Any]] = Field(default=None, description="JSON 临时数据")
    updated_at: datetime = Field(default_factory=datetime.now)


# =============================================================================
# 投资相关模型
# =============================================================================

class UserWatchlist(BaseModel):
    """自选股表模型 (user_watchlist)"""
    watchlist_id: str = Field(..., description="UUID v4 主键")
    user_id: str = Field(..., description="关联 user_accounts.user_id")
    stock_code: str = Field(..., max_length=20, description="如: 000001.SZ")
    stock_name: Optional[str] = Field(default=None, max_length=100)
    alert_high: Optional[float] = None
    alert_low: Optional[float] = None
    notes: Optional[str] = None
    sort_order: int = Field(default=0)
    created_at: datetime = Field(default_factory=datetime.now)


class UserHolding(BaseModel):
    """持仓表模型 (user_holdings)"""
    holding_id: str = Field(..., description="UUID v4 主键")
    user_id: str = Field(..., description="关联 user_accounts.user_id")
    stock_code: str = Field(..., max_length=20)
    stock_name: Optional[str] = Field(default=None, max_length=100)
    shares: int = Field(default=0, ge=0)
    avg_cost: float = Field(default=0.0, ge=0.0)
    current_price: Optional[float] = None
    # 计算字段
    total_cost: Optional[float] = None
    market_value: Optional[float] = None
    unrealized_pnl: Optional[float] = None
    unrealized_pnl_pct: Optional[float] = None
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None


class UserHoldingInput(BaseModel):
    """添加持仓输入模型"""
    stock_code: str = Field(..., max_length=20)
    stock_name: Optional[str] = None
    shares: int = Field(..., ge=0)
    avg_cost: float = Field(..., ge=0.0)


# =============================================================================
# 消息相关模型
# =============================================================================

class Message(BaseModel):
    """消息记录表模型 (messages)"""
    message_id: str = Field(..., description="UUID v4 主键")
    user_id: str = Field(..., description="关联 user_accounts.user_id")
    agent_id: Optional[str] = Field(default=None, description="关联 user_agents.agent_id")
    channel_id: str = Field(..., max_length=64)
    wechat_id: Optional[str] = Field(default=None, max_length=64)
    direction: MessageDirection
    message_type: MessageType = Field(default=MessageType.TEXT)
    content: str
    processed: bool = Field(default=False)
    processing_time_ms: Optional[int] = None
    reply_to_message_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    created_at: datetime = Field(default_factory=datetime.now)


class RoutingLog(BaseModel):
    """路由日志表模型 (routing_log)"""
    log_id: str = Field(..., description="UUID v4 主键")
    message_id: Optional[str] = None
    user_id: str
    routing_type: RoutingType
    source: str = Field(default="wechat")
    input_content: str
    intent: Optional[str] = None
    confidence: float = Field(ge=0.0, le=1.0)
    target_agent_id: Optional[str] = None
    target_skill: Optional[str] = None
    decision_data: Dict[str, Any] = Field(default_factory=dict)
    success: bool = Field(default=True)
    error_message: Optional[str] = None
    execution_time_ms: Optional[int] = None
    created_at: datetime = Field(default_factory=datetime.now)


# =============================================================================
# 注册流程模型
# =============================================================================

class OnboardingProgress(BaseModel):
    """问卷进度表模型 (onboarding_progress)"""
    progress_id: str = Field(..., description="UUID v4 主键")
    user_id: Optional[str] = None  # 完成后回填
    wechat_id: str = Field(..., max_length=64)
    channel_id: str = Field(default="wechat_main", max_length=64)
    current_question: int = Field(default=0)
    answers: Dict[str, Any] = Field(default_factory=dict, description="JSON 所有答案")
    status: OnboardingStatus = Field(default=OnboardingStatus.IN_PROGRESS)
    start_time: datetime = Field(default_factory=datetime.now)
    complete_time: Optional[datetime] = None


class OnboardingQuestion(BaseModel):
    """问卷问题模型"""
    question_id: str
    question_type: QuestionType
    question_text: str
    options: Optional[List[Dict[str, Any]]] = None
    hint: Optional[str] = None
    is_last: bool = False
    validation_rules: Optional[Dict[str, Any]] = None


class OnboardingAnswer(BaseModel):
    """问卷答案模型"""
    progress_id: str
    question_id: str
    answer: Any
    answered_at: datetime = Field(default_factory=datetime.now)


# =============================================================================
# 记忆相关模型
# =============================================================================

class UserMemory(BaseModel):
    """用户长期记忆表模型 (user_memories)"""
    memory_id: str = Field(..., description="UUID v4 主键")
    user_id: str
    memory_type: MemoryType
    category: Optional[str] = Field(default=None, max_length=50)
    memory_key: str = Field(..., max_length=200)
    memory_value: Any
    summary: Optional[str] = None
    source: Optional[str] = Field(default=None, max_length=50)
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    expires_at: Optional[datetime] = None
    access_count: int = Field(default=0)
    last_accessed_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None


# =============================================================================
# 技能调用模型
# =============================================================================

class SkillUsage(BaseModel):
    """技能调用记录表模型 (skill_usage)"""
    usage_id: str = Field(..., description="UUID v4 主键")
    user_id: str
    agent_id: Optional[str] = None
    message_id: Optional[str] = None
    skill_name: str = Field(..., max_length=100)
    skill_version: Optional[str] = Field(default=None, max_length=20)
    input_params: Dict[str, Any] = Field(default_factory=dict)
    output_result: Optional[Dict[str, Any]] = None
    execution_time_ms: int
    success: bool = Field(default=True)
    error_message: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.now)


# =============================================================================
# API 请求/响应模型
# =============================================================================

class MessageContext(BaseModel):
    """消息上下文模型"""
    user_id: str
    wechat_id: str
    channel_id: ChannelId
    message_id: str
    session_id: Optional[str] = None
    timestamp: int = Field(..., description="Unix timestamp in seconds")
    user_profile: Optional[UserProfile] = None
    
    class Config:
        use_enum_values = True


class RoutingResult(BaseModel):
    """路由结果模型"""
    success: bool
    action: Literal["route_to_client", "start_onboarding", "error"]
    target_agent_id: Optional[str] = None
    user_id: Optional[str] = None
    response: Optional[str] = None
    reason: str = ""
    error_code: Optional[str] = None


class AgentConfig(BaseModel):
    """Agent 配置模型"""
    model: str = Field(default="kimi-coding/k2p5", description="使用的 LLM 模型")
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    max_tokens: int = Field(default=4096, ge=1)
    system_prompt: Optional[str] = None
    skills_enabled: List[str] = Field(default_factory=list)
    memory_enabled: bool = Field(default=True)
    context_window: int = Field(default=10, description="保持的上下文消息数")
    custom_settings: Dict[str, Any] = Field(default_factory=dict)


class UserIdentityResult(BaseModel):
    """用户身份识别结果模型"""
    exists: bool
    user_id: Optional[str] = None
    agent_id: Optional[str] = None
    identity_id: Optional[str] = None
    status: Optional[Literal["active", "onboarding", "inactive", "suspended"]] = None
    is_primary: Optional[bool] = None


class AgentCreationResult(BaseModel):
    """Agent 创建结果模型"""
    success: bool
    agent_id: Optional[str] = None
    workspace_path: Optional[str] = None
    status: Literal["created", "error"]
    message: str


class RouteToAgentResult(BaseModel):
    """消息路由结果模型"""
    status: Literal["delivered", "error", "timeout"]
    response: Optional[str] = None
    response_type: Literal["text", "markdown", "image", "card"] = "text"
    processing_time_ms: int = 0
    error: Optional[str] = None
    error_code: Optional[str] = None


class OnboardingState(BaseModel):
    """注册流程状态模型"""
    progress_id: str
    user_id: Optional[str] = None
    wechat_id: str
    channel_id: str
    current_question: int
    total_questions: int
    progress_pct: float = Field(ge=0.0, le=100.0)
    answers: Dict[str, Any]
    status: OnboardingStatus
    is_complete: bool = False


class OnboardingCompleteResult(BaseModel):
    """注册完成结果模型"""
    success: bool
    user_id: Optional[str] = None
    agent_id: Optional[str] = None
    profile: Optional[UserProfile] = None
    error: Optional[str] = None


# =============================================================================
# Webhook 请求/响应模型
# =============================================================================

class WechatWebhookRequest(BaseModel):
    """微信 Webhook 请求模型"""
    wechat_id: str
    channel_id: ChannelId
    message: str
    message_type: MessageType = MessageType.TEXT
    timestamp: int
    msg_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    
    class Config:
        use_enum_values = True


class WechatWebhookResponse(BaseModel):
    """微信 Webhook 响应模型"""
    success: bool
    action: str
    response: Optional[str] = None
    response_type: MessageType = MessageType.TEXT
    processing_time_ms: int = 0
    error: Optional[str] = None


# =============================================================================
# 错误响应模型
# =============================================================================

class ErrorResponse(BaseModel):
    """标准错误响应模型"""
    success: bool = False
    error_code: str
    error_message: str
    error_details: Optional[Dict[str, Any]] = None
    timestamp: datetime = Field(default_factory=datetime.now)
    request_id: Optional[str] = None
