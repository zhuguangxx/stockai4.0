# 003 vs 004 功能对比评估报告

**评估时间**: 2026-04-05
**评估目的**: 确认004是否完整复制003功能，评估功能损失

---

## 一、核心模块复制情况 ✅

| 模块 | 003位置 | 004位置 | 状态 | 说明 |
|------|---------|---------|------|------|
| **六大专家系统** | `core/experts.py` | `core/experts.py` | ✅ 已复制 | MACD/KDJ/MA/BOLL/RSI/CCI |
| **技术指标** | `core/indicators.py` | `core/indicators.py` | ✅ 已复制 | 完整复制 |
| **回测引擎** | `backtest/engine.py` | `backtest/engine.py` | ✅ 已复制 | 单标的回测 |
| **组合回测** | `backtest/portfolio_engine.py` | `backtest/portfolio_engine.py` | ✅ 已复制 | 多标的组合回测 |
| **回测报告** | `backtest/report.py` | `backtest/report.py` | ✅ 已复制 | 报告生成 |
| **分析器** | `core/analyzer.py` | `core/analyzer.py` | ✅ 已复制 | 主分析器 |
| **数据获取** | `core/data_fetcher.py` | `core/data_fetcher.py` | ✅ 已复制 | 数据获取 |
| **混合数据源** | `core/mixed_data.py` | `core/mixed_data.py` | ✅ 已复制 | 混合数据策略 |
| **用户记忆** | `user_memory.py` | `src/services/user_memory.py` | ✅ 已复制 | 自选股/持仓/画像 |
| **问卷系统** | `onboarding.py` | `src/services/onboarding.py` | ✅ 已复制 | 6题问卷 |

**结论**: 所有核心模块均已完整复制 ✅

---

## 二、交互功能接入情况 ⚠️

| 功能 | 003实现 | 004当前状态 | 问题 | 修复难度 |
|------|---------|-------------|------|----------|
| **股票分析** | 发送代码直接分析 | ✅ `router.py`已实现 | 无 | - |
| **六大指标详情** | 菜单选项1调用 | ⚠️ **未接入** | 只复制了模块，未在router实现 | 低 |
| **回测功能** | 菜单选项2调用 | ⚠️ **未接入** | 只复制了模块，未在router实现 | 中 |
| **专家辩论** | 菜单选项3调用 | ❌ **未复制** | 003可能也没有独立实现 | 中 |
| **自选股查看** | 菜单或指令 | ✅ `router.py`已实现 | 无 | - |
| **自选股添加** | 菜单或指令 | ✅ `router.py`已实现 | 无 | - |
| **持仓查看** | 菜单或指令 | ✅ `router.py`已实现 | 无 | - |
| **深度研究** | 未实现 | ✅ `router.py`已实现(SubAgent) | 004新增功能 | - |

**关键发现**: 
- 核心模块都复制了 ✅
- 但**菜单交互未完全接入** ⚠️

---

## 三、功能损失评估

### 3.1 功能损失清单

| 功能 | 损失程度 | 影响 | 原因 |
|------|----------|------|------|
| **菜单选项1: 六大指标详情** | 🔴 高 | 用户无法查看指标详细解读 | router未接入experts.py |
| **菜单选项2: 回测** | 🔴 高 | 用户无法触发回测 | router未接入backtest/engine.py |
| **菜单选项3: 专家辩论** | 🟡 中 | 无法看多专家观点对比 | 003可能也未实现 |

### 3.2 功能保留清单

| 功能 | 状态 | 说明 |
|------|------|------|
| 直接发送股票代码分析 | ✅ 完整保留 | 主功能正常 |
| 自选股管理 | ✅ 完整保留 | 添加/删除/查看 |
| 用户画像 | ✅ 完整保留 | 问卷+画像展示 |
| 深度研究 | ✅ 新增 | Sub-Agent深度分析 |
| 持仓管理 | ✅ 完整保留 | 基础功能 |

---

## 四、修复方案

### 4.1 立即修复（高优先级）

#### 修复1: 接入六大指标详情
```python
# 在 router.py 中添加

def _show_indicators_detail(self, user_id: str, stock_code: str):
    """显示六大指标详情"""
    from core.experts import ExpertSystem
    from core.data_access import DataAccess
    
    # 获取数据
    data_access = DataAccess()
    df = data_access.get_stock_data(stock_code, days=60)
    
    if df is None or df.empty:
        return f"无法获取 {stock_code} 的数据"
    
    # 调用六大专家
    expert = ExpertSystem(df)
    results = expert.analyze_all()
    
    # 生成报告
    report = f"📊 {stock_code} 六大指标详情\n\n"
    for indicator, result in results.items():
        report += f"\n{result}\n"
    
    return report
```

**工作量**: 30分钟
**依赖**: core/experts.py 已存在 ✅

#### 修复2: 接入回测功能
```python
# 在 router.py 中添加

def _run_backtest(self, user_id: str, stock_code: str, period: str = "1year"):
    """运行回测"""
    from backtest.engine import BacktestEngine
    from strategies.macd_strategy import MACDStrategy  # 需要确认策略文件
    
    # 创建回测引擎
    engine = BacktestEngine(
        initial_capital=100000,
        commission_rate=0.0003
    )
    
    # 设置策略（使用默认MACD策略）
    strategy = MACDStrategy()
    
    # 运行回测
    result = engine.run(
        stock_code=stock_code,
        strategy=strategy,
        start_date="2024-01-01",
        end_date="2024-12-31"
    )
    
    return result.report
```

**工作量**: 1-2小时
**依赖**: backtest/engine.py 已存在 ✅，但可能需要策略文件

### 4.2 确认003是否有专家辩论

需要检查003源码确认:
- 003的experts.py是否有多专家对比功能？
- 还是只有六大独立专家，没有辩论逻辑？

如果003也没有，则不属于功能损失。

---

## 五、总体评估

### 5.1 模块完整性: 95% ✅

所有核心分析模块都已完整复制，没有代码损失。

### 5.2 功能可用性: 70% ⚠️

虽然模块都在，但部分交互功能未接入router，用户暂时无法使用。

### 5.3 建议

**方案A - 完整修复后部署**（推荐）
- 接入六大指标详情（30分钟）
- 接入回测功能（2小时）
- 测试验证（1小时）
- 总时间: 3.5小时
- 结果: 功能无损失，用户体验一致

**方案B - 先部署基础功能**
- 当前004可直接部署
- 股票分析、自选股、深度研究可用
- 六大指标详情和回测后续迭代
- 适合快速上线验证

---

## 六、你的决策

| 选项 | 时间 | 结果 | 建议 |
|------|------|------|------|
| A. 完整修复后部署 | 3.5小时 | 功能无损失 | ⭐ 推荐 |
| B. 先部署基础功能 | 1小时 | 核心功能可用 | 适合快速验证 |
| C. 保持现状 | 0 | 部分功能缺失 | 不推荐 |

**请指示**:
1. 我立即接入缺失的菜单功能？
2. 先部署，后续迭代？
3. 检查003确认专家辩论是否原本就有？
