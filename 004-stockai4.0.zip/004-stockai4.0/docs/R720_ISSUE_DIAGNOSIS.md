# R720 StockAI 服务问题诊断报告

**调查时间**: 2026-04-05  
**调查人员**: 运维排查工程师 (Subagent)  
**服务器**: nas.ayfans.com:8822 (R720)

---

## 1. 发现的问题

### 1.1 "功能正在开发中" 问题 ✅ 已定位

**来源**: `/data/stockai/skills/menu/handler.py` 第7-9行

```python
RESPONSES = {
    '1': '🔍 六大指标详情功能开发中...\n\n当前支持：MACD、KDJ、MA、BOLL、RSI、CCI',
    '2': '📊 回测功能开发中...\n\n请使用：回测 [股票代码] [开始日期] [结束日期]',
    '3': '⚔️ 专家辩论功能开发中...',
    '4': '✅ 已加入自选股'
}
```

**问题**: 用户分析股票后，回复数字1-3查看详情时，返回"开发中"提示。

**实际功能状态**:
- 核心分析功能 ✓ 完全可用（已验证600519能正常分析）
- 六大指标详情 ✗ 未实现（分析结果中已包含简评）
- 回测功能 ✗ 未实现
- 专家辩论 ✗ 未实现

### 1.2 "无数据" 问题 ⚠️ 未发现系统性问题

**调查结果**: 
- 数据库 `stock.db` 大小: **668MB**
- K线数据表: **6,426,821 条记录**
- 覆盖股票数: **7,074 只**
- 测试600519: ✓ 数据正常（200天历史数据）

**结论**: 未发现"无数据"返回的系统性问题。用户看到的"无数据"可能是:
1. 个别股票确实无数据（新股或停牌股）
2. Baostock实时数据获取失败时的提示（见下文）

### 1.3 Baostock 实时数据获取失败 ⚠️

**现象**: 每次分析时都显示
```
🔄 获取实时数据...
login success!
logout success!
⚠️  实时数据获取失败，使用历史数据
```

**影响**: 使用昨日收盘数据作为"当前价格"，非实时数据。

**根本原因**: 
- 周末/非交易时间Baostock无实时数据
- 或Baostock接口配置/网络问题

### 1.4 服务状态异常 ⚠️

**问题**: `stockai-gateway-listener.service` 显示为 `inactive (dead)`
```
     Active: inactive (dead) since Sat 2026-04-04 19:20:01 UTC; 12h ago
```

**但**: ps显示进程仍在运行
```
root 163501 python3 /data/stockai/gateway_listener.py
```

**分析**: systemd服务配置可能有问题，但进程由其他方式启动并正常运行。

### 1.5 菜单重复显示 ⚠️

**现象**: 分析结果底部出现两次相同的操作菜单

```
━━━━━━━━━━━━━━━━━━━━━━
📋 下一步操作:
【1】...
━━━━━━━━━━━━━━━━━━━━━━

━━━━━━━━━━━━━━━━━━━━━━
📋 下一步操作:
【1】...
━━━━━━━━━━━━━━━━━━━━━━
```

**来源**: 
- 第一次: `analyzer.py` 中的 `generate_menu()`
- 第二次: `skills/analyzer/main.py` 中的 `menu` 变量

---

## 2. 根本原因分析

| 问题 | 根本原因 | 严重程度 |
|------|---------|---------|
| "功能开发中" | 菜单功能未实现，仅返回占位文本 | 中等 |
| 实时数据失败 | Baostock在非交易时间无数据/网络问题 | 低 |
| 服务状态异常 | systemd服务配置问题，但进程正常运行 | 低 |
| 菜单重复 | 两处代码都添加了菜单，重复拼接 | 低 |

---

## 3. 修复建议

### 🔴 高优先级

#### 3.1 修复菜单功能（立即修复）

**方案A**: 实现功能
```bash
# 修改 /data/stockai/skills/menu/handler.py
# 选项1: 调用已有分析数据展示详情
# 选项2: 调用 backtest/ 目录下的回测功能
# 选项3: 实现专家辩论（调用experts.py生成不同观点）
```

**方案B**: 暂时隐藏未实现功能
```python
RESPONSES = {
    '1': '🔍 六大指标详情\n\nMACD、KDJ、MA、BOLL、RSI、CCI指标已在上方分析报告中展示',
    '4': '✅ 已加入自选股'
}
# 移除选项2、3或返回友好提示
```

### 🟡 中优先级

#### 3.2 修复菜单重复问题

修改 `/data/stockai/skills/analyzer/main.py`:
```python
# 移除或注释掉 menu 变量的添加
# analyzer.py 已经调用了 generate_menu()
```

#### 3.3 修复服务状态显示

检查systemd服务配置:
```bash
systemctl cat stockai-gateway-listener.service
# 检查ExecStart是否指向正确的进程
# 检查PID文件配置
```

### 🟢 低优先级

#### 3.4 优化实时数据获取

- 添加交易时间判断，非交易时间不尝试获取实时数据
- 添加备用数据源（如akshare、tushare）
- 优化错误提示，区分"非交易时间"和"获取失败"

---

## 4. 验证测试结果

### 4.1 服务状态
- OpenClaw Gateway: ✓ 运行中 (127.0.0.1:18789)
- wechat_server.py: ✓ 运行中 (127.0.0.1:18080)
- gateway_listener.py: ✓ 运行中 (WebSocket连接正常)

### 4.2 API测试
- 新用户欢迎消息: ✓ 正常
- 股票分析 (600519): ✓ 正常，返回完整报告
- 菜单选项1: ✗ 返回"开发中"
- 菜单选项2: ✗ 返回"开发中"
- 菜单选项3: ✗ 返回"开发中"

### 4.3 数据检查
- stock.db: ✓ 668MB, 642万条K线数据
- agent_memory.db: ✓ 用户状态正常存储
- kline表覆盖: ✓ 7074只股票

---

## 5. 立即修复脚本

如需立即修复"开发中"问题，执行:

```bash
# SSH到R720
ssh root@nas.ayfans.com -p 8822

# 备份原文件
cp /data/stockai/skills/menu/handler.py /data/stockai/skills/menu/handler.py.bak

# 修复菜单响应
cat > /data/stockai/skills/menu/handler.py << 'EOF'
#!/usr/bin/env python3
"""菜单选择处理"""

import sys

RESPONSES = {
    '1': '🔍 六大指标详情\n\nMACD、KDJ、MA、BOLL、RSI、CCI 六大指标详情已在分析报告中展示。\n\n如需重新分析，请直接发送股票代码。',
    '2': '📊 回测功能\n\n回测功能正在优化中，敬请期待！\n\n当前可使用：直接发送股票代码获取技术分析',
    '3': '⚔️ 专家辩论\n\n专家辩论功能正在开发中！',
    '4': '✅ 已加入自选股（功能开发中）'
}

def handle(user_id, choice):
    return RESPONSES.get(choice, '❌ 无效选项，请回复 1-4')

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("用法: handler.py <user_id> <choice>")
        sys.exit(1)
    
    user_id = sys.argv[1]
    choice = sys.argv[2]
    print(handle(user_id, choice))
EOF

echo "修复完成！"
```

---

## 6. 总结

**核心问题**: "功能正在开发中"是产品功能未完成导致的用户体验问题，不是服务故障。

**好消息**: 
- 核心股票分析功能完全正常
- 数据库数据完整（668MB，7000+股票）
- 所有服务进程运行正常
- API响应正常

**需要修复**:
1. 菜单选项1-3改为友好提示或实现功能
2. 修复菜单重复显示问题
3. 优化非交易时间的实时数据提示

---

*报告生成时间: 2026-04-05*  
*报告位置: /root/.openclaw/workspace/004-stockai4.0/docs/R720_ISSUE_DIAGNOSIS.md*
