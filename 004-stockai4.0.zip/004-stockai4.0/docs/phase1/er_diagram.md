# StockAI 2.0 数据库 ER 图设计

## 1. 实体关系图（ASCII）

```
┌─────────────────┐       ┌─────────────────┐       ┌─────────────────┐
│  users          │       │  agents         │       │  wechat_bindings│
│  (用户主表)      │◀─────▶│  (Agent表)      │       │  (微信绑定表)    │
└────────┬────────┘       └────────┬────────┘       └────────┬────────┘
         │                         │                         │
         │ 1:N                     │ 1:1                     │ N:1
         │                         │                         │
         ▼                         ▼                         │
┌─────────────────┐       ┌─────────────────┐               │
│  messages       │       │  user_sessions  │               │
│  (消息历史)      │       │  (会话状态)      │               │
└─────────────────┘       └─────────────────┘               │
                                                            │
┌─────────────────┐       ┌─────────────────┐               │
│  portfolios     │       │  watchlists     │               │
│  (持仓表)        │       │  (自选股)        │               │
└────────┬────────┘       └─────────────────┘               │
         │                                                  │
         │ 1:N                                              │
         ▼                                                  │
┌─────────────────┐                                         │
│  portfolio_holdings                                         │
│  (持仓明细)      │                                         │
└─────────────────┘                                         │
                                                            │
┌─────────────────┐       ┌─────────────────┐               │
│  skills_usage   │       │  memories       │               │
│  (技能调用记录)  │       │  (长期记忆)      │               │
└─────────────────┘       └─────────────────┘               │
                                                            │
┌─────────────────┐                                         │
│  onboarding_logs │                                        │
│  (注册流程记录)  │◀────────────────────────────────────────┘
└─────────────────┘
```

## 2. 表结构设计

### 2.1 users (用户主表)

```sql
CREATE TABLE users (
    -- 主键
    user_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- 基础信息
    nickname VARCHAR(100) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(20),
    avatar_url TEXT,
    
    -- 投资画像 (来自问卷)
    investment_experience VARCHAR(20),  -- 'beginner' | 'intermediate' | 'expert'
    risk_profile VARCHAR(20),           -- 'conservative' | 'balanced' | 'aggressive'
    preferred_sectors TEXT[],           -- ['tech', 'finance', 'healthcare', ...]
    
    -- 状态
    status VARCHAR(20) DEFAULT 'active', -- 'active' | 'inactive' | 'suspended'
    
    -- 时间戳
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    
    -- 索引
    CONSTRAINT valid_experience CHECK (investment_experience IN ('beginner', 'intermediate', 'expert')),
    CONSTRAINT valid_risk CHECK (risk_profile IN ('conservative', 'balanced', 'aggressive'))
);

CREATE INDEX idx_users_status ON users(status);
CREATE INDEX idx_users_created ON users(created_at);
```

### 2.2 wechat_bindings (微信绑定表)

```sql
CREATE TABLE wechat_bindings (
    -- 主键
    binding_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- 外键
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    
    -- 微信相关信息
    wechat_id VARCHAR(64) NOT NULL,     -- wxid_xxx
    channel_id VARCHAR(64) NOT NULL,    -- 'wechat_main' | 'wechat_test'
    channel_name VARCHAR(100),          -- 频道显示名
    
    -- 绑定状态
    is_primary BOOLEAN DEFAULT false,   -- 是否是主绑定
    bound_at TIMESTAMPTZ DEFAULT NOW(),
    unbound_at TIMESTAMPTZ,
    
    -- 唯一约束: 一个微信ID在一个频道只能绑定一个用户
    UNIQUE(wechat_id, channel_id)
);

CREATE INDEX idx_wechat_bindings_user ON wechat_bindings(user_id);
CREATE INDEX idx_wechat_bindings_lookup ON wechat_bindings(wechat_id, channel_id);
CREATE INDEX idx_wechat_bindings_channel ON wechat_bindings(channel_id);
```

### 2.3 agents (Agent 表)

```sql
CREATE TABLE agents (
    -- 主键
    agent_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- 外键
    user_id UUID NOT NULL UNIQUE REFERENCES users(user_id) ON DELETE CASCADE,
    
    -- Agent 配置
    agent_name VARCHAR(100),            -- 默认: "StockAI_{昵称}"
    config JSONB DEFAULT '{}',          -- Agent 个性化配置
    
    -- 运行时状态
    status VARCHAR(20) DEFAULT 'stopped', -- 'running' | 'stopped' | 'error'
    last_active_at TIMESTAMPTZ,
    
    -- 时间戳
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    
    CONSTRAINT valid_agent_status CHECK (status IN ('running', 'stopped', 'error'))
);

CREATE INDEX idx_agents_status ON agents(status);
CREATE INDEX idx_agents_user ON agents(user_id);
```

### 2.4 messages (消息历史表)

```sql
CREATE TABLE messages (
    -- 主键
    message_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- 外键
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    agent_id UUID REFERENCES agents(agent_id) ON DELETE SET NULL,
    
    -- 消息来源
    channel_id VARCHAR(64) NOT NULL,
    wechat_id VARCHAR(64) NOT NULL,
    
    -- 消息内容
    direction VARCHAR(10) NOT NULL,     -- 'inbound' | 'outbound'
    message_type VARCHAR(20) DEFAULT 'text', -- 'text' | 'image' | 'file' | 'voice'
    content TEXT NOT NULL,
    
    -- 处理状态
    processed BOOLEAN DEFAULT false,
    processing_time_ms INTEGER,         -- 处理耗时
    
    -- 时间戳
    created_at TIMESTAMPTZ DEFAULT NOW(),
    
    -- 分区建议: 按 created_at 按月分区
);

CREATE INDEX idx_messages_user_time ON messages(user_id, created_at DESC);
CREATE INDEX idx_messages_channel ON messages(channel_id, created_at DESC);
CREATE INDEX idx_messages_unprocessed ON messages(processed) WHERE processed = false;
```

### 2.5 user_sessions (用户会话状态表)

```sql
CREATE TABLE user_sessions (
    -- 主键
    session_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- 外键
    user_id UUID NOT NULL UNIQUE REFERENCES users(user_id) ON DELETE CASCADE,
    agent_id UUID REFERENCES agents(agent_id),
    
    -- 会话状态
    context JSONB DEFAULT '{}',         -- 当前会话上下文
    last_message_at TIMESTAMPTZ,
    message_count INTEGER DEFAULT 0,    -- 本轮会话消息数
    
    -- 临时状态
    pending_action VARCHAR(50),         -- 待完成的操作 (如: 'awaiting_stock_code')
    temp_data JSONB DEFAULT '{}',       -- 临时数据存储
    
    -- 时间戳
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sessions_agent ON user_sessions(agent_id);
```

### 2.6 portfolios (持仓表)

```sql
CREATE TABLE portfolios (
    -- 主键
    portfolio_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- 外键
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    
    -- 组合信息
    portfolio_name VARCHAR(100) NOT NULL DEFAULT '默认持仓',
    portfolio_type VARCHAR(20) DEFAULT 'stock', -- 'stock' | 'fund' | 'mixed'
    
    -- 统计信息
    total_cost DECIMAL(15, 2),          -- 总成本
    total_value DECIMAL(15, 2),         -- 总市值
    total_return DECIMAL(15, 4),        -- 总收益
    
    -- 时间戳
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    
    -- 默认组合标记
    is_default BOOLEAN DEFAULT false
);

CREATE INDEX idx_portfolios_user ON portfolios(user_id);
```

### 2.7 portfolio_holdings (持仓明细表)

```sql
CREATE TABLE portfolio_holdings (
    -- 主键
    holding_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- 外键
    portfolio_id UUID NOT NULL REFERENCES portfolios(portfolio_id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    
    -- 股票信息
    stock_code VARCHAR(20) NOT NULL,    -- '000001.SZ'
    stock_name VARCHAR(100),            -- '平安银行'
    
    -- 持仓数据
    quantity INTEGER NOT NULL,          -- 持仓数量
    avg_cost DECIMAL(10, 4),            -- 平均成本
    current_price DECIMAL(10, 4),       -- 当前价格
    
    -- 收益计算
    total_cost DECIMAL(15, 2),          -- 总成本
    market_value DECIMAL(15, 2),        -- 市值
    unrealized_pnl DECIMAL(15, 2),      -- 浮动盈亏
    return_rate DECIMAL(8, 4),          -- 收益率
    
    -- 时间戳
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_holdings_portfolio ON portfolio_holdings(portfolio_id);
CREATE INDEX idx_holdings_user ON portfolio_holdings(user_id);
CREATE INDEX idx_holdings_stock ON portfolio_holdings(stock_code);
```

### 2.8 watchlists (自选股表)

```sql
CREATE TABLE watchlists (
    -- 主键
    watchlist_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- 外键
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    
    -- 股票信息
    stock_code VARCHAR(20) NOT NULL,
    stock_name VARCHAR(100),
    
    -- 用户设置
    alert_high DECIMAL(10, 4),          -- 高价预警
    alert_low DECIMAL(10, 4),           -- 低价预警
    notes TEXT,                         -- 备注
    
    -- 排序
    sort_order INTEGER DEFAULT 0,
    
    -- 时间戳
    created_at TIMESTAMPTZ DEFAULT NOW(),
    
    -- 唯一约束
    UNIQUE(user_id, stock_code)
);

CREATE INDEX idx_watchlists_user ON watchlists(user_id);
```

### 2.9 memories (长期记忆表)

```sql
CREATE TABLE memories (
    -- 主键
    memory_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- 外键
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    
    -- 记忆分类
    memory_type VARCHAR(50) NOT NULL,   -- 'preference' | 'fact' | 'event' | 'insight'
    category VARCHAR(50),               -- 细分类别
    
    -- 记忆内容
    key VARCHAR(200) NOT NULL,          -- 记忆键
    value JSONB NOT NULL,               -- 记忆值
    summary TEXT,                       -- 摘要
    
    -- 元数据
    source VARCHAR(50),                 -- 来源
    confidence DECIMAL(3, 2) DEFAULT 1.0, -- 置信度
    
    -- 生命周期
    expires_at TIMESTAMPTZ,             -- 过期时间
    access_count INTEGER DEFAULT 0,     -- 访问次数
    last_accessed_at TIMESTAMPTZ,
    
    -- 时间戳
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_memories_user ON memories(user_id);
CREATE INDEX idx_memories_type ON memories(user_id, memory_type);
CREATE INDEX idx_memories_key ON memories(user_id, key);
```

### 2.10 skills_usage (技能调用记录表)

```sql
CREATE TABLE skills_usage (
    -- 主键
    usage_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- 外键
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    agent_id UUID REFERENCES agents(agent_id),
    message_id UUID REFERENCES messages(message_id),
    
    -- 技能信息
    skill_name VARCHAR(100) NOT NULL,
    skill_version VARCHAR(20),
    
    -- 调用详情
    input_params JSONB,
    output_result JSONB,
    
    -- 性能
    execution_time_ms INTEGER,
    success BOOLEAN DEFAULT true,
    error_message TEXT,
    
    -- 时间戳
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_skills_user ON skills_usage(user_id, created_at DESC);
CREATE INDEX idx_skills_skill ON skills_usage(skill_name, created_at DESC);
```

### 2.11 onboarding_logs (注册流程记录表)

```sql
CREATE TABLE onboarding_logs (
    -- 主键
    log_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- 关联 (可能还没有 user_id)
    user_id UUID REFERENCES users(user_id),
    wechat_id VARCHAR(64) NOT NULL,
    channel_id VARCHAR(64) NOT NULL,
    
    -- 流程状态
    step VARCHAR(50) NOT NULL,          -- 'started' | 'questionnaire' | 'profile_created' | 'agent_created' | 'completed'
    step_data JSONB,                    -- 步骤相关数据
    
    -- 结果
    success BOOLEAN,
    error_message TEXT,
    
    -- 时间戳
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_onboarding_wechat ON onboarding_logs(wechat_id, channel_id);
CREATE INDEX idx_onboarding_user ON onboarding_logs(user_id);
```

## 3. 关系说明

### 3.1 核心关系

| 关系 | 类型 | 说明 |
|-----|------|------|
| users → agents | 1:1 | 一个用户对应一个 Client Agent |
| users → wechat_bindings | 1:N | 一个用户可绑定多个微信账号 |
| users → portfolios | 1:N | 一个用户可有多个持仓组合 |
| portfolios → portfolio_holdings | 1:N | 一个组合包含多只股票 |
| users → watchlists | 1:N | 一个用户可有多个自选股 |
| users → messages | 1:N | 一个用户有多条消息记录 |
| users → memories | 1:N | 一个用户有多条长期记忆 |

### 3.2 跨表查询示例

```sql
-- 1. 通过 wechat_id + channel_id 查询用户信息
SELECT 
    u.user_id,
    u.nickname,
    u.investment_experience,
    u.risk_profile,
    a.agent_id,
    a.status as agent_status
FROM wechat_bindings wb
JOIN users u ON wb.user_id = u.user_id
LEFT JOIN agents a ON u.user_id = a.user_id
WHERE wb.wechat_id = 'wxid_xxx'
  AND wb.channel_id = 'wechat_main';

-- 2. 查询用户的完整持仓信息
SELECT 
    p.portfolio_name,
    ph.stock_code,
    ph.stock_name,
    ph.quantity,
    ph.avg_cost,
    ph.market_value,
    ph.unrealized_pnl
FROM portfolios p
JOIN portfolio_holdings ph ON p.portfolio_id = ph.portfolio_id
WHERE p.user_id = 'user_uuid'
  AND p.is_default = true;

-- 3. 查询用户最近的消息历史
SELECT 
    m.direction,
    m.message_type,
    m.content,
    m.created_at
FROM messages m
WHERE m.user_id = 'user_uuid'
ORDER BY m.created_at DESC
LIMIT 50;

-- 4. 查询用户所有微信绑定
SELECT 
    wb.wechat_id,
    wb.channel_id,
    wb.channel_name,
    wb.is_primary,
    wb.bound_at
FROM wechat_bindings wb
WHERE wb.user_id = 'user_uuid'
  AND wb.unbound_at IS NULL;
```

## 4. 分区策略建议

### 4.1 messages 表分区

```sql
-- 按月分区 (根据数据量决定)
CREATE TABLE messages_2024_01 PARTITION OF messages
    FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');

-- 或使用 TimescaleDB 扩展
CREATE EXTENSION IF NOT EXISTS timescaledb;
SELECT create_hypertable('messages', 'created_at');
```

### 4.2 skills_usage 表分区

```sql
-- 同样建议按月分区
SELECT create_hypertable('skills_usage', 'created_at');
```

## 5. RLS (Row Level Security) 策略

```sql
-- 启用 RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE portfolios ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE memories ENABLE ROW LEVEL SECURITY;

-- 用户只能看到自己的数据
CREATE POLICY user_isolation ON users
    FOR ALL
    USING (auth.uid() = user_id);

-- 类似策略应用到其他表
CREATE POLICY portfolio_isolation ON portfolios
    FOR ALL
    USING (auth.uid() = user_id);
```
