# StockAI 2.0 ID 系统设计

## 1. ID 类型定义

### 1.1 核心 ID 一览表

| ID 名称 | 格式 | 生成方式 | 用途 | 示例 |
|---------|------|---------|------|------|
| `wechat_id` | `wxid_` + 16位随机字符 | 微信分配 | 微信用户唯一标识 | `wxid_abc123def456ghi7` |
| `channel_id` | 字符串常量 | 系统配置 | 区分微信频道 | `wechat_main` / `wechat_test` |
| `user_id` | UUID v4 | 系统生成 | 系统内部用户标识 | `a1b2c3d4-e5f6-7890-abcd-ef1234567890` |
| `agent_id` | UUID v4 | 系统生成 | Client Agent 标识 | `b2c3d4e5-f6a7-8901-bcde-f23456789012` |

### 1.2 关键问题回答

#### Q1: user_id 到底是什么？

**回答**: `user_id` 是系统内部生成的 **UUID**，与微信 ID 完全解耦。

```
┌─────────────────────────────────────────────────────────────┐
│  为什么不用 wechat_id 作为 user_id？                         │
├─────────────────────────────────────────────────────────────┤
│  1. 平台无关性                                                │
│     • 未来可能支持 Telegram/Discord/WhatsApp               │
│     • 用户可能更换微信账号                                   │
│                                                              │
│  2. 多账号支持                                                │
│     • 一个 user_id 可绑定多个 wechat_id                     │
│     • 同一个用户从不同渠道接入视为同一用户                   │
│                                                              │
│  3. 隐私和安全                                                │
│     • 内部系统不暴露微信原始 ID                              │
│     • wechat_id 只存储在绑定表中                             │
└─────────────────────────────────────────────────────────────┘
```

#### Q2: 两个微信频道怎么区分？

**回答**: 通过 `channel_id` 字符串常量区分。

```python
# 配置定义
CHANNEL_CONFIG = {
    "wechat_main": {
        "name": "StockAI主号",
        "webhook_url": "https://gateway.openclaw.com/webhook/wechat/main",
        "enabled": True,
        "is_production": True
    },
    "wechat_test": {
        "name": "StockAI测试号", 
        "webhook_url": "https://gateway.openclaw.com/webhook/wechat/test",
        "enabled": True,
        "is_production": False
    }
}
```

**重要**: `wechat_id` + `channel_id` 才能唯一确定一个微信账号身份。
- 同一个微信号 `wxid_abc` 从两个频道发消息 → 识别为同一人
- 两个不同的微信号分别从两个频道发消息 → 识别为两个人

## 2. ID 生成策略

### 2.1 UUID 生成 (PostgreSQL)

```sql
-- 使用 pgcrypto 扩展
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- user_id 生成
-- DEFAULT gen_random_uuid()

-- 或者使用自定义前缀 (可选)
CREATE OR REPLACE FUNCTION generate_user_id()
RETURNS UUID AS $$
BEGIN
    RETURN gen_random_uuid();
END;
$$ LANGUAGE plpgsql;
```

### 2.2 Python 端生成

```python
import uuid
from datetime import datetime

def generate_user_id() -> str:
    """生成用户 ID"""
    return str(uuid.uuid4())

def generate_agent_id() -> str:
    """生成 Agent ID"""
    return str(uuid.uuid4())

def generate_short_id(prefix: str = "") -> str:
    """生成短 ID (用于调试/日志)"""
    # 取 UUID 前 8 位 + 时间戳后 4 位
    ts = str(int(datetime.now().timestamp()))[-4:]
    uid = uuid.uuid4().hex[:8]
    return f"{prefix}{uid}{ts}" if prefix else f"{uid}{ts}"

# 使用示例
user_id = generate_user_id()      # "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
agent_id = generate_agent_id()    # "b2c3d4e5-f6a7-8901-bcde-f23456789012"
short = generate_short_id("usr_") # "usr_a1b2c3d47890"
```

## 3. ID 关联关系

### 3.1 关系图

```
                    ┌─────────────────────────────────────────┐
                    │           Identity Resolution           │
                    │          (身份识别服务)                  │
                    └───────────────────┬─────────────────────┘
                                        │
           ┌────────────────────────────┼────────────────────────────┐
           │                            │                            │
           ▼                            ▼                            ▼
┌──────────────────────┐    ┌──────────────────────┐    ┌──────────────────────┐
│   wechat_bindings    │    │       users          │    │       agents         │
│  ┌────────────────┐  │    │  ┌────────────────┐  │    │  ┌────────────────┐  │
│  │ wechat_id      │  │    │  │ user_id (PK)   │◀─┼────┼──│ user_id (FK)   │  │
│  │ channel_id     │  │───▶│  │ nickname       │  │    │  │ agent_id (PK)  │  │
│  │ user_id (FK)   │──┘    │  │ profile        │  │───▶│  │ config         │  │
│  │ is_primary     │       │  │ created_at     │  │    │  │ status         │  │
│  └────────────────┘       │  └────────────────┘  │    │  └────────────────┘  │
└──────────────────────┘    └──────────────────────┘    └──────────────────────┘
           │                                                        │
           │              ┌─────────────────────────┐               │
           │              │    唯一性约束说明        │               │
           │              ├─────────────────────────┤               │
           └─────────────▶│ users.user_id: UNIQUE   │◀──────────────┘
                          │ agents.agent_id: UNIQUE │
                          │ agents.user_id: UNIQUE  │ (1:1 关系)
                          │ wechat_bindings:        │
                          │   (wechat_id, channel_id) UNIQUE
                          └─────────────────────────┘
```

### 3.2 识别逻辑伪代码

```python
async def resolve_identity(wechat_id: str, channel_id: str) -> IdentityResult:
    """
    身份识别核心逻辑
    
    输入: wechat_id + channel_id
    输出: 识别结果 (新用户 / 老用户)
    """
    
    # 1. 查询绑定表
    binding = await db.wechat_bindings.find_unique(
        where={
            "wechat_id_channel_id": {
                "wechat_id": wechat_id,
                "channel_id": channel_id
            }
        }
    )
    
    if binding:
        # 老用户: 返回 user_id
        return IdentityResult(
            is_new_user=False,
            user_id=binding.user_id,
            wechat_id=wechat_id,
            channel_id=channel_id
        )
    
    # 2. 检查是否从其他频道已知此用户
    other_bindings = await db.wechat_bindings.find_many(
        where={"wechat_id": wechat_id}
    )
    
    if other_bindings:
        # 同一微信用户从其他频道发消息
        # 可选择: A) 自动绑定到新频道  B) 引导用户确认
        existing_user_id = other_bindings[0].user_id
        
        # 策略A: 自动绑定
        await db.wechat_bindings.create({
            "wechat_id": wechat_id,
            "channel_id": channel_id,
            "user_id": existing_user_id,
            "is_primary": False
        })
        
        return IdentityResult(
            is_new_user=False,
            user_id=existing_user_id,
            wechat_id=wechat_id,
            channel_id=channel_id,
            is_cross_channel=True
        )
    
    # 3. 全新用户
    return IdentityResult(
        is_new_user=True,
        user_id=None,
        wechat_id=wechat_id,
        channel_id=channel_id
    )
```

## 4. 多频道用户识别方案

### 4.1 方案对比

| 方案 | 描述 | 优点 | 缺点 | 推荐度 |
|-----|------|------|------|--------|
| **方案A** | 相同 wxid 自动识别为同一人 | 用户体验好，无感知 | 需要用户授权确认 | ⭐⭐⭐⭐⭐ |
| 方案B | 每个频道视为独立用户 | 实现简单 | 用户需要重复注册 | ⭐⭐ |
| 方案C | 通过手机号绑定关联 | 准确可靠 | 需要收集敏感信息 | ⭐⭐⭐ |

### 4.2 推荐方案: 方案A + 用户确认

```
┌─────────────────────────────────────────────────────────────────────┐
│  跨频道用户识别流程                                                   │
└─────────────────────────────────────────────────────────────────────┘

第一次 (主号):
┌──────────┐      ┌──────────────┐      ┌──────────────┐
│ wxid_abc │─────▶│  wechat_main │─────▶│  注册新用户   │
│ 用户A     │      │  首次出现     │      │  user_id: u1 │
└──────────┘      └──────────────┘      └──────────────┘

第二次 (测试号):
┌──────────┐      ┌──────────────┐      ┌──────────────────┐
│ wxid_abc │─────▶│  wechat_test │─────▶│ 检测到已有用户   │
│ 用户A     │      │  首次出现     │      │  user_id: u1     │
└──────────┘      └──────────────┘      └────────┬─────────┘
                                                  │
                                                  ▼
                              ┌───────────────────────────────────┐
                              │  发送确认消息:                     │
                              │  "检测到您在 StockAI主号 已有账号  │
                              │   是否将此微信绑定到同一账号?"      │
                              │                                   │
                              │  [确认绑定]  [创建新账号]          │
                              └───────────────────────────────────┘
```

## 5. ID 在代码中的使用

### 5.1 数据模型定义

```python
from dataclasses import dataclass
from typing import Optional
from datetime import datetime

# ============ ID 类型别名 (用于类型提示) ============
WechatId = str       # 格式: "wxid_xxx"
ChannelId = str      # 格式: "wechat_main" | "wechat_test"
UserId = str         # 格式: UUID string
AgentId = str        # 格式: UUID string
MessageId = str      # 格式: UUID string

# ============ 核心数据模型 ============

@dataclass
class WechatIdentity:
    """微信身份标识"""
    wechat_id: WechatId
    channel_id: ChannelId
    
    @property
    def composite_key(self) -> str:
        """复合键: 用于数据库查询"""
        return f"{self.wechat_id}:{self.channel_id}"

@dataclass
class User:
    """用户实体"""
    user_id: UserId
    nickname: str
    created_at: datetime
    # 关联的微信身份列表
    wechat_bindings: list[WechatIdentity]
    
    def has_wechat(self, wechat_id: WechatId) -> bool:
        """检查是否已绑定指定微信"""
        return any(b.wechat_id == wechat_id for b in self.wechat_bindings)

@dataclass
class ClientAgent:
    """Client Agent 实体"""
    agent_id: AgentId
    user_id: UserId          # 外键: 所属用户
    agent_name: str
    status: str              # "running" | "stopped" | "error"
    config: dict
    created_at: datetime
    
    @property
    def display_name(self) -> str:
        """显示名称"""
        return self.agent_name or f"StockAI_{self.user_id[:8]}"
```

### 5.2 ID 验证工具

```python
import re
from uuid import UUID

class IDValidator:
    """ID 格式验证器"""
    
    WECHAT_ID_PATTERN = re.compile(r'^wxid_[a-zA-Z0-9]{16,24}$')
    CHANNEL_IDS = {'wechat_main', 'wechat_test'}
    
    @classmethod
    def is_valid_wechat_id(cls, wechat_id: str) -> bool:
        """验证微信 ID 格式"""
        return bool(cls.WECHAT_ID_PATTERN.match(wechat_id))
    
    @classmethod
    def is_valid_channel_id(cls, channel_id: str) -> bool:
        """验证频道 ID 是否有效"""
        return channel_id in cls.CHANNEL_IDS
    
    @classmethod
    def is_valid_uuid(cls, id_str: str) -> bool:
        """验证 UUID 格式"""
        try:
            UUID(id_str)
            return True
        except ValueError:
            return False
    
    @classmethod
    def validate_all(cls, wechat_id: str, channel_id: str, user_id: Optional[str] = None):
        """验证所有 ID"""
        if not cls.is_valid_wechat_id(wechat_id):
            raise ValueError(f"Invalid wechat_id: {wechat_id}")
        
        if not cls.is_valid_channel_id(channel_id):
            raise ValueError(f"Invalid channel_id: {channel_id}")
        
        if user_id and not cls.is_valid_uuid(user_id):
            raise ValueError(f"Invalid user_id: {user_id}")
        
        return True
```

## 6. 路由决策流程

### 6.1 完整路由逻辑

```
┌─────────────────────────────────────────────────────────────────────┐
│                         消息路由决策树                               │
└─────────────────────────────────────────────────────────────────────┘

                         收到消息
                            │
                            ▼
                    ┌───────────────┐
                    │ 提取身份信息   │
                    │ wechat_id     │
                    │ channel_id    │
                    └───────┬───────┘
                            │
                            ▼
                    ┌───────────────┐
                    │ 查询绑定表     │
                    │ 是否存在记录?  │
                    └───────┬───────┘
                            │
               ┌────────────┴────────────┐
               │是                        │否
               ▼                          ▼
        ┌───────────────┐          ┌───────────────┐
        │ 获取 user_id  │          │ 查询其他频道   │
        │ 查询 agents 表 │          │ 是否有相同wxid │
        │ 获取 agent_id │          └───────┬───────┘
        └───────┬───────┘                  │
                │               ┌──────────┴──────────┐
                │               │是                   │否
                │               ▼                     ▼
                │      ┌───────────────┐      ┌───────────────┐
                │      │ 发送确认消息   │      │ 启动新用户流程 │
                │      │ 等待用户选择   │      │ onboarding    │
                │      └───────┬───────┘      └───────────────┘
                │              │
                │    ┌─────────┴─────────┐
                │    │绑定到现有         │创建新用户
                └────┤     │             │
                     │     │             │
                     ▼     ▼             ▼
              ┌───────────────────────────────────────┐
              │           路由到 Client Agent         │
              │                                        │
              │  参数:                                  │
              │    • user_id                           │
              │    • agent_id                          │
              │    • message                           │
              │    • context: {                        │
              │        wechat_id,                      │
              │        channel_id,                     │
              │        timestamp                       │
              │    }                                   │
              └───────────────────────────────────────┘
```

### 6.2 路由代码实现

```python
class MessageRouter:
    """消息路由器"""
    
    def __init__(self, db, agent_manager):
        self.db = db
        self.agent_manager = agent_manager
    
    async def route(self, wechat_id: str, channel_id: str, message: str) -> RouteResult:
        """
        核心路由方法
        """
        # 1. 验证 ID
        IDValidator.validate_all(wechat_id, channel_id)
        
        # 2. 身份识别
        identity = await self.resolve_identity(wechat_id, channel_id)
        
        if identity.is_new_user:
            # 新用户: 启动 onboarding
            return await self._handle_new_user(wechat_id, channel_id, message)
        
        # 3. 获取或创建 Agent
        agent = await self._get_or_create_agent(identity.user_id)
        
        # 4. 路由消息
        return await self._route_to_agent(
            agent_id=agent.agent_id,
            user_id=identity.user_id,
            wechat_id=wechat_id,
            channel_id=channel_id,
            message=message
        )
    
    async def _get_or_create_agent(self, user_id: UserId) -> ClientAgent:
        """获取或创建用户的 Client Agent"""
        agent = await self.db.agents.find_unique(where={"user_id": user_id})
        
        if agent:
            # 确保 Agent 在运行
            if agent.status != "running":
                await self.agent_manager.start_agent(agent.agent_id)
            return agent
        
        # 创建新 Agent (不应该走到这里，新用户应该在 onboarding 时创建)
        raise AgentNotFoundError(f"Agent not found for user: {user_id}")
```

## 7. 索引设计

### 7.1 数据库索引

```sql
-- 用户查询优化
CREATE UNIQUE INDEX idx_users_user_id ON users(user_id);

-- 微信绑定查询 (核心索引)
CREATE UNIQUE INDEX idx_bindings_composite ON wechat_bindings(wechat_id, channel_id);
CREATE INDEX idx_bindings_user ON wechat_bindings(user_id);
CREATE INDEX idx_bindings_wechat ON wechat_bindings(wechat_id);

-- Agent 查询
CREATE UNIQUE INDEX idx_agents_agent_id ON agents(agent_id);
CREATE UNIQUE INDEX idx_agents_user ON agents(user_id);
CREATE INDEX idx_agents_status ON agents(status);

-- 消息查询
CREATE INDEX idx_messages_user_time ON messages(user_id, created_at DESC);
CREATE INDEX idx_messages_channel ON messages(channel_id, created_at DESC);
```

## 8. 总结

### 8.1 核心设计原则

1. **wechat_id ≠ user_id** - 保持平台无关性
2. **wechat_id + channel_id 唯一** - 一个微信账号在每个频道是独立身份
3. **user_id 全局唯一** - 一个用户可以绑定多个微信账号
4. **agent_id 与 user_id 1:1** - 每个用户对应一个专属 Client Agent

### 8.2 验证清单

| 问题 | 答案 |
|-----|------|
| user_id 是什么？ | 系统生成的 UUID，与微信 ID 解耦 |
| 两个微信频道怎么区分？ | 通过 channel_id 常量区分 |
| 相同微信用户从两个频道发消息？ | 识别为同一人，可选择绑定或创建新账号 |
| Client Agent 如何知道用户是谁？ | 通过 user_id 查询用户数据和记忆 |
| 如何查询用户绑定了哪些微信？ | 通过 wechat_bindings 表关联查询 |
