"""
StockAI 2.0 - Main Agent 路由模块
===============================
负责消息入口、身份识别、路由决策
"""

import time
import logging
from typing import Dict, Any, Optional
from datetime import datetime

from database import DatabaseManager, get_db
from models import RoutingResult, WechatWebhookRequest, WechatWebhookResponse
from services.user_service import UserService, IdentityService
from services.agent_service import AgentService
from services.onboarding_service import OnboardingService

logger = logging.getLogger(__name__)


class MainRouter:
    """
    Main Agent 路由器
    
    职责：
    1. 接收所有微信消息入口
    2. 识别用户身份（新用户/老用户）
    3. 路由消息到新用户流程或 Client Agent
    4. 统一错误处理和响应格式化
    """
    
    def __init__(self, db: DatabaseManager = None):
        self.db = db or get_db()
        self.identity_service = IdentityService(db)
        self.user_service = UserService(db)
        self.agent_service = AgentService(db)
        self.onboarding_service = OnboardingService(db, self.agent_service)
    
    def handle_message(self, wechat_id: str, channel_id: str,
                       message: str, message_type: str = "text",
                       metadata: Dict[str, Any] = None) -> RoutingResult:
        """
        处理微信消息入口 - 核心方法
        
        Args:
            wechat_id: 微信用户ID (如: wxid_xxx)
            channel_id: 频道标识 ('wechat_main' | 'wechat_test')
            message: 消息内容文本
            message_type: 消息类型 ('text' | 'image' | 'voice' | 'file')
            metadata: 额外元数据 (timestamp, msg_id等)
            
        Returns:
            RoutingResult: 路由结果
        """
        start_time = time.time()
        metadata = metadata or {}
        
        try:
            # 1. 记录消息
            message_id = self._record_incoming_message(
                wechat_id, channel_id, message, message_type, metadata
            )
            
            # 2. 识别用户身份
            identity = self.identity_service.identify_user(wechat_id, channel_id)
            
            # 检查是否在问卷中（即使身份不存在，也可能正在问卷流程中）
            onboarding_state = self.onboarding_service.get_onboarding_state_by_wechat(
                wechat_id, channel_id
            )
            
            if onboarding_state and not onboarding_state.is_complete:
                # 用户正在完成问卷
                logger.info(f"User in onboarding: wechat_id={wechat_id}")
                return self._handle_onboarding(wechat_id, channel_id, message, None)
            
            if not identity.exists:
                # 新用户 - 启动问卷流程
                logger.info(f"New user detected, starting onboarding: {wechat_id}")
                return self._handle_new_user(wechat_id, channel_id, message, message_id)
            
            # 老用户 - 路由到 Client Agent
            user_id = identity.user_id
            agent_id = identity.agent_id
            if not agent_id:
                # 用户存在但 Agent 不存在，需要创建
                logger.warning(f"User exists but no agent: user_id={user_id}")
                agent_result = self.agent_service.create_client_agent(user_id)
                if not agent_result.success:
                    return RoutingResult(
                        success=False,
                        action="error",
                        error_code="AGENT_CREATION_FAILED",
                        reason=agent_result.message
                    )
                agent_id = agent_result.agent_id
            
            logger.info(f"Routing to client agent: user_id={user_id}, agent_id={agent_id}")
            return self._route_to_agent(
                agent_id, user_id, wechat_id, channel_id, message, message_id
            )
            
        except Exception as e:
            logger.error(f"Message handling failed: {e}")
            return RoutingResult(
                success=False,
                action="error",
                error_code="INTERNAL_ERROR",
                reason=str(e)
            )
    
    def _record_incoming_message(self, wechat_id: str, channel_id: str,
                                  message: str, message_type: str,
                                  metadata: Dict[str, Any]) -> Optional[str]:
        """记录 incoming 消息"""
        try:
            # 尝试获取用户ID
            identity = self.identity_service.identify_user(wechat_id, channel_id)
            
            if not identity.exists:
                # 新用户，还未创建账号，跳过记录或创建临时记录
                # 不记录消息，等用户创建后再记录
                return None
            
            # 记录消息
            message_id = self.db.record_message(
                user_id=identity.user_id,
                channel_id=channel_id,
                wechat_id=wechat_id,
                direction='inbound',
                content=message,
                message_type=message_type
            )
            return message_id
        except Exception as e:
            logger.error(f"Record message failed: {e}")
            return None
    
    def _handle_new_user(self, wechat_id: str, channel_id: str,
                         message: str, message_id: str) -> RoutingResult:
        """
        处理新用户
        
        触发问卷流程
        """
        try:
            # 开始问卷
            onboarding_result = self.onboarding_service.start_onboarding(
                wechat_id, channel_id
            )
            
            progress_id = onboarding_result["progress_id"]
            first_question = onboarding_result["first_question"]
            welcome_message = onboarding_result["welcome_message"]
            
            # 如果消息不是常见触发词，将其作为第一个答案保存
            trigger_words = ["开始", "你好", "hi", "hello", "问卷", "注册"]
            if message.strip() not in trigger_words:
                save_result = self.onboarding_service.save_answer(progress_id, message)
                
                # 如果只有一个答案就完成了（不太可能，但以防万一）
                if save_result.get("is_complete"):
                    return self._complete_onboarding_and_create_user(
                        progress_id, message, message_id
                    )
                
                # 获取下一个问题
                next_question = save_result.get("next_question")
                if next_question:
                    first_question = next_question
                    welcome_message = None  # 已经回答了第一个问题，不需要欢迎语了
            
            # 构建回复
            response = self._format_question_response(
                welcome_message, first_question
            )
            
            return RoutingResult(
                success=True,
                action="start_onboarding",
                response=response,
                reason="New user detected, starting onboarding"
            )
            
        except Exception as e:
            logger.error(f"Handle new user failed: {e}")
            return RoutingResult(
                success=False,
                action="error",
                error_code="ONBOARDING_START_FAILED",
                reason=str(e)
            )
    
    def _complete_onboarding_and_create_user(self, progress_id: str,
                                              message: str, message_id: str) -> RoutingResult:
        """完成问卷并创建用户"""
        complete_result = self.onboarding_service.complete_onboarding(progress_id)
        
        if not complete_result.success:
            return RoutingResult(
                success=False,
                action="error",
                error_code="ONBOARDING_COMPLETE_FAILED",
                reason=complete_result.error
            )
        
        # 构建完成消息
        response = (
            "🎉 恭喜！您的专属投资助手已创建完成！\n\n"
            f"Agent ID: {complete_result.agent_id}\n"
            "现在您可以开始查询股票了，比如：\n"
            "• 帮我分析一下贵州茅台\n"
            "• 查看我的自选股\n"
            "• 今天大盘怎么样\n\n"
            "⏱️ 回复耗时：实时"
        )
        
        return RoutingResult(
            success=True,
            action="route_to_client",
            user_id=complete_result.user_id,
            target_agent_id=complete_result.agent_id,
            response=response,
            reason="Onboarding completed, client agent created"
        )
    
    def _handle_onboarding(self, wechat_id: str, channel_id: str,
                           message: str, user_id: str = None) -> RoutingResult:
        """
        处理问卷中的用户
        
        保存答案并继续下一个问题
        """
        try:
            # 获取进行中的问卷
            progress = self.db.get_onboarding_by_wechat(wechat_id, channel_id)
            if not progress:
                # 问卷记录丢失，重新开始
                return self._handle_new_user(wechat_id, channel_id, message, None)
            
            progress_id = progress['progress_id']
            
            # 保存答案
            save_result = self.onboarding_service.save_answer(progress_id, message)
            
            if not save_result["success"]:
                return RoutingResult(
                    success=False,
                    action="error",
                    error_code="ANSWER_SAVE_FAILED",
                    reason=save_result.get("error", "Unknown error")
                )
            
            # 检查是否完成
            if save_result["is_complete"]:
                # 完成问卷，创建用户和Agent
                complete_result = self.onboarding_service.complete_onboarding(progress_id)
                
                if not complete_result.success:
                    return RoutingResult(
                        success=False,
                        action="error",
                        error_code="ONBOARDING_COMPLETE_FAILED",
                        reason=complete_result.error
                    )
                
                # 构建完成消息
                response = (
                    "🎉 恭喜！您的专属投资助手已创建完成！\n\n"
                    f"Agent ID: {complete_result.agent_id}\n"
                    "现在您可以开始查询股票了，比如：\n"
                    "• 帮我分析一下贵州茅台\n"
                    "• 查看我的自选股\n"
                    "• 今天大盘怎么样\n\n"
                    "⏱️ 回复耗时：实时"
                )
                
                return RoutingResult(
                    success=True,
                    action="route_to_client",
                    user_id=complete_result.user_id,
                    target_agent_id=complete_result.agent_id,
                    response=response,
                    reason="Onboarding completed, client agent created"
                )
            
            # 继续下一个问题
            next_question = save_result["next_question"]
            response = self._format_question_response(None, next_question)
            
            return RoutingResult(
                success=True,
                action="continue_onboarding",
                response=response,
                reason=f"Question answered, progress: {save_result['progress']}"
            )
            
        except Exception as e:
            logger.error(f"Handle onboarding failed: {e}")
            return RoutingResult(
                success=False,
                action="error",
                error_code="ONBOARDING_ERROR",
                reason=str(e)
            )
    
    def _route_to_agent(self, agent_id: str, user_id: str, wechat_id: str,
                        channel_id: str, message: str, message_id: str) -> RoutingResult:
        """
        将消息路由到 Client Agent
        """
        try:
            # 准备上下文
            context = {
                "user_id": user_id,
                "wechat_id": wechat_id,
                "channel_id": channel_id,
                "message_id": message_id,
                "timestamp": int(time.time())
            }
            
            # 路由消息
            route_result = self.agent_service.route_to_agent(
                agent_id=agent_id,
                message=message,
                context=context
            )
            
            if route_result.status == "error":
                return RoutingResult(
                    success=False,
                    action="error",
                    error_code=route_result.error_code or "ROUTE_FAILED",
                    reason=route_result.error
                )
            
            # 记录路由日志
            self.db.log_routing(
                user_id=user_id,
                routing_type="rule",
                input_content=message,
                intent="client_message",
                confidence=1.0,
                target_agent_id=agent_id,
                message_id=message_id
            )
            
            return RoutingResult(
                success=True,
                action="route_to_client",
                user_id=user_id,
                target_agent_id=agent_id,
                response=route_result.response,  # 可能是 None，由 Client Agent 异步回复
                reason="Message routed to client agent"
            )
            
        except Exception as e:
            logger.error(f"Route to agent failed: {e}")
            return RoutingResult(
                success=False,
                action="error",
                error_code="ROUTE_ERROR",
                reason=str(e)
            )
    
    def _format_question_response(self, welcome_message: Optional[str],
                                   question: Dict[str, Any]) -> str:
        """格式化问题回复"""
        lines = []
        
        if welcome_message:
            lines.append(welcome_message)
            lines.append("")
        
        lines.append(f"📋 问题 {question.get('progress', '')}")
        lines.append(question['question_text'])
        
        # 添加选项
        if question.get('options'):
            lines.append("")
            for i, opt in enumerate(question['options'], 1):
                lines.append(f"  {i}. {opt['label']}")
        
        # 添加提示
        if question.get('hint'):
            lines.append("")
            lines.append(f"💡 {question['hint']}")
        
        return "\n".join(lines)
    
    def health_check(self) -> Dict[str, Any]:
        """
        服务健康检查
        
        Returns:
            健康状态字典
        """
        try:
            # 检查数据库
            db_healthy = True
            try:
                self.db.get_user_account("test")
            except:
                db_healthy = False
            
            # 检查各服务
            services = {
                "identity_service": True,
                "agent_manager": True,
                "onboarding_service": True,
                "database": db_healthy
            }
            
            all_healthy = all(services.values())
            
            return {
                "status": "healthy" if all_healthy else "degraded",
                "version": "2.0.0",
                "services": services,
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return {
                "status": "unhealthy",
                "version": "2.0.0",
                "services": {},
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    # ============ Webhook 接口 ============
    
    def handle_webhook(self, request: WechatWebhookRequest) -> WechatWebhookResponse:
        """
        处理 Webhook 请求
        
        Args:
            request: Webhook 请求
            
        Returns:
            Webhook 响应
        """
        start_time = time.time()
        
        result = self.handle_message(
            wechat_id=request.wechat_id,
            channel_id=request.channel_id,
            message=request.message,
            message_type=request.message_type,
            metadata=request.metadata or {}
        )
        
        processing_time = int((time.time() - start_time) * 1000)
        
        return WechatWebhookResponse(
            success=result.success,
            action=result.action,
            response=result.response,
            processing_time_ms=processing_time,
            error=result.error_code
        )


# 为 OnboardingService 添加一个辅助方法
def _patch_onboarding_service():
    """为 OnboardingService 添加 get_onboarding_state_by_wechat 方法"""
    def get_onboarding_state_by_wechat(self, wechat_id: str, channel_id: str = "wechat_main"):
        progress = self.db.get_onboarding_by_wechat(wechat_id, channel_id)
        if progress:
            return self.get_onboarding_state(progress['progress_id'])
        return None
    
    OnboardingService.get_onboarding_state_by_wechat = get_onboarding_state_by_wechat


_patch_onboarding_service()


if __name__ == "__main__":
    print("=== Main Router 模块测试 ===")
    
    from database import DatabaseManager
    import tempfile
    
    # 使用内存数据库测试
    test_db = DatabaseManager(":memory:")
    test_dir = tempfile.mkdtemp()
    
    # 更新 AgentService 的 clients_dir
    from services.agent_service import AgentService
    AgentService.CLIENTS_DIR = test_dir
    
    router = MainRouter(test_db)
    
    # 测试新用户
    print("\n1. 测试新用户消息...")
    result = router.handle_message(
        wechat_id="wxid_new_user",
        channel_id="wechat_main",
        message="你好"
    )
    print(f"   结果: {result.action}")
    print(f"   回复: {result.response[:100]}...")
    
    # 测试回答问题
    print("\n2. 测试回答问题...")
    for i, answer in enumerate(["张三", "无", "3", "2", "1", "1,2"]):
        result = router.handle_message(
            wechat_id="wxid_new_user",
            channel_id="wechat_main",
            message=answer
        )
        print(f"   答案 {i+1}: {answer} -> {result.action}")
        if result.action == "route_to_client":
            print(f"   用户创建成功！")
            print(f"   回复: {result.response[:200]}...")
            break
    
    # 测试老用户
    print("\n3. 测试老用户消息...")
    result = router.handle_message(
        wechat_id="wxid_new_user",  # 现在已是老用户
        channel_id="wechat_main",
        message="帮我分析贵州茅台"
    )
    print(f"   结果: {result.action}")
    print(f"   用户ID: {result.user_id}")
    print(f"   AgentID: {result.target_agent_id}")
    
    # 测试健康检查
    print("\n4. 测试健康检查...")
    health = router.health_check()
    print(f"   状态: {health['status']}")
    print(f"   服务: {health['services']}")
    
    print("\n✅ Main Router 模块测试通过")
    
    # 清理
    import shutil
    shutil.rmtree(test_dir)
