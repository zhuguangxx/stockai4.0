# R720 服务器完整信息档案

**最后更新**: 2026-04-05
**用途**: 004部署前现状整理

---

## 一、SSH访问信息

### 1.1 当前认证方式
| 项目 | 值 | 说明 |
|------|-----|------|
| **Host** | `nas.ayfans.com` | 域名访问 |
| **IP** | (通过域名解析) | 动态IP，使用域名稳定 |
| **Port** | `8822` | 非标准SSH端口 |
| **User** | `root` | 管理员账户 |
| **认证方式** | **密码认证** | 当前未配置SSH Key |
| **Password** | `xiaming` | 明文密码 |

### 1.2 SSH密钥对状态
**当前状态**: ❌ **未配置SSH Key登录**

```bash
# 当前登录方式
ssh root@nas.ayfans.com -p 8822
# 提示输入密码: xiaming

# 检查是否已有密钥
ls -la ~/.ssh/authorized_keys  # 待确认是否存在
```

**建议**: 004部署后配置SSH Key，提升安全性
```bash
# 生成密钥对（在本地执行）
ssh-keygen -t ed25519 -C "stockai-r720"

# 复制公钥到R720
ssh-copy-id -p 8822 root@nas.ayfans.com
```

---

## 二、Timeshift快照信息

### 2.1 快照位置
```
/run/timeshift/backup/timeshift-btrfs/snapshots/
```

### 2.2 可用快照
| 快照名称 | 创建时间 | 系统状态 | 回滚建议 |
|----------|----------|----------|----------|
| `2026-04-03_10-22-41` | 2026-04-03 10:22 | **纯净Ubuntu** | ⭐ **推荐回滚到此** |
| `2026-04-03_13-37-47` | 2026-04-03 13:37 | node+openclaw+微信+python | 备选（如纯净快照有问题） |

### 2.3 回滚命令
```bash
# 查看可用快照
sudo timeshift --list

# 回滚到纯净系统（推荐）
sudo timeshift --restore --snapshot '2026-04-03_10-22-41'

# 重启
sudo reboot
```

---

## 三、五年股票数据库

### 3.1 当前位置
| 路径 | 大小 | 说明 |
|------|------|------|
| `/data/stockai/db/stock.db` | 668MB | **主数据库**（软链接） |
| `/data/stock_backup_20260404_115657.db` | 638MB | 备份原文件 |

### 3.2 数据库状态（来自诊断报告）
```
✅ 数据完整性: 正常
✅ 记录数: 6,426,821 条K线数据
✅ 覆盖股票: 7,074 只
✅ 时间范围: 5年历史数据
```

### 3.3 回滚保护
**重要**: Timeshift回滚可能影响 `/data` 目录
```bash
# 回滚前必须备份
sudo cp /data/stockai/db/stock.db /data/stock.db.backup-004-deploy

# 回滚后检查
ls -lh /data/stockai/db/stock.db

# 如丢失，恢复
sudo cp /data/stock.db.backup-004-deploy /data/stockai/db/stock.db
```

---

## 四、环境信息（当前003版本）

### 4.1 操作系统
```
OS: Ubuntu 24.04 LTS
Hostname: stockaiserver
Kernel: 6.8.0-71-generic
Arch: x86_64
```

### 4.2 Node.js
```
Version: v22.22.2
Install: 二进制安装 (/usr/local/bin/node)
Status: ✅ 运行中
```

### 4.3 OpenClaw
```
Version: 2026.4.1
Gateway: 127.0.0.1:18789
Status: ✅ active (running)
Config: ~/.openclaw/openclaw.json
```

### 4.4 微信插件
```
Service: wechat_server.py
Port: 127.0.0.1:18080
Status: ✅ 运行中
Binding: 已绑定（通过openclaw-weixin通道）
```

### 4.5 Python环境
```
Version: Python 3.12
Key packages:
  - pandas (数据处理)
  - sqlite3 (数据库)
  - requests (HTTP)
  - baostock (股票数据)
```

---

## 五、当前部署结构（003版本）

```
/data/stockai/                    # 003版本主目录
├── 01-cloud-platform/
│   └── api/                      # API服务
├── core/                         # 核心模块
│   ├── experts.py               # 六大专家
│   ├── indicators.py            # 技术指标
│   └── analyzer.py              # 分析器
├── backtest/                     # 回测模块（未接入）
│   ├── engine.py
│   └── portfolio_engine.py
├── skills/                       # Skill模块
│   ├── menu/handler.py          # 菜单（仅占位）
│   ├── analyzer/main.py         # 分析（重复菜单）
│   └── weixin-login/            # 微信登录
├── data/
│   └── stock.db -> /data/stockai/db/stock.db  # 软链接
└── wechat_server.py             # 微信服务

/opt/stockai/                     # 可能是另一个版本（待确认）
```

---

## 六、004部署后结构（规划）

```
/opt/stockai4.0/                  # 004版本主目录
├── src/                          # 源码
│   ├── entry.py                 # Gateway入口
│   ├── router.py                # 消息路由（含菜单功能）
│   └── services/                # 服务层
│       ├── identity.py
│       ├── onboarding.py
│       ├── user_memory.py
│       ├── stock_analysis.py
│       ├── subagent_dispatcher.py
│       └── indicator_detail.py  # 新增：指标详情
├── core/                         # 从003复制
│   ├── experts.py
│   ├── indicators.py
│   └── analyzer.py
├── backtest/                     # 从003复制
│   ├── engine.py
│   ├── portfolio_engine.py
│   └── report.py
├── strategies/                   # 新增
│   └── macd_strategy.py         # MACD回测策略
├── data/
│   └── stockai.db               # 用户数据库（新）
├── config/
│   └── openclaw-r720.json       # OpenClaw配置
├── scripts/
│   └── init_db_r720.py          # 数据库初始化
└── docs/                         # 文档

/data/stockai/db/stock.db        # 五年数据（共用，只读）
```

---

## 七、关键端口

| 服务 | 端口 | 状态 | 004变化 |
|------|------|------|---------|
| OpenClaw Gateway | 18789 | ✅ | 不变 |
| 微信Server | 18080 | ✅ | 不变 |
| StockAI API | 8000 | ✅ | 可能弃用 |
| SSH | 8822 | ✅ | 不变 |

---

## 八、部署前检查清单

### 8.1 必须备份
- [ ] `/data/stockai/db/stock.db` → `/data/stock.db.backup`
- [ ] `~/.openclaw/openclaw.json` → `~/openclaw.json.backup`
- [ ] `/data/stockai/` → `/data/stockai-backup-003.tar.gz`

### 8.2 回滚后需重新安装（如回滚到纯净快照）
- [ ] Node.js v22
- [ ] OpenClaw 2026.4.1
- [ ] 微信插件
- [ ] Python依赖包

### 8.3 回滚后保持不变（数据盘）
- [ ] `/data/stockai/db/stock.db`（需验证）
- [ ] `/data/stock_backup*.db`

---

## 九、风险与应对

| 风险 | 可能性 | 应对措施 |
|------|--------|----------|
| 回滚丢失五年数据库 | 中 | 预先备份到 `/data/stock.db.backup` |
| 回滚后网络配置丢失 | 低 | 记录当前网络配置 |
| 微信绑定失效 | 中 | 重新执行 `openclaw channels login` |
| 004部署失败 | 低 | 保留003备份，可快速回退 |

---

## 十、快速参考命令

```bash
# SSH登录
ssh root@nas.ayfans.com -p 8822

# 检查服务状态
openclaw gateway status
ps aux | grep -E "wechat|stockai"

# 检查数据库
sqlite3 /data/stockai/db/stock.db "SELECT COUNT(*) FROM stock_daily;"

# 查看日志
tail -f ~/.openclaw/logs/gateway.log
tail -f /var/log/stockai/api.log

# 备份命令
tar czf /data/stockai-backup-$(date +%Y%m%d).tar.gz /data/stockai/
```

---

**文档用途**: 004部署前现状确认
**创建时间**: 2026-04-05
**维护者**: Main Agent
