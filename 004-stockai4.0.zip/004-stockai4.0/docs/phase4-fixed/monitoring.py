"""
StockAI 2.0 - 监控告警模块
=========================
提供错误日志记录、飞书告警通知、健康检查接口
"""

import os
import json
import logging
import traceback
import threading
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List
from pathlib import Path
from functools import wraps
from dataclasses import dataclass, asdict


# 配置日志目录
LOG_DIR = Path(__file__).parent / "logs"
LOG_DIR.mkdir(exist_ok=True)

# 错误日志文件
ERROR_LOG_FILE = LOG_DIR / "error.log"
ALERT_LOG_FILE = LOG_DIR / "alert.log"
ACCESS_LOG_FILE = LOG_DIR / "access.log"

# 配置 Python 日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
    handlers=[
        logging.FileHandler(ERROR_LOG_FILE, encoding='utf-8'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)


@dataclass
class ErrorRecord:
    """错误记录"""
    error_id: str
    timestamp: str
    level: str  # ERROR, WARNING, CRITICAL
    error_type: str
    message: str
    traceback: str
    context: Dict[str, Any]
    user_id: Optional[str] = None
    wechat_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class HealthStatus:
    """健康状态"""
    status: str  # healthy, degraded, unhealthy
    version: str
    timestamp: str
    uptime_seconds: int
    checks: Dict[str, Any]
    error_count_1h: int
    last_error_time: Optional[str]


class MonitoringManager:
    """监控管理器 - 单例模式"""
    
    _instance: Optional['MonitoringManager'] = None
    _lock = threading.Lock()
    
    # 告警阈值配置
    ALERT_CONFIG = {
        'error_rate_threshold': 10,  # 1小时内错误数阈值
        'critical_error_types': [
            'DATABASE_CONNECTION_ERROR',
            'INTERNAL_ERROR',
            'AGENT_CREATION_FAILED'
        ],
        'feishu_webhook': None,  # 飞书Webhook地址，从环境变量读取
    }
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self._initialized = True
        self._start_time = datetime.now()
        self._error_buffer: List[ErrorRecord] = []
        self._buffer_lock = threading.Lock()
        self._alert_cooldown: Dict[str, datetime] = {}
        self._alert_cooldown_seconds = 300  # 5分钟告警冷却
        
        # 从环境变量读取飞书Webhook
        self.ALERT_CONFIG['feishu_webhook'] = os.environ.get('FEISHU_WEBHOOK_URL')
    
    def record_error(self, 
                     error: Exception,
                     level: str = "ERROR",
                     context: Dict[str, Any] = None,
                     user_id: str = None,
                     wechat_id: str = None) -> str:
        """
        记录错误
        
        Args:
            error: 异常对象
            level: 错误级别 (ERROR, WARNING, CRITICAL)
            context: 错误上下文信息
            user_id: 用户ID
            wechat_id: 微信ID
            
        Returns:
            error_id: 错误唯一标识
        """
        error_id = f"ERR-{datetime.now().strftime('%Y%m%d%H%M%S')}-{id(error) % 10000:04d}"
        
        record = ErrorRecord(
            error_id=error_id,
            timestamp=datetime.now().isoformat(),
            level=level,
            error_type=error.__class__.__name__,
            message=str(error),
            traceback=traceback.format_exc(),
            context=context or {},
            user_id=user_id,
            wechat_id=wechat_id
        )
        
        # 写入错误日志
        self._write_error_log(record)
        
        # 添加到缓冲区
        with self._buffer_lock:
            self._error_buffer.append(record)
            # 保留最近100条
            if len(self._error_buffer) > 100:
                self._error_buffer = self._error_buffer[-100:]
        
        # 检查是否需要告警
        if level in ["ERROR", "CRITICAL"]:
            self._check_and_alert(record)
        
        return error_id
    
    def _write_error_log(self, record: ErrorRecord):
        """写入错误日志文件"""
        try:
            with open(ERROR_LOG_FILE, 'a', encoding='utf-8') as f:
                f.write(f"\n{'='*60}\n")
                f.write(f"Error ID: {record.error_id}\n")
                f.write(f"Time: {record.timestamp}\n")
                f.write(f"Level: {record.level}\n")
                f.write(f"Type: {record.error_type}\n")
                f.write(f"User: {record.user_id or 'N/A'}\n")
                f.write(f"Wechat: {record.wechat_id or 'N/A'}\n")
                f.write(f"Message: {record.message}\n")
                f.write(f"Context: {json.dumps(record.context, ensure_ascii=False)}\n")
                f.write(f"Traceback:\n{record.traceback}\n")
                f.write(f"{'='*60}\n")
        except Exception as e:
            logger.error(f"Failed to write error log: {e}")
    
    def _check_and_alert(self, record: ErrorRecord):
        """检查是否需要发送告警"""
        # 检查错误类型是否属于关键错误
        error_code = record.context.get('error_code', '')
        if error_code not in self.ALERT_CONFIG['critical_error_types']:
            return
        
        # 检查冷却时间
        now = datetime.now()
        error_type = record.error_type
        
        if error_type in self._alert_cooldown:
            last_alert = self._alert_cooldown[error_type]
            if (now - last_alert).seconds < self._alert_cooldown_seconds:
                return  # 还在冷却期内
        
        # 发送告警
        self._send_feishu_alert(record)
        self._alert_cooldown[error_type] = now
    
    def _send_feishu_alert(self, record: ErrorRecord):
        """发送飞书告警通知"""
        webhook_url = self.ALERT_CONFIG['feishu_webhook']
        if not webhook_url:
            logger.warning("Feishu webhook not configured, skipping alert")
            return
        
        # 构建告警消息
        alert_message = self._build_alert_message(record)
        
        # 记录告警日志
        try:
            with open(ALERT_LOG_FILE, 'a', encoding='utf-8') as f:
                f.write(f"{datetime.now().isoformat()} - ALERT SENT - {record.error_id}\n")
        except Exception as e:
            logger.error(f"Failed to write alert log: {e}")
        
        # 发送飞书通知（使用message工具）
        try:
            # 使用全局的message工具函数
            from message_tool import send_feishu_alert
            send_feishu_alert(alert_message)
            logger.info(f"Feishu alert sent for error {record.error_id}")
        except Exception as e:
            logger.error(f"Failed to send Feishu alert: {e}")
    
    def _build_alert_message(self, record: ErrorRecord) -> Dict[str, Any]:
        """构建飞书告警消息卡片"""
        error_code = record.context.get('error_code', 'UNKNOWN')
        action = record.context.get('action', 'N/A')
        
        return {
            "msg_type": "interactive",
            "card": {
                "config": {"wide_screen_mode": True},
                "header": {
                    "title": {
                        "tag": "plain_text",
                        "content": f"🚨 StockAI 错误告警 - {error_code}"
                    },
                    "template": "red"
                },
                "elements": [
                    {
                        "tag": "div",
                        "text": {
                            "tag": "lark_md",
                            "content": f"**错误ID:** {record.error_id}\n"
                                       f"**时间:** {record.timestamp}\n"
                                       f"**错误类型:** {record.error_type}\n"
                                       f"**错误码:** {error_code}\n"
                                       f"**操作:** {action}\n"
                                       f"**用户:** {record.user_id or 'N/A'}\n"
                                       f"**微信ID:** {record.wechat_id or 'N/A'}"
                        }
                    },
                    {"tag": "hr"},
                    {
                        "tag": "div",
                        "text": {
                            "tag": "lark_md",
                            "content": f"**错误信息:**\n{record.message[:500]}"
                        }
                    },
                    {"tag": "hr"},
                    {
                        "tag": "action",
                        "actions": [
                            {
                                "tag": "button",
                                "text": {"tag": "plain_text", "content": "查看日志"},
                                "type": "primary",
                                "value": {"action": "view_logs"}
                            }
                        ]
                    }
                ]
            }
        }
    
    def get_health_status(self) -> HealthStatus:
        """
        获取健康检查状态
        
        Returns:
            HealthStatus: 健康状态对象
        """
        now = datetime.now()
        uptime = (now - self._start_time).total_seconds()
        
        # 统计最近1小时错误数
        one_hour_ago = now - timedelta(hours=1)
        error_count_1h = 0
        last_error_time = None
        
        with self._buffer_lock:
            for record in self._error_buffer:
                record_time = datetime.fromisoformat(record.timestamp)
                if record_time > one_hour_ago:
                    error_count_1h += 1
                    if last_error_time is None or record_time > datetime.fromisoformat(last_error_time):
                        last_error_time = record.timestamp
        
        # 判断健康状态
        if error_count_1h >= self.ALERT_CONFIG['error_rate_threshold']:
            status = "unhealthy"
        elif error_count_1h > 0:
            status = "degraded"
        else:
            status = "healthy"
        
        # 各项服务检查
        checks = {
            "error_log": self._check_log_file(ERROR_LOG_FILE),
            "alert_log": self._check_log_file(ALERT_LOG_FILE),
            "log_directory": LOG_DIR.exists(),
            "feishu_webhook_configured": self.ALERT_CONFIG['feishu_webhook'] is not None
        }
        
        return HealthStatus(
            status=status,
            version="2.0.0",
            timestamp=now.isoformat(),
            uptime_seconds=int(uptime),
            checks=checks,
            error_count_1h=error_count_1h,
            last_error_time=last_error_time
        )
    
    def _check_log_file(self, log_file: Path) -> Dict[str, Any]:
        """检查日志文件状态"""
        try:
            if not log_file.exists():
                return {"exists": False, "writable": False}
            
            # 尝试写入测试
            with open(log_file, 'a', encoding='utf-8') as f:
                pass
            
            return {
                "exists": True,
                "writable": True,
                "size_bytes": log_file.stat().st_size
            }
        except Exception as e:
            return {"exists": log_file.exists(), "writable": False, "error": str(e)}
    
    def get_error_stats(self, hours: int = 24) -> Dict[str, Any]:
        """
        获取错误统计
        
        Args:
            hours: 统计最近几小时
            
        Returns:
            统计信息字典
        """
        now = datetime.now()
        since = now - timedelta(hours=hours)
        
        stats = {
            "total_errors": 0,
            "by_type": {},
            "by_level": {},
            "recent_errors": []
        }
        
        with self._buffer_lock:
            for record in self._error_buffer:
                record_time = datetime.fromisoformat(record.timestamp)
                if record_time > since:
                    stats["total_errors"] += 1
                    stats["by_type"][record.error_type] = stats["by_type"].get(record.error_type, 0) + 1
                    stats["by_level"][record.level] = stats["by_level"].get(record.level, 0) + 1
                    
                    if len(stats["recent_errors"]) < 10:
                        stats["recent_errors"].append(record.to_dict())
        
        return stats


# 全局监控实例
monitoring = MonitoringManager()


def error_handler(func):
    """
    错误处理装饰器
    
    自动捕获异常并记录到监控系统
    
    Usage:
        @error_handler
        def my_function():
            ...
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            # 提取上下文信息
            context = {
                "function": func.__name__,
                "module": func.__module__,
                "args_count": len(args),
                "kwargs_keys": list(kwargs.keys())
            }
            
            # 记录错误
            monitoring.record_error(
                error=e,
                level="ERROR",
                context=context
            )
            raise
    return wrapper


def log_access(user_id: str, action: str, details: Dict[str, Any] = None):
    """记录访问日志"""
    try:
        with open(ACCESS_LOG_FILE, 'a', encoding='utf-8') as f:
            log_entry = {
                "timestamp": datetime.now().isoformat(),
                "user_id": user_id,
                "action": action,
                "details": details or {}
            }
            f.write(json.dumps(log_entry, ensure_ascii=False) + '\n')
    except Exception as e:
        logger.error(f"Failed to write access log: {e}")


# 用于message工具的简单包装函数
class MessageToolWrapper:
    """message工具包装器 - 用于发送飞书告警"""
    
    @staticmethod
    def send_feishu_alert(alert_message: Dict[str, Any]):
        """
        发送飞书告警消息
        
        注意：这里会被外部的message工具替换
        """
        # 实际使用时，这个函数会被 main_router 中的代码替换
        # 使用真正的 message 工具发送
        logger.info(f"Feishu alert would be sent: {alert_message}")


# 兼容性导出
send_feishu_alert = MessageToolWrapper.send_feishu_alert


if __name__ == "__main__":
    print("=== 监控告警模块测试 ===")
    
    # 测试错误记录
    try:
        raise ValueError("测试错误")
    except Exception as e:
        error_id = monitoring.record_error(
            error=e,
            level="ERROR",
            context={"error_code": "TEST_ERROR", "action": "test"},
            user_id="test_user"
        )
        print(f"✅ 错误已记录: {error_id}")
    
    # 测试健康检查
    health = monitoring.get_health_status()
    print(f"\n✅ 健康状态:")
    print(f"   状态: {health.status}")
    print(f"   运行时间: {health.uptime_seconds}秒")
    print(f"   最近1小时错误数: {health.error_count_1h}")
    print(f"   检查项: {health.checks}")
    
    # 测试错误统计
    stats = monitoring.get_error_stats(hours=1)
    print(f"\n✅ 错误统计:")
    print(f"   总错误数: {stats['total_errors']}")
    print(f"   按类型: {stats['by_type']}")
    
    print("\n✅ 监控告警模块测试通过")
