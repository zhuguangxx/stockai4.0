"""
StockAI 2.0 - Agent 服务模块
===========================
负责创建 Client Agent、查询 Agent 信息、路由消息
"""

import json
import os
import logging
from typing import Optional, Dict, Any
from pathlib import Path
from datetime import datetime

from database import DatabaseManager, get_db
from models import AgentConfig, AgentStatus, AgentCreationResult, RouteToAgentResult

logger = logging.getLogger(__name__)


class AgentService:
    """Agent 管理服务"""
    
    # Agent 工作空间根目录
    CLIENTS_DIR = "/opt/new-stockai/clients"
    
    def __init__(self, db: DatabaseManager = None, clients_dir: str = None):
        self.db = db or get_db()
        self.clients_dir = clients_dir or self.CLIENTS_DIR
        # 确保目录存在
        Path(self.clients_dir).mkdir(parents=True, exist_ok=True)
    
    def create_client_agent(self, user_id: str, user_profile: Dict[str, Any] = None,
                           agent_config: Dict[str, Any] = None) -> AgentCreationResult:
        """
        创建用户专属的 Client Agent
        
        Args:
            user_id: 用户ID
            user_profile: 用户画像数据
            agent_config: Agent 个性化配置
            
        Returns:
            AgentCreationResult: 创建结果
        """
        try:
            # 检查是否已存在
            existing = self.db.get_agent_by_user(user_id)
            if existing:
                logger.info(f"Agent already exists for user {user_id}")
                return AgentCreationResult(
                    success=True,
                    agent_id=existing['agent_id'],
                    workspace_path=None,  # 现有Agent不返回新路径
                    status="created",
                    message="Agent already exists"
                )
            
            # 获取用户信息
            user = self.db.get_user_account(user_id)
            if not user:
                return AgentCreationResult(
                    success=False,
                    agent_id=None,
                    workspace_path=None,
                    status="error",
                    message="User not found"
                )
            
            # 创建 Agent 名称
            nickname = user.get('nickname', 'User')
            agent_name = f"StockAI_{nickname}"
            
            # 生成 Agent ID
            agent_id = self.db.create_agent(user_id, agent_name, agent_config)
            
            # 创建 Agent 工作空间
            workspace_path = self._create_agent_workspace(
                agent_id=agent_id,
                user_id=user_id,
                agent_name=agent_name,
                user_profile=user_profile
            )
            
            # 更新Agent状态为running
            self.db.update_agent_status(agent_id, 'running')
            
            logger.info(f"Client Agent created: agent_id={agent_id}, user_id={user_id}")
            
            return AgentCreationResult(
                success=True,
                agent_id=agent_id,
                workspace_path=workspace_path,
                status="created",
                message="Agent created successfully"
            )
            
        except Exception as e:
            logger.error(f"Agent creation failed: {e}")
            return AgentCreationResult(
                success=False,
                agent_id=None,
                workspace_path=None,
                status="error",
                message=str(e)
            )
    
    def _create_agent_workspace(self, agent_id: str, user_id: str,
                                 agent_name: str, user_profile: Dict[str, Any]) -> str:
        """
        创建 Agent 工作空间
        
        包含：
        - 工作目录
        - SOUL.md 配置文件
        - config.json 配置
        """
        # 创建工作目录
        agent_dir = Path(self.clients_dir) / agent_id
        workspace_dir = agent_dir / "workspace"
        workspace_dir.mkdir(parents=True, exist_ok=True)
        
        # 创建 config.json
        config = {
            "agent_id": agent_id,
            "user_id": user_id,
            "agent_name": agent_name,
            "created_at": datetime.now().isoformat(),
            "workspace": str(workspace_dir)
        }
        
        with open(agent_dir / "config.json", "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        
        # 创建 SOUL.md
        soul_content = self._generate_soul_md(agent_name, user_profile)
        with open(workspace_dir / "SOUL.md", "w", encoding="utf-8") as f:
            f.write(soul_content)
        
        # 创建 MEMORY.md（用户记忆文件）
        memory_content = self._generate_memory_md(user_profile)
        with open(workspace_dir / "MEMORY.md", "w", encoding="utf-8") as f:
            f.write(memory_content)
        
        logger.info(f"Agent workspace created: {workspace_dir}")
        return str(workspace_dir)
    
    def _generate_soul_md(self, agent_name: str, user_profile: Dict[str, Any]) -> str:
        """生成 SOUL.md 内容"""
        experience = user_profile.get('investment_experience', '未设置') if user_profile else '未设置'
        risk = user_profile.get('risk_profile', '未设置') if user_profile else '未设置'
        style = user_profile.get('investment_style', '未设置') if user_profile else '未设置'
        sectors = user_profile.get('focus_sectors', []) if user_profile else []
        
        sectors_str = ", ".join(sectors) if sectors else "未设置"
        
        return f"""# SOUL.md - {agent_name}的专属投资助手

## 身份
你是{agent_name}的专属AI投资助手，负责股票分析和投资建议。

## 权限
- 可查看用户的自选股、持仓
- 可查询股票数据
- 禁止访问其他客户数据

## 用户画像
- 投资经验: {experience}
- 风险偏好: {risk}
- 投资风格: {style}
- 关注板块: {sectors_str}

## 职责
1. 根据用户画像提供个性化的股票分析
2. 跟踪用户的自选股动态
3. 分析持仓股票的盈亏情况
4. 提供符合用户风险偏好的投资建议

## 约束
- 不做具体买卖建议，只提供分析参考
- 提醒用户投资有风险，决策需谨慎
- 保护用户隐私，不泄露持仓信息
"""
    
    def _generate_memory_md(self, user_profile: Dict[str, Any]) -> str:
        """生成 MEMORY.md 内容"""
        return f"""# MEMORY.md - 用户记忆

## 长期记忆

### 投资偏好
{json.dumps(user_profile, indent=2, ensure_ascii=False) if user_profile else "暂无"}

### 交互历史
- 首次创建: {datetime.now().isoformat()}

### 待办事项
- [ ] 熟悉用户投资风格
- [ ] 跟踪自选股票动态
"""
    
    def get_client_agent(self, user_id: str) -> Optional[Dict[str, Any]]:
        """
        获取用户的 Client Agent 信息
        
        Args:
            user_id: 用户ID
            
        Returns:
            Agent 信息或 None
        """
        try:
            return self.db.get_agent_by_user(user_id)
        except Exception as e:
            logger.error(f"Get client agent failed: {e}")
            return None
    
    def get_agent(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """
        获取 Agent 信息
        
        Args:
            agent_id: Agent ID
            
        Returns:
            Agent 信息或 None
        """
        try:
            return self.db.get_agent(agent_id)
        except Exception as e:
            logger.error(f"Get agent failed: {e}")
            return None
    
    def route_to_agent(self, agent_id: str, message: str,
                       context: Dict[str, Any]) -> RouteToAgentResult:
        """
        将消息路由到指定 Client Agent
        
        注意: 这是模拟实现，实际需要通过 OpenClaw API 路由消息
        
        Args:
            agent_id: Agent ID
            message: 用户消息内容
            context: 上下文信息
            
        Returns:
            RouteToAgentResult: 路由结果
        """
        try:
            # 检查 Agent 是否存在
            agent = self.db.get_agent(agent_id)
            if not agent:
                return RouteToAgentResult(
                    status="error",
                    response=None,
                    error="Agent not found",
                    error_code="AGENT_NOT_FOUND"
                )
            
            # 检查 Agent 状态
            if agent['status'] != 'running':
                # 尝试启动 Agent
                self.start_agent(agent_id)
            
            # 记录消息
            user_id = context.get('user_id')
            channel_id = context.get('channel_id', 'wechat_main')
            wechat_id = context.get('wechat_id')
            
            if user_id:
                self.db.record_message(
                    user_id=user_id,
                    channel_id=channel_id,
                    wechat_id=wechat_id,
                    direction='inbound',
                    content=message,
                    agent_id=agent_id
                )
            
            # 模拟处理成功
            # 实际实现需要通过 OpenClaw API 发送消息到 Agent
            logger.info(f"Message routed to agent: {agent_id}")
            
            return RouteToAgentResult(
                status="delivered",
                response=None,  # Client Agent 会异步回复
                error=None,
                error_code=None
            )
            
        except Exception as e:
            logger.error(f"Route to agent failed: {e}")
            return RouteToAgentResult(
                status="error",
                response=None,
                error=str(e),
                error_code="ROUTE_ERROR"
            )
    
    def start_agent(self, agent_id: str) -> Dict[str, Any]:
        """
        启动 Client Agent
        
        Args:
            agent_id: Agent ID
            
        Returns:
            {"success": bool, "status": str, "error": str | None}
        """
        try:
            # 更新数据库状态
            self.db.update_agent_status(agent_id, 'running')
            
            logger.info(f"Agent started: {agent_id}")
            return {
                "success": True,
                "status": "running",
                "error": None
            }
        except Exception as e:
            logger.error(f"Start agent failed: {e}")
            return {
                "success": False,
                "status": "error",
                "error": str(e)
            }
    
    def stop_agent(self, agent_id: str) -> Dict[str, Any]:
        """
        停止 Client Agent
        
        Args:
            agent_id: Agent ID
            
        Returns:
            {"success": bool, "status": str, "error": str | None}
        """
        try:
            # 更新数据库状态
            self.db.update_agent_status(agent_id, 'stopped')
            
            logger.info(f"Agent stopped: {agent_id}")
            return {
                "success": True,
                "status": "stopped",
                "error": None
            }
        except Exception as e:
            logger.error(f"Stop agent failed: {e}")
            return {
                "success": False,
                "status": "error",
                "error": str(e)
            }
    
    def get_agent_status(self, agent_id: str) -> Dict[str, Any]:
        """
        获取 Agent 运行状态
        
        Args:
            agent_id: Agent ID
            
        Returns:
            Agent 状态信息
        """
        try:
            agent = self.db.get_agent(agent_id)
            if not agent:
                return {
                    "agent_id": agent_id,
                    "status": "error",
                    "uptime_seconds": None,
                    "memory_usage_mb": None,
                    "last_error": "Agent not found"
                }
            
            # 计算运行时间
            uptime = None
            if agent['status'] == 'running' and agent.get('last_active_at'):
                last_active = datetime.fromisoformat(agent['last_active_at'])
                uptime = int((datetime.now() - last_active).total_seconds())
            
            return {
                "agent_id": agent_id,
                "status": agent['status'],
                "uptime_seconds": uptime,
                "memory_usage_mb": None,  # 实际实现需要系统监控
                "last_error": None
            }
        except Exception as e:
            logger.error(f"Get agent status failed: {e}")
            return {
                "agent_id": agent_id,
                "status": "error",
                "uptime_seconds": None,
                "memory_usage_mb": None,
                "last_error": str(e)
            }


if __name__ == "__main__":
    print("=== Agent 服务模块测试 ===")
    
    from database import DatabaseManager
    from services.user_service import UserService
    
    # 使用临时目录测试
    import tempfile
    test_dir = tempfile.mkdtemp()
    
    # 使用内存数据库测试
    test_db = DatabaseManager(":memory:")
    user_service = UserService(test_db)
    agent_service = AgentService(test_db, clients_dir=test_dir)
    
    # 先注册一个用户
    result = user_service.register_user(
        nickname="测试用户",
        wechat_id="wxid_agent_test",
        profile_data={
            "investment_experience": "expert",
            "risk_profile": "aggressive",
            "investment_style": "growth"
        }
    )
    user_id = result["user_id"]
    print(f"✅ 创建用户: {user_id}")
    
    # 测试创建 Agent
    profile = user_service.get_user(user_id)
    result = agent_service.create_client_agent(
        user_id=user_id,
        user_profile=profile.get("profile") if profile else None
    )
    print(f"✅ 创建 Agent: {result}")
    
    agent_id = result.agent_id
    
    # 测试获取 Agent
    agent = agent_service.get_client_agent(user_id)
    print(f"✅ 获取 Agent: {agent}")
    
    # 测试路由消息
    route_result = agent_service.route_to_agent(
        agent_id=agent_id,
        message="帮我分析一下贵州茅台",
        context={"user_id": user_id, "channel_id": "wechat_main"}
    )
    print(f"✅ 路由消息: {route_result}")
    
    print("\n✅ Agent 服务模块测试通过")
    
    # 清理
    import shutil
    shutil.rmtree(test_dir)
