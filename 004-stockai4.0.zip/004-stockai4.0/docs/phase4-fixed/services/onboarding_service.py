"""
StockAI 2.0 - 问卷服务模块
=========================
负责新用户注册的6个问题流程、答案保存、完成触发
"""

import json
import logging
from typing import Optional, Dict, Any, List
from datetime import datetime

from database import DatabaseManager, get_db
from models import (
    OnboardingQuestion, OnboardingAnswer, OnboardingState,
    OnboardingStatus, OnboardingCompleteResult, QuestionType
)
from services.user_service import UserService
from services.agent_service import AgentService

logger = logging.getLogger(__name__)


# =============================================================================
# 问卷问题定义
# =============================================================================

ONBOARDING_QUESTIONS = [
    {
        "question_id": "q1_name",
        "question_type": QuestionType.TEXT,
        "question_text": "👋 欢迎！请问怎么称呼您？",
        "key": "nickname",
        "hint": "请输入您的昵称或姓名",
        "is_last": False
    },
    {
        "question_id": "q2_watchlist",
        "question_type": QuestionType.TEXT,
        "question_text": "📈 您关注哪些股票？（请输入股票代码，如：000001.SZ, 600519.SH）",
        "key": "watchlist",
        "hint": "多个股票代码用逗号分隔，如果没有可输入'无'",
        "is_last": False
    },
    {
        "question_id": "q3_experience",
        "question_type": QuestionType.SINGLE_CHOICE,
        "question_text": "🎯 您的投资经验如何？",
        "key": "investment_experience",
        "options": [
            {"value": "newbie", "label": "新手 - 刚开始接触股票"},
            {"value": "junior", "label": "入门 - 有1-2年经验"},
            {"value": "intermediate", "label": "中级 - 有3-5年经验"},
            {"value": "expert", "label": "资深 - 5年以上经验"}
        ],
        "hint": "请回复选项编号（1-4）",
        "is_last": False
    },
    {
        "question_id": "q4_risk",
        "question_type": QuestionType.SINGLE_CHOICE,
        "question_text": "⚖️ 您的风险承受能力？",
        "key": "risk_profile",
        "options": [
            {"value": "conservative", "label": "保守型 - 优先保本，接受低收益"},
            {"value": "moderate", "label": "稳健型 - 平衡风险与收益"},
            {"value": "aggressive", "label": "积极型 - 愿意承担较高风险"},
            {"value": "radical", "label": "激进型 - 追求高收益，能承受大波动"}
        ],
        "hint": "请回复选项编号（1-4）",
        "is_last": False
    },
    {
        "question_id": "q5_style",
        "question_type": QuestionType.SINGLE_CHOICE,
        "question_text": "🔄 您的投资风格？",
        "key": "investment_style",
        "options": [
            {"value": "value", "label": "价值投资 - 长期持有优质股"},
            {"value": "growth", "label": "成长投资 - 寻找高增长潜力股"},
            {"value": "dividend", "label": "股息投资 - 偏好高分红股票"},
            {"value": "swing", "label": "波段操作 - 中短线交易"},
            {"value": "daytrade", "label": "短线交易 - 日内或超短线"}
        ],
        "hint": "请回复选项编号（1-5）",
        "is_last": False
    },
    {
        "question_id": "q6_sectors",
        "question_type": QuestionType.MULTIPLE_CHOICE,
        "question_text": "🏭 您关注的行业板块？（可多选）",
        "key": "focus_sectors",
        "options": [
            {"value": "technology", "label": "科技（AI、芯片、软件）"},
            {"value": "finance", "label": "金融（银行、保险、证券）"},
            {"value": "healthcare", "label": "医药（生物医药、医疗器械）"},
            {"value": "new_energy", "label": "新能源（光伏、锂电、储能）"},
            {"value": "consumer", "label": "消费（白酒、家电、零售）"},
            {"value": "manufacturing", "label": "制造（汽车、机械、军工）"}
        ],
        "hint": "请回复选项编号（1-6），多个选项用逗号分隔",
        "is_last": True
    }
]

TOTAL_QUESTIONS = len(ONBOARDING_QUESTIONS)


class OnboardingService:
    """问卷服务"""
    
    def __init__(self, db: DatabaseManager = None, agent_service: AgentService = None):
        self.db = db or get_db()
        self.user_service = UserService(db)
        self.agent_service = agent_service or AgentService(db)
    
    def start_onboarding(self, wechat_id: str, channel_id: str = "wechat_main") -> Dict[str, Any]:
        """
        开始新用户注册流程
        
        Args:
            wechat_id: 微信用户ID
            channel_id: 频道标识
            
        Returns:
            {
                "progress_id": str,
                "first_question": dict,
                "welcome_message": str
            }
        """
        try:
            # 检查是否已有进行中的问卷
            existing = self.db.get_onboarding_by_wechat(wechat_id, channel_id)
            if existing:
                progress_id = existing['progress_id']
                current_q = existing['current_question']
                logger.info(f"Resuming onboarding: progress_id={progress_id}, question={current_q}")
            else:
                # 创建新的问卷进度
                progress_id = self.db.create_onboarding_progress(wechat_id, channel_id)
                current_q = 0
                logger.info(f"Started new onboarding: progress_id={progress_id}")
            
            # 获取第一个问题（或继续的问题）
            next_question = self.get_next_question(progress_id)
            
            welcome_message = (
                "🎉 欢迎使用 StockAI 智能投资助手！\n\n"
                "为了给您提供更好的服务，请完成以下6个简单问题。"
            )
            
            return {
                "progress_id": progress_id,
                "first_question": next_question,
                "welcome_message": welcome_message
            }
            
        except Exception as e:
            logger.error(f"Start onboarding failed: {e}")
            raise
    
    def get_next_question(self, progress_id: str) -> Optional[Dict[str, Any]]:
        """
        获取下一个问题
        
        Args:
            progress_id: 进度记录ID
            
        Returns:
            问题对象或 None（如果已完成）
        """
        try:
            progress = self.db.get_onboarding_progress(progress_id)
            if not progress:
                return None
            
            current_q = progress['current_question']
            
            # 检查是否已完成
            if current_q >= TOTAL_QUESTIONS:
                return None
            
            # 获取当前问题
            question = ONBOARDING_QUESTIONS[current_q]
            
            return {
                "question_id": question["question_id"],
                "question_type": question["question_type"],
                "question_text": question["question_text"],
                "options": question.get("options"),
                "hint": question.get("hint"),
                "is_last": question["is_last"],
                "progress": f"{current_q + 1}/{TOTAL_QUESTIONS}"
            }
            
        except Exception as e:
            logger.error(f"Get next question failed: {e}")
            return None
    
    def save_answer(self, progress_id: str, answer: str) -> Dict[str, Any]:
        """
        保存用户答案，返回下一个问题或完成状态
        
        Args:
            progress_id: 进度记录ID
            answer: 用户答案
            
        Returns:
            {
                "success": bool,
                "is_complete": bool,
                "next_question": dict | None,
                "progress": str,
                "error": str | None
            }
        """
        try:
            # 获取当前进度
            progress = self.db.get_onboarding_progress(progress_id)
            if not progress:
                return {
                    "success": False,
                    "is_complete": False,
                    "next_question": None,
                    "progress": "0/6",
                    "error": "Progress not found"
                }
            
            current_q = progress['current_question']
            answers = progress.get('answers', {})
            
            # 检查是否已完成
            if current_q >= TOTAL_QUESTIONS:
                return {
                    "success": True,
                    "is_complete": True,
                    "next_question": None,
                    "progress": f"{TOTAL_QUESTIONS}/{TOTAL_QUESTIONS}",
                    "error": None
                }
            
            # 获取当前问题
            question = ONBOARDING_QUESTIONS[current_q]
            key = question["key"]
            
            # 处理答案
            processed_answer = self._process_answer(answer, question)
            answers[key] = processed_answer
            
            # 更新进度
            next_q = current_q + 1
            is_complete = next_q >= TOTAL_QUESTIONS
            
            status = "completed" if is_complete else "in_progress"
            self.db.update_onboarding_progress(progress_id, next_q, answers, status)
            
            logger.info(f"Answer saved: progress_id={progress_id}, question={current_q}, key={key}")
            
            # 获取下一个问题
            next_question = None
            if not is_complete:
                next_question = self.get_next_question(progress_id)
            
            return {
                "success": True,
                "is_complete": is_complete,
                "next_question": next_question,
                "progress": f"{next_q}/{TOTAL_QUESTIONS}",
                "error": None
            }
            
        except Exception as e:
            logger.error(f"Save answer failed: {e}")
            return {
                "success": False,
                "is_complete": False,
                "next_question": None,
                "progress": "0/6",
                "error": str(e)
            }
    
    def _process_answer(self, answer: str, question: Dict[str, Any]) -> Any:
        """
        处理用户答案，转换为适当的格式
        """
        question_type = question.get("question_type")
        options = question.get("options", [])
        
        if question_type == QuestionType.TEXT:
            return answer.strip()
        
        elif question_type == QuestionType.SINGLE_CHOICE:
            # 解析选项编号
            try:
                idx = int(answer.strip()) - 1
                if 0 <= idx < len(options):
                    return options[idx]["value"]
            except:
                pass
            # 如果不是编号，直接返回原值（如果是有效的value）
            valid_values = [opt["value"] for opt in options]
            if answer in valid_values:
                return answer
            return answer.strip()  # 默认返回原文
        
        elif question_type == QuestionType.MULTIPLE_CHOICE:
            # 解析多个选项编号
            selected = []
            parts = answer.replace(",", " ").split()
            for part in parts:
                try:
                    idx = int(part.strip()) - 1
                    if 0 <= idx < len(options):
                        selected.append(options[idx]["value"])
                except:
                    # 直接匹配value
                    valid_values = [opt["value"] for opt in options]
                    if part in valid_values:
                        selected.append(part)
            return selected
        
        return answer.strip()
    
    def is_complete(self, progress_id: str) -> bool:
        """
        检查问卷是否完成
        
        Args:
            progress_id: 进度记录ID
            
        Returns:
            是否已完成
        """
        try:
            progress = self.db.get_onboarding_progress(progress_id)
            if not progress:
                return False
            return progress['status'] == 'completed'
        except Exception as e:
            logger.error(f"Check completion failed: {e}")
            return False
    
    def get_answers(self, progress_id: str) -> Dict[str, Any]:
        """
        获取所有答案
        
        Args:
            progress_id: 进度记录ID
            
        Returns:
            答案字典
        """
        try:
            progress = self.db.get_onboarding_progress(progress_id)
            if not progress:
                return {}
            
            return {
                "progress_id": progress_id,
                "answers": progress.get('answers', {}),
                "completed_at": progress.get('complete_time'),
                "user_profile": self._build_profile(progress.get('answers', {}))
            }
        except Exception as e:
            logger.error(f"Get answers failed: {e}")
            return {}
    
    def _build_profile(self, answers: Dict[str, Any]) -> Dict[str, Any]:
        """
        从答案构建用户画像
        """
        return {
            "investment_experience": answers.get("investment_experience"),
            "risk_profile": answers.get("risk_profile"),
            "investment_style": answers.get("investment_style"),
            "focus_sectors": answers.get("focus_sectors", [])
        }
    
    def complete_onboarding(self, progress_id: str) -> OnboardingCompleteResult:
        """
        完成注册流程
        
        触发动作：
        1. 创建 user_accounts 记录
        2. 创建 user_profiles 记录
        3. 绑定微信身份
        4. 创建 Client Agent
        5. 更新 onboarding_progress 状态
        
        Args:
            progress_id: 进度记录ID
            
        Returns:
            OnboardingCompleteResult: 完成结果
        """
        try:
            # 获取问卷进度
            progress = self.db.get_onboarding_progress(progress_id)
            if not progress:
                return OnboardingCompleteResult(
                    success=False,
                    error="Progress not found"
                )
            
            answers = progress.get('answers', {})
            wechat_id = progress['wechat_id']
            channel_id = progress['channel_id']
            
            # 1. 创建用户账号
            nickname = answers.get('nickname', '用户')
            register_result = self.user_service.register_user(
                nickname=nickname,
                wechat_id=wechat_id,
                channel_id=channel_id
            )
            
            if not register_result['success']:
                return OnboardingCompleteResult(
                    success=False,
                    error=f"User registration failed: {register_result['error']}"
                )
            
            user_id = register_result['user_id']
            
            # 2. 创建用户画像
            profile_data = self._build_profile(answers)
            self.user_service.update_profile(user_id, profile_data)
            
            # 3. 添加自选股
            watchlist_str = answers.get('watchlist', '')
            if watchlist_str and watchlist_str != '无':
                import re
                stocks = re.split(r"[,\s]+", watchlist_str.strip())
                for stock_code in stocks:
                    stock_code = stock_code.strip()
                    if stock_code:
                        self.db.add_watchlist(user_id, stock_code)
            
            # 4. 创建 Client Agent
            agent_result = self.agent_service.create_client_agent(
                user_id=user_id,
                user_profile=profile_data
            )
            
            if not agent_result.success:
                return OnboardingCompleteResult(
                    success=False,
                    user_id=user_id,
                    error=f"Agent creation failed: {agent_result.message}"
                )
            
            agent_id = agent_result.agent_id
            
            # 5. 完成问卷进度
            self.db.complete_onboarding(progress_id, user_id)
            
            logger.info(f"Onboarding completed: user_id={user_id}, agent_id={agent_id}")
            
            return OnboardingCompleteResult(
                success=True,
                user_id=user_id,
                agent_id=agent_id,
                profile=profile_data
            )
            
        except Exception as e:
            logger.error(f"Complete onboarding failed: {e}")
            return OnboardingCompleteResult(
                success=False,
                error=str(e)
            )
    
    def get_onboarding_state(self, progress_id: str) -> Optional[OnboardingState]:
        """
        获取问卷状态
        
        Args:
            progress_id: 进度记录ID
            
        Returns:
            OnboardingState 或 None
        """
        try:
            progress = self.db.get_onboarding_progress(progress_id)
            if not progress:
                return None
            
            current_q = progress['current_question']
            
            return OnboardingState(
                progress_id=progress_id,
                user_id=progress.get('user_id'),
                wechat_id=progress['wechat_id'],
                channel_id=progress['channel_id'],
                current_question=current_q,
                total_questions=TOTAL_QUESTIONS,
                progress_pct=(current_q / TOTAL_QUESTIONS) * 100,
                answers=progress.get('answers', {}),
                status=OnboardingStatus(progress['status']),
                is_complete=progress['status'] == 'completed'
            )
        except Exception as e:
            logger.error(f"Get onboarding state failed: {e}")
            return None
    
    def reset_onboarding(self, wechat_id: str, channel_id: str = "wechat_main") -> bool:
        """
        重置问卷进度（用于测试）
        
        Args:
            wechat_id: 微信用户ID
            channel_id: 频道标识
            
        Returns:
            是否成功
        """
        try:
            progress = self.db.get_onboarding_by_wechat(wechat_id, channel_id)
            if progress:
                self.db.update_onboarding_progress(
                    progress['progress_id'],
                    0,
                    {},
                    'in_progress'
                )
                logger.info(f"Onboarding reset: wechat_id={wechat_id}")
            return True
        except Exception as e:
            logger.error(f"Reset onboarding failed: {e}")
            return False


if __name__ == "__main__":
    print("=== 问卷服务模块测试 ===")
    
    from database import DatabaseManager
    import tempfile
    
    # 使用内存数据库测试
    test_db = DatabaseManager(":memory:")
    test_dir = tempfile.mkdtemp()
    
    onboarding_service = OnboardingService(test_db)
    
    # 测试开始问卷
    result = onboarding_service.start_onboarding("wxid_onboarding_test")
    progress_id = result["progress_id"]
    print(f"✅ 开始问卷: progress_id={progress_id}")
    print(f"   第一个问题: {result['first_question']['question_text']}")
    
    # 模拟回答所有问题
    test_answers = [
        "张三",  # 昵称
        "000001.SZ, 600519.SH",  # 自选股
        "3",  # 中级经验
        "2",  # 稳健型
        "1",  # 价值投资
        "1, 2, 3"  # 科技、金融、医药
    ]
    
    for i, answer in enumerate(test_answers):
        result = onboarding_service.save_answer(progress_id, answer)
        print(f"✅ 回答问题 {i+1}: {answer}")
        if result["is_complete"]:
            print(f"   问卷完成！")
            break
        else:
            print(f"   下一个问题: {result['next_question']['question_text'][:30]}...")
    
    # 测试完成注册
    complete_result = onboarding_service.complete_onboarding(progress_id)
    print(f"✅ 完成注册: {complete_result}")
    
    print("\n✅ 问卷服务模块测试通过")
    
    # 清理
    import shutil
    shutil.rmtree(test_dir)
