"""
StockAI 2.0 - 用户服务模块
=========================
负责用户注册/查询、微信绑定、身份识别
"""

import logging
from typing import Optional, Dict, Any, List
from datetime import datetime

from database import DatabaseManager, get_db
from models import (
    UserAccount, UserIdentity, UserProfile, UserAgent,
    UserIdentityResult, UserStatus, IdentityProvider, AgentStatus
)

logger = logging.getLogger(__name__)


class IdentityService:
    """身份识别服务"""
    
    def __init__(self, db: DatabaseManager = None):
        self.db = db or get_db()
    
    def identify_user(self, wechat_id: str, channel_id: str = "wechat_main") -> UserIdentityResult:
        """
        识别用户身份 - 核心方法
        
        Args:
            wechat_id: 微信用户ID
            channel_id: 频道标识
            
        Returns:
            UserIdentityResult: 包含用户是否存在及相关信息
        """
        try:
            # 查询身份
            identity = self.db.get_identity_by_provider('wechat', wechat_id, channel_id)
            
            if not identity:
                logger.info(f"New user detected: wechat_id={wechat_id}, channel={channel_id}")
                return UserIdentityResult(exists=False)
            
            user_id = identity['user_id']
            
            # 查询用户账号状态
            account = self.db.get_user_account(user_id)
            if not account:
                logger.warning(f"Identity exists but account not found: user_id={user_id}")
                return UserIdentityResult(exists=False)
            
            # 查询Agent
            agent = self.db.get_agent_by_user(user_id)
            agent_id = agent['agent_id'] if agent else None
            
            logger.info(f"User identified: user_id={user_id}, agent_id={agent_id}")
            
            return UserIdentityResult(
                exists=True,
                user_id=user_id,
                agent_id=agent_id,
                identity_id=identity['identity_id'],
                status=account['status'],
                is_primary=identity['is_primary']
            )
            
        except Exception as e:
            logger.error(f"Identity identification failed: {e}")
            return UserIdentityResult(exists=False)
    
    def bind_wechat(self, user_id: str, wechat_id: str, channel_id: str = "wechat_main",
                    is_primary: bool = False, auth_data: Dict = None) -> Dict[str, Any]:
        """
        绑定微信账号到用户
        
        Args:
            user_id: 用户ID
            wechat_id: 微信用户ID
            channel_id: 频道标识
            is_primary: 是否设为主身份
            auth_data: 额外认证数据
            
        Returns:
            {"success": bool, "identity_id": str | None, "error": str | None}
        """
        try:
            # 检查是否已绑定
            existing = self.db.get_identity_by_provider('wechat', wechat_id, channel_id)
            if existing:
                return {
                    "success": False,
                    "identity_id": None,
                    "error": "WeChat ID already bound to another user"
                }
            
            # 创建身份
            identity_id = self.db.create_identity(
                user_id=user_id,
                provider='wechat',
                provider_id=wechat_id,
                channel_id=channel_id,
                is_primary=is_primary,
                auth_data=auth_data
            )
            
            logger.info(f"WeChat bound: user_id={user_id}, wechat_id={wechat_id}")
            
            return {
                "success": True,
                "identity_id": identity_id,
                "error": None
            }
            
        except Exception as e:
            logger.error(f"WeChat binding failed: {e}")
            return {
                "success": False,
                "identity_id": None,
                "error": str(e)
            }
    
    def unbind_wechat(self, identity_id: str) -> Dict[str, Any]:
        """
        解绑微信账号
        
        Args:
            identity_id: 身份ID
            
        Returns:
            {"success": bool, "error": str | None}
        """
        try:
            self.db.unbind_identity(identity_id)
            logger.info(f"WeChat unbound: identity_id={identity_id}")
            return {"success": True, "error": None}
        except Exception as e:
            logger.error(f"WeChat unbinding failed: {e}")
            return {"success": False, "error": str(e)}
    
    def get_user_identities(self, user_id: str) -> List[Dict[str, Any]]:
        """
        获取用户的所有身份绑定
        
        Args:
            user_id: 用户ID
            
        Returns:
            身份绑定列表
        """
        try:
            # 这里需要从数据库查询所有身份
            # 为了简化，这里只返回微信身份
            with self.db.pool.get_connection() as conn:
                cursor = conn.execute(
                    """SELECT identity_id, provider, provider_id, channel_id, is_primary, bound_at 
                       FROM user_identities WHERE user_id = ? AND unbound_at IS NULL""",
                    (user_id,)
                )
                rows = cursor.fetchall()
                return [
                    {
                        "identity_id": row['identity_id'],
                        "provider": row['provider'],
                        "provider_id": row['provider_id'],
                        "channel_id": row['channel_id'],
                        "is_primary": row['is_primary'],
                        "bound_at": row['bound_at']
                    }
                    for row in rows
                ]
        except Exception as e:
            logger.error(f"Get user identities failed: {e}")
            return []


class UserService:
    """用户服务"""
    
    def __init__(self, db: DatabaseManager = None):
        self.db = db or get_db()
        self.identity_service = IdentityService(db)
    
    def register_user(self, nickname: str, wechat_id: str, channel_id: str = "wechat_main",
                      profile_data: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        注册新用户
        
        Args:
            nickname: 昵称
            wechat_id: 微信ID
            channel_id: 频道标识
            profile_data: 用户画像数据
            
        Returns:
            {"success": bool, "user_id": str | None, "error": str | None}
        """
        try:
            # 1. 检查微信是否已绑定
            existing = self.db.get_identity_by_provider('wechat', wechat_id, channel_id)
            if existing:
                return {
                    "success": False,
                    "user_id": None,
                    "error": "WeChat ID already registered"
                }
            
            # 2. 创建用户账号
            user_id = self.db.create_user_account(nickname=nickname)
            
            # 3. 绑定微信
            bind_result = self.identity_service.bind_wechat(
                user_id=user_id,
                wechat_id=wechat_id,
                channel_id=channel_id,
                is_primary=True
            )
            
            if not bind_result['success']:
                # 回滚用户账号（简化处理，实际需要事务）
                return {
                    "success": False,
                    "user_id": None,
                    "error": bind_result['error']
                }
            
            # 4. 创建用户画像
            if profile_data:
                self.db.create_profile(user_id, profile_data)
            
            logger.info(f"User registered: user_id={user_id}, wechat_id={wechat_id}")
            
            return {
                "success": True,
                "user_id": user_id,
                "error": None
            }
            
        except Exception as e:
            logger.error(f"User registration failed: {e}")
            return {
                "success": False,
                "user_id": None,
                "error": str(e)
            }
    
    def get_user(self, user_id: str) -> Optional[Dict[str, Any]]:
        """
        获取用户完整信息
        
        Args:
            user_id: 用户ID
            
        Returns:
            用户完整信息（账号、画像、身份）
        """
        try:
            account = self.db.get_user_account(user_id)
            if not account:
                return None
            
            profile = self.db.get_profile(user_id)
            identities = self.identity_service.get_user_identities(user_id)
            
            return {
                "account": account,
                "profile": profile,
                "identities": identities
            }
        except Exception as e:
            logger.error(f"Get user failed: {e}")
            return None
    
    def get_user_by_wechat(self, wechat_id: str, channel_id: str = "wechat_main") -> Optional[Dict[str, Any]]:
        """
        通过微信ID获取用户
        
        Args:
            wechat_id: 微信ID
            channel_id: 频道标识
            
        Returns:
            用户完整信息
        """
        return self.db.get_user_by_wechat(wechat_id, channel_id)
    
    def update_profile(self, user_id: str, profile_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        更新用户画像
        
        Args:
            user_id: 用户ID
            profile_data: 画像数据
            
        Returns:
            {"success": bool, "error": str | None}
        """
        try:
            # 检查是否已有画像
            existing = self.db.get_profile(user_id)
            
            if existing:
                success = self.db.update_profile(user_id, profile_data)
            else:
                success = self.db.create_profile(user_id, profile_data)
            
            return {
                "success": success,
                "error": None if success else "Failed to update profile"
            }
        except Exception as e:
            logger.error(f"Update profile failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def update_account(self, user_id: str, updates: Dict[str, Any]) -> Dict[str, Any]:
        """
        更新用户账号信息
        
        Args:
            user_id: 用户ID
            updates: 更新字段
            
        Returns:
            {"success": bool, "error": str | None}
        """
        try:
            success = self.db.update_user_account(user_id, updates)
            return {
                "success": success,
                "error": None if success else "Failed to update account"
            }
        except Exception as e:
            logger.error(f"Update account failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def deactivate_user(self, user_id: str) -> Dict[str, Any]:
        """
        停用用户账号
        
        Args:
            user_id: 用户ID
            
        Returns:
            {"success": bool, "error": str | None}
        """
        try:
            success = self.db.update_user_account(user_id, {"status": "inactive"})
            logger.info(f"User deactivated: user_id={user_id}")
            return {
                "success": success,
                "error": None if success else "Failed to deactivate user"
            }
        except Exception as e:
            logger.error(f"Deactivate user failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }


if __name__ == "__main__":
    print("=== 用户服务模块测试 ===")
    
    from database import DatabaseManager
    
    # 使用内存数据库测试
    test_db = DatabaseManager(":memory:")
    user_service = UserService(test_db)
    identity_service = IdentityService(test_db)
    
    # 测试用户注册
    result = user_service.register_user(
        nickname="测试用户",
        wechat_id="wxid_test123",
        channel_id="wechat_main",
        profile_data={
            "investment_experience": "intermediate",
            "risk_profile": "moderate",
            "investment_style": "value"
        }
    )
    print(f"✅ 用户注册: {result}")
    
    user_id = result.get("user_id")
    
    # 测试身份识别
    identity = identity_service.identify_user("wxid_test123", "wechat_main")
    print(f"✅ 身份识别: {identity}")
    
    # 测试获取用户
    user = user_service.get_user(user_id)
    print(f"✅ 获取用户: {user}")
    
    print("\n✅ 用户服务模块测试通过")
