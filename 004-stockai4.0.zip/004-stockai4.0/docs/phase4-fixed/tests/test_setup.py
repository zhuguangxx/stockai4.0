"""
StockAI 2.0 - 初始化测试脚本
===========================
测试数据库初始化、Schema 创建、基础功能
"""

import sys
import os

# 添加父目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import tempfile
import shutil
from pathlib import Path


def test_database_initialization():
    """测试数据库初始化"""
    print("\n" + "="*60)
    print("测试 1: 数据库初始化")
    print("="*60)
    
    from database import DatabaseManager
    
    # 使用临时文件测试
    db_path = tempfile.mktemp(suffix=".db")
    
    try:
        db = DatabaseManager(db_path)
        
        # 验证表是否创建
        with db.pool.get_connection() as conn:
            cursor = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )
            tables = [row[0] for row in cursor.fetchall()]
            
            expected_tables = [
                'user_accounts', 'user_identities', 'user_profiles',
                'user_agents', 'user_sessions', 'user_watchlist',
                'user_holdings', 'messages', 'routing_log',
                'onboarding_progress', 'user_memories', 'skill_usage'
            ]
            
            for table in expected_tables:
                if table in tables:
                    print(f"  ✅ 表 {table} 已创建")
                else:
                    print(f"  ❌ 表 {table} 缺失")
                    return False
        
        print("\n  ✅ 数据库初始化测试通过")
        db.close()
        return True
        
    finally:
        if os.path.exists(db_path):
            os.remove(db_path)


def test_user_service():
    """测试用户服务"""
    print("\n" + "="*60)
    print("测试 2: 用户服务")
    print("="*60)
    
    from database import DatabaseManager
    from services.user_service import UserService, IdentityService
    
    db = DatabaseManager(":memory:")
    user_service = UserService(db)
    identity_service = IdentityService(db)
    
    # 测试用户注册
    result = user_service.register_user(
        nickname="测试用户",
        wechat_id="wxid_test_user",
        channel_id="wechat_main",
        profile_data={
            "investment_experience": "intermediate",
            "risk_profile": "moderate",
            "investment_style": "value"
        }
    )
    
    if result['success']:
        print(f"  ✅ 用户注册成功: {result['user_id']}")
        user_id = result['user_id']
    else:
        print(f"  ❌ 用户注册失败: {result['error']}")
        return False
    
    # 测试身份识别
    identity = identity_service.identify_user("wxid_test_user", "wechat_main")
    if identity.exists and identity.user_id == user_id:
        print(f"  ✅ 身份识别成功: {identity.user_id}")
    else:
        print(f"  ❌ 身份识别失败")
        return False
    
    # 测试获取用户
    user = user_service.get_user(user_id)
    if user and user['account']['nickname'] == "测试用户":
        print(f"  ✅ 获取用户信息成功")
    else:
        print(f"  ❌ 获取用户信息失败")
        return False
    
    # 测试更新画像
    update_result = user_service.update_profile(user_id, {
        "risk_profile": "aggressive"
    })
    if update_result['success']:
        print(f"  ✅ 更新画像成功")
    else:
        print(f"  ❌ 更新画像失败")
        return False
    
    print("\n  ✅ 用户服务测试通过")
    db.close()
    return True


def test_agent_service():
    """测试 Agent 服务"""
    print("\n" + "="*60)
    print("测试 3: Agent 服务")
    print("="*60)
    
    from database import DatabaseManager
    from services.user_service import UserService
    from services.agent_service import AgentService
    
    db = DatabaseManager(":memory:")
    test_dir = tempfile.mkdtemp()
    
    try:
        # 先创建用户
        user_service = UserService(db)
        reg_result = user_service.register_user(
            nickname="Agent测试用户",
            wechat_id="wxid_agent_test"
        )
        user_id = reg_result['user_id']
        
        # 测试创建 Agent
        agent_service = AgentService(db, clients_dir=test_dir)
        result = agent_service.create_client_agent(
            user_id=user_id,
            user_profile={"investment_experience": "expert"}
        )
        
        if result.success:
            print(f"  ✅ Agent 创建成功: {result.agent_id}")
            agent_id = result.agent_id
        else:
            print(f"  ❌ Agent 创建失败: {result.message}")
            return False
        
        # 测试获取 Agent
        agent = agent_service.get_client_agent(user_id)
        if agent and agent['agent_id'] == agent_id:
            print(f"  ✅ 获取 Agent 成功")
        else:
            print(f"  ❌ 获取 Agent 失败")
            return False
        
        # 测试启动/停止
        start_result = agent_service.start_agent(agent_id)
        if start_result['success']:
            print(f"  ✅ 启动 Agent 成功")
        else:
            print(f"  ❌ 启动 Agent 失败")
            return False
        
        stop_result = agent_service.stop_agent(agent_id)
        if stop_result['success']:
            print(f"  ✅ 停止 Agent 成功")
        else:
            print(f"  ❌ 停止 Agent 失败")
            return False
        
        # 验证工作空间创建
        soul_path = Path(test_dir) / agent_id / "workspace" / "SOUL.md"
        if soul_path.exists():
            print(f"  ✅ SOUL.md 创建成功")
        else:
            print(f"  ❌ SOUL.md 未创建")
            return False
        
        print("\n  ✅ Agent 服务测试通过")
        return True
        
    finally:
        db.close()
        shutil.rmtree(test_dir)


def test_onboarding_service():
    """测试问卷服务"""
    print("\n" + "="*60)
    print("测试 4: 问卷服务")
    print("="*60)
    
    from database import DatabaseManager
    from services.onboarding_service import OnboardingService
    
    db = DatabaseManager(":memory:")
    service = OnboardingService(db)
    
    # 测试开始问卷
    result = service.start_onboarding("wxid_onboarding_test")
    progress_id = result['progress_id']
    
    if progress_id:
        print(f"  ✅ 问卷开始: {progress_id}")
    else:
        print(f"  ❌ 问卷开始失败")
        return False
    
    # 模拟回答所有问题
    test_answers = [
        "李四",
        "600519.SH",
        "4",  # 专家
        "3",  # 积极型
        "2",  # 成长投资
        "1,3,5"  # 科技、医药、消费
    ]
    
    for i, answer in enumerate(test_answers):
        save_result = service.save_answer(progress_id, answer)
        if save_result['success']:
            progress = save_result['progress']
            if save_result['is_complete']:
                print(f"  ✅ 问题 {i+1} 回答完成，问卷结束")
                break
            else:
                print(f"  ✅ 问题 {i+1} 回答完成 ({progress})")
        else:
            print(f"  ❌ 问题 {i+1} 回答失败: {save_result.get('error')}")
            return False
    
    # 测试获取答案
    answers = service.get_answers(progress_id)
    if answers and len(answers.get('answers', {})) == 6:
        print(f"  ✅ 获取答案成功")
    else:
        print(f"  ❌ 获取答案失败")
        return False
    
    # 测试完成注册
    complete_result = service.complete_onboarding(progress_id)
    if complete_result.success:
        print(f"  ✅ 注册完成: user_id={complete_result.user_id}, agent_id={complete_result.agent_id}")
    else:
        print(f"  ❌ 注册完成失败: {complete_result.error}")
        return False
    
    print("\n  ✅ 问卷服务测试通过")
    db.close()
    return True


def test_watchlist_and_holdings():
    """测试自选股和持仓"""
    print("\n" + "="*60)
    print("测试 5: 自选股和持仓")
    print("="*60)
    
    from database import DatabaseManager
    from services.user_service import UserService
    
    db = DatabaseManager(":memory:")
    user_service = UserService(db)
    
    # 创建用户
    reg_result = user_service.register_user(
        nickname="持仓测试用户",
        wechat_id="wxid_holdings_test"
    )
    user_id = reg_result['user_id']
    
    # 测试添加自选股
    db.add_watchlist(user_id, "000001.SZ", "平安银行", alert_high=15.0, alert_low=10.0)
    db.add_watchlist(user_id, "600519.SH", "贵州茅台")
    
    watchlist = db.get_watchlist(user_id)
    if len(watchlist) == 2:
        print(f"  ✅ 添加自选股成功: {len(watchlist)} 只")
    else:
        print(f"  ❌ 添加自选股失败")
        return False
    
    # 测试添加持仓
    db.add_holding(user_id, "000001.SZ", 1000, 12.5, "平安银行")
    db.add_holding(user_id, "600519.SH", 100, 1500.0, "贵州茅台")
    
    holdings = db.get_holdings(user_id)
    if len(holdings) == 2:
        print(f"  ✅ 添加持仓成功: {len(holdings)} 只")
    else:
        print(f"  ❌ 添加持仓失败")
        return False
    
    # 测试删除自选股
    db.remove_watchlist(user_id, "000001.SZ")
    watchlist = db.get_watchlist(user_id)
    if len(watchlist) == 1:
        print(f"  ✅ 删除自选股成功")
    else:
        print(f"  ❌ 删除自选股失败")
        return False
    
    print("\n  ✅ 自选股和持仓测试通过")
    db.close()
    return True


def test_message_recording():
    """测试消息记录"""
    print("\n" + "="*60)
    print("测试 6: 消息记录")
    print("="*60)
    
    from database import DatabaseManager
    from services.user_service import UserService
    
    db = DatabaseManager(":memory:")
    user_service = UserService(db)
    
    # 先创建一个用户
    result = user_service.register_user(
        nickname="消息测试用户",
        wechat_id="wxid_msg_test"
    )
    user_id = result['user_id']
    
    # 记录消息（不指定agent_id，避免外键约束问题）
    msg_id = db.record_message(
        user_id=user_id,
        channel_id="wechat_main",
        wechat_id="wxid_msg_test",
        direction="inbound",
        content="帮我分析股票",
        agent_id=None
    )
    
    if msg_id:
        print(f"  ✅ 记录消息成功: {msg_id}")
    else:
        print(f"  ❌ 记录消息失败")
        return False
    
    # 获取消息历史
    messages = db.get_messages(user_id, limit=10)
    if len(messages) == 1 and messages[0]['content'] == "帮我分析股票":
        print(f"  ✅ 获取消息历史成功")
    else:
        print(f"  ❌ 获取消息历史失败")
        return False
    
    # 更新消息状态
    db.update_message_processed(msg_id, True, processing_time_ms=1500)
    messages = db.get_messages(user_id, limit=10)
    if messages[0]['processed'] and messages[0]['processing_time_ms'] == 1500:
        print(f"  ✅ 更新消息状态成功")
    else:
        print(f"  ❌ 更新消息状态失败")
        return False
    
    print("\n  ✅ 消息记录测试通过")
    db.close()
    return True


def run_all_tests():
    """运行所有测试"""
    print("\n" + "="*60)
    print("StockAI 2.0 - 初始化测试")
    print("="*60)
    
    tests = [
        ("数据库初始化", test_database_initialization),
        ("用户服务", test_user_service),
        ("Agent 服务", test_agent_service),
        ("问卷服务", test_onboarding_service),
        ("自选股和持仓", test_watchlist_and_holdings),
        ("消息记录", test_message_recording),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            success = test_func()
            results.append((name, success))
        except Exception as e:
            print(f"\n  ❌ {name} 测试异常: {e}")
            results.append((name, False))
    
    # 打印结果汇总
    print("\n" + "="*60)
    print("测试结果汇总")
    print("="*60)
    
    passed = sum(1 for _, success in results if success)
    total = len(results)
    
    for name, success in results:
        status = "✅ 通过" if success else "❌ 失败"
        print(f"  {status} {name}")
    
    print(f"\n总计: {passed}/{total} 通过")
    
    if passed == total:
        print("\n🎉 所有测试通过！系统初始化成功。")
        return 0
    else:
        print(f"\n⚠️ {total - passed} 项测试失败，请检查。")
        return 1


if __name__ == "__main__":
    sys.exit(run_all_tests())
