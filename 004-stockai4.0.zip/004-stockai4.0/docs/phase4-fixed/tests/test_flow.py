"""
StockAI 2.0 - 全流程测试脚本
===========================
模拟完整用户流程：新用户注册 -> 问卷 -> 创建Agent -> 消息路由
"""

import sys
import os

# 添加父目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import tempfile
import shutil
from pathlib import Path


def test_full_flow_new_user():
    """
    全流程测试：新用户从消息到创建Client Agent
    """
    print("\n" + "="*70)
    print("全流程测试: 新用户注册 -> 问卷 -> 创建Agent")
    print("="*70)
    
    from database import DatabaseManager
    from main_router import MainRouter
    from services.agent_service import AgentService
    
    # 初始化
    db = DatabaseManager(":memory:")
    test_dir = tempfile.mkdtemp()
    AgentService.CLIENTS_DIR = test_dir
    
    router = MainRouter(db)
    
    wechat_id = "wxid_flow_test_001"
    channel_id = "wechat_main"
    
    print("\n📱 步骤 1: 新用户发送第一条消息")
    print("-"*70)
    result = router.handle_message(
        wechat_id=wechat_id,
        channel_id=channel_id,
        message="你好"
    )
    
    print(f"   消息: '你好'")
    print(f"   路由决策: {result.action}")
    print(f"   原因: {result.reason}")
    
    if result.action != "start_onboarding":
        print(f"   ❌ 预期启动问卷，实际: {result.action}")
        return False
    
    if result.response:
        print(f"   回复预览: {result.response[:100]}...")
    print("   ✅ 新用户被正确识别，启动问卷")
    
    print("\n📋 步骤 2: 用户完成问卷")
    print("-"*70)
    
    # 模拟回答6个问题
    answers = [
        ("1", "王五"),
        ("2", "000001.SZ, 600519.SH"),
        ("3", "3"),  # 中级
        ("4", "2"),  # 稳健型
        ("5", "1"),  # 价值投资
        ("6", "1,2,3")  # 科技、金融、医药
    ]
    
    final_result = None
    
    for step, (q_num, answer) in enumerate(answers, 1):
        result = router.handle_message(
            wechat_id=wechat_id,
            channel_id=channel_id,
            message=answer
        )
        
        print(f"   问题 {step}: {answer}")
        print(f"   路由: {result.action}")
        
        if result.action in ["continue_onboarding", "route_to_client"]:
            final_result = result
            if result.action == "route_to_client":
                print(f"   ✅ 问卷完成，创建用户和Agent")
                break
        else:
            print(f"   ❌ 意外路由: {result.action}")
            return False
    
    print("\n✅ 步骤 3: 验证创建结果")
    print("-"*70)
    
    if not final_result or final_result.action != "route_to_client":
        print("   ❌ 未完成用户创建流程")
        return False
    
    user_id = final_result.user_id
    agent_id = final_result.target_agent_id
    
    print(f"   用户ID: {user_id}")
    print(f"   AgentID: {agent_id}")
    
    # 验证用户存在
    user = db.get_user_by_wechat(wechat_id, channel_id)
    if not user:
        print("   ❌ 用户未创建")
        return False
    print("   ✅ 用户已创建")
    
    # 验证Agent存在
    agent = db.get_agent(agent_id)
    if not agent:
        print("   ❌ Agent未创建")
        return False
    print("   ✅ Agent已创建")
    
    # 验证自选股
    watchlist = db.get_watchlist(user_id)
    if len(watchlist) != 2:
        print(f"   ❌ 自选股数量错误: {len(watchlist)}")
        return False
    print(f"   ✅ 自选股已添加: {len(watchlist)} 只")
    
    # 验证工作空间
    soul_path = Path(test_dir) / agent_id / "workspace" / "SOUL.md"
    if not soul_path.exists():
        print("   ❌ Agent工作空间未创建")
        return False
    print("   ✅ Agent工作空间已创建")
    
    # 验证身份识别
    from services.user_service import IdentityService
    identity_service = IdentityService(db)
    identity = identity_service.identify_user(wechat_id, channel_id)
    
    if not identity.exists:
        print("   ❌ 身份识别失败")
        return False
    if identity.user_id != user_id:
        print("   ❌ 身份识别错误")
        return False
    print("   ✅ 身份识别正确")
    
    print("\n📱 步骤 4: 老用户发送消息")
    print("-"*70)
    
    result = router.handle_message(
        wechat_id=wechat_id,
        channel_id=channel_id,
        message="帮我分析贵州茅台"
    )
    
    print(f"   消息: '帮我分析贵州茅台'")
    print(f"   路由: {result.action}")
    print(f"   用户ID: {result.user_id}")
    print(f"   AgentID: {result.target_agent_id}")
    
    if result.action != "route_to_client":
        print(f"   ❌ 预期路由到Client Agent")
        return False
    if result.user_id != user_id:
        print(f"   ❌ 用户ID不匹配")
        return False
    if result.target_agent_id != agent_id:
        print(f"   ❌ AgentID不匹配")
        return False
    
    print("   ✅ 消息正确路由到Client Agent")
    
    # 清理
    db.close()
    shutil.rmtree(test_dir)
    
    return True


def test_multiple_users():
    """测试多个用户并发场景"""
    print("\n" + "="*70)
    print("多用户测试: 并发用户场景")
    print("="*70)
    
    from database import DatabaseManager
    from main_router import MainRouter
    from services.agent_service import AgentService
    
    db = DatabaseManager(":memory:")
    test_dir = tempfile.mkdtemp()
    AgentService.CLIENTS_DIR = test_dir
    
    router = MainRouter(db)
    
    users = [
        ("wxid_user_001", "张三"),
        ("wxid_user_002", "李四"),
        ("wxid_user_003", "王五")
    ]
    
    created_users = []
    
    for wechat_id, name in users:
        print(f"\n   处理用户: {name} ({wechat_id})")
        
        # 开始问卷
        result = router.handle_message(wechat_id, "wechat_main", "开始")
        
        # 快速完成问卷（所有答案一行）
        for answer in [name, "无", "2", "2", "2", "1"]:
            result = router.handle_message(wechat_id, "wechat_main", answer)
        
        if result.action == "route_to_client" and result.user_id:
            created_users.append({
                'wechat_id': wechat_id,
                'name': name,
                'user_id': result.user_id,
                'agent_id': result.target_agent_id
            })
            print(f"   ✅ 用户 {name} 创建成功")
        else:
            print(f"   ❌ 用户 {name} 创建失败")
    
    print(f"\n   总计创建: {len(created_users)}/{len(users)} 用户")
    
    # 验证每个用户数据隔离
    print("\n   验证数据隔离...")
    
    for user_info in created_users:
        user_data = db.get_user_by_wechat(user_info['wechat_id'], 'wechat_main')
        if user_data and user_data['account']['nickname'] == user_info['name']:
            print(f"   ✅ {user_info['name']} 数据正确")
        else:
            print(f"   ❌ {user_info['name']} 数据错误")
            return False
    
    # 清理
    db.close()
    shutil.rmtree(test_dir)
    
    return len(created_users) == len(users)


def test_edge_cases():
    """测试边界情况"""
    print("\n" + "="*70)
    print("边界情况测试")
    print("="*70)
    
    from database import DatabaseManager
    from main_router import MainRouter
    from services.agent_service import AgentService
    from services.onboarding_service import OnboardingService
    
    db = DatabaseManager(":memory:")
    test_dir = tempfile.mkdtemp()
    AgentService.CLIENTS_DIR = test_dir
    
    router = MainRouter(db)
    
    # 测试1: 重复注册
    print("\n   测试1: 重复注册")
    wechat_id = "wxid_duplicate_test"
    
    # 第一次注册
    for answer in ["用户A", "无", "2", "2", "2", "1"]:
        result = router.handle_message(wechat_id, "wechat_main", answer)
    
    user_id_1 = result.user_id
    print(f"   第一次注册: {user_id_1}")
    
    # 尝试第二次（应该直接路由到Client Agent）
    result2 = router.handle_message(wechat_id, "wechat_main", "你好")
    print(f"   第二次消息路由: {result2.action}")
    
    if result2.action == "route_to_client" and result2.user_id == user_id_1:
        print("   ✅ 重复消息正确路由到现有Agent")
    else:
        print("   ❌ 重复处理失败")
        return False
    
    # 测试2: 空消息
    print("\n   测试2: 处理空消息")
    result = router.handle_message("wxid_empty", "wechat_main", "")
    if result.action == "start_onboarding":
        print("   ✅ 空消息触发新用户流程（预期行为）")
    else:
        print("   ⚠️ 空消息处理: " + result.action)
    
    # 测试3: 问卷中断后恢复
    print("\n   测试3: 问卷中断恢复")
    wechat_id_resume = "wxid_resume_test"
    
    # 开始问卷但只回答一半
    router.handle_message(wechat_id_resume, "wechat_main", "开始")
    for answer in ["用户B", "600519.SH", "3"]:  # 只回答3题
        result = router.handle_message(wechat_id_resume, "wechat_main", answer)
    
    progress_before = db.get_onboarding_by_wechat(wechat_id_resume, "wechat_main")
    print(f"   中断时进度: {progress_before['current_question']}/6")
    
    # 模拟"会话中断"，重新发送消息
    result = router.handle_message(wechat_id_resume, "wechat_main", "继续")
    print(f"   恢复后路由: {result.action}")
    
    if result.action in ["continue_onboarding", "route_to_client"]:
        print("   ✅ 问卷正确恢复")
    else:
        print("   ⚠️ 问卷恢复行为: " + result.action)
    
    # 清理
    db.close()
    shutil.rmtree(test_dir)
    
    return True


def test_health_check():
    """测试健康检查"""
    print("\n" + "="*70)
    print("健康检查测试")
    print("="*70)
    
    from database import DatabaseManager
    from main_router import MainRouter
    
    db = DatabaseManager(":memory:")
    router = MainRouter(db)
    
    health = router.health_check()
    
    print(f"   状态: {health['status']}")
    print(f"   版本: {health['version']}")
    print(f"   服务状态:")
    for service, status in health.get('services', {}).items():
        icon = "✅" if status else "❌"
        print(f"      {icon} {service}: {status}")
    
    if health['status'] == 'healthy':
        print("\n   ✅ 系统健康")
        return True
    else:
        print("\n   ⚠️ 系统状态: " + health['status'])
        return health['status'] != 'unhealthy'


def run_all_tests():
    """运行所有测试"""
    print("\n" + "="*70)
    print("StockAI 2.0 - 全流程测试")
    print("="*70)
    
    tests = [
        ("全流程-新用户注册", test_full_flow_new_user),
        ("多用户并发", test_multiple_users),
        ("边界情况", test_edge_cases),
        ("健康检查", test_health_check),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            print(f"\n\n{'='*70}")
            print(f"开始测试: {name}")
            print('='*70)
            success = test_func()
            results.append((name, success))
            if success:
                print(f"\n✅ {name} 测试通过")
            else:
                print(f"\n❌ {name} 测试失败")
        except Exception as e:
            print(f"\n❌ {name} 测试异常: {e}")
            import traceback
            traceback.print_exc()
            results.append((name, False))
    
    # 打印结果汇总
    print("\n\n" + "="*70)
    print("测试结果汇总")
    print("="*70)
    
    passed = sum(1 for _, success in results if success)
    total = len(results)
    
    for name, success in results:
        status = "✅ 通过" if success else "❌ 失败"
        print(f"  {status} {name}")
    
    print(f"\n总计: {passed}/{total} 通过")
    
    if passed == total:
        print("\n🎉 所有全流程测试通过！")
        return 0
    else:
        print(f"\n⚠️ {total - passed} 项测试失败，请检查。")
        return 1


if __name__ == "__main__":
    sys.exit(run_all_tests())
