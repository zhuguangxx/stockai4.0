"""
StockAI 2.0 - Phase 4 修复验证脚本
==================================
验证以下三个生产问题修复：
1. API限流保护
2. 数据库事务支持
3. 错误监控告警
"""

import sys
import time
import threading
from pathlib import Path

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent))


def test_rate_limiting():
    """测试 API 限流保护"""
    print("\n" + "="*60)
    print("测试 1: API 限流保护")
    print("="*60)
    
    from main_router import RateLimiter
    
    limiter = RateLimiter()
    test_user = "test_user_001"
    
    # 测试消息限流：30条/分钟
    print("\n1.1 测试消息限流 (30条/分钟)...")
    passed = 0
    blocked = 0
    
    for i in range(35):
        allowed, msg = limiter.check_message_limit(test_user)
        if allowed:
            passed += 1
        else:
            blocked += 1
    
    print(f"   发送35条消息: 通过 {passed} 条, 限制 {blocked} 条")
    assert passed == 30, f"应该通过30条，实际通过{passed}条"
    assert blocked == 5, f"应该限制5条，实际限制{blocked}条"
    print("   ✅ 消息限流测试通过")
    
    # 测试实时查询限流：5次/分钟
    print("\n1.2 测试实时查询限流 (5次/分钟)...")
    query_passed = 0
    query_blocked = 0
    
    for i in range(7):
        allowed, msg = limiter.check_query_limit("query_user_001")
        if allowed:
            query_passed += 1
        else:
            query_blocked += 1
    
    print(f"   尝试7次查询: 通过 {query_passed} 次, 限制 {query_blocked} 次")
    assert query_passed == 5, f"应该通过5次，实际通过{query_passed}次"
    assert query_blocked == 2, f"应该限制2次，实际限制{query_blocked}次"
    print("   ✅ 实时查询限流测试通过")
    
    # 测试限流状态查询
    print("\n1.3 测试限流状态查询...")
    status = limiter.get_status(test_user)
    print(f"   消息使用: {status['message']['used']}/{status['message']['limit']}")
    print(f"   查询使用: {status['query']['used']}/{status['query']['limit']}")
    assert status['message']['limit'] == 30
    assert status['query']['limit'] == 5
    print("   ✅ 限流状态查询测试通过")
    
    # 测试滑动窗口（等待后应可继续）
    print("\n1.4 测试滑动窗口重置...")
    # 新用户应该可以正常发送
    new_user = "test_user_002"
    allowed, _ = limiter.check_message_limit(new_user)
    assert allowed, "新用户应该可以发送消息"
    print("   ✅ 滑动窗口测试通过")
    
    print("\n✅ 限流保护测试全部通过")
    return True


def test_database_transaction():
    """测试数据库事务支持"""
    print("\n" + "="*60)
    print("测试 2: 数据库事务支持")
    print("="*60)
    
    from database import DatabaseManager
    import tempfile
    import os
    
    # 使用临时文件数据库（内存数据库每个连接独立，不适合测试事务）
    temp_db = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
    temp_db.close()
    db_path = temp_db.name
    
    try:
        db = DatabaseManager(db_path)
        
        # 测试事务上下文管理器
        print("\n2.1 测试事务上下文管理器...")
        try:
            with db.transaction() as conn:
                # 执行多个操作
                conn.execute(
                    "INSERT INTO user_accounts (user_id, nickname, created_at, updated_at) VALUES (?, ?, datetime('now'), datetime('now'))",
                    ("test_tx_001", "事务测试用户")
                )
                conn.execute(
                    "INSERT INTO user_identities (identity_id, user_id, provider, provider_id, channel_id, bound_at) VALUES (?, ?, ?, ?, ?, datetime('now'))",
                    ("test_id_001", "test_tx_001", "wechat", "wxid_tx_001", "wechat_main")
                )
            print("   ✅ 事务提交成功")
        except Exception as e:
            print(f"   ❌ 事务提交失败: {e}")
            return False
        
        # 验证数据已写入
        user = db.get_user_account("test_tx_001")
        identity = db.get_identity_by_provider("wechat", "wxid_tx_001")
        assert user is not None, "用户应该已创建"
        assert identity is not None, "身份应该已创建"
        print("   ✅ 事务数据验证通过")
        
        # 测试事务回滚
        print("\n2.2 测试事务回滚...")
        rollback_test_id = "test_rollback_001"
        try:
            with db.transaction() as conn:
                conn.execute(
                    "INSERT INTO user_accounts (user_id, nickname, created_at, updated_at) VALUES (?, ?, datetime('now'), datetime('now'))",
                    (rollback_test_id, "回滚测试用户")
                )
                # 故意抛出异常
                raise ValueError("故意触发回滚")
        except ValueError:
            pass  # 预期异常
        
        # 验证数据未写入
        user = db.get_user_account(rollback_test_id)
        assert user is None, "回滚后数据不应该存在"
        print("   ✅ 事务回滚测试通过")
        
        # 测试完整用户创建事务
        print("\n2.3 测试完整用户创建事务...")
        try:
            result = db.create_complete_user_transaction(
                wechat_id="wxid_complete_001",
                nickname="完整测试用户",
                profile_data={
                    'investment_experience': 'junior',
                    'risk_profile': 'moderate',
                    'investment_style': 'value',
                    'focus_sectors': ['科技', '消费'],
                    'preferences': {'language': 'zh'}
                },
                agent_name="完整测试Agent"
            )
            
            # 验证所有数据
            user = db.get_user_account(result['user_id'])
            identity = db.get_identity_by_provider('wechat', 'wxid_complete_001')
            profile = db.get_profile(result['user_id'])
            agent = db.get_agent(result['agent_id'])
            
            assert user is not None, "用户应该已创建"
            assert identity is not None, "身份应该已创建"
            assert profile is not None, "画像应该已创建"
            assert agent is not None, "Agent应该已创建"
            print(f"   创建结果: {result}")
            print("   ✅ 完整用户创建事务测试通过")
        except Exception as e:
            print(f"   ❌ 完整用户创建失败: {e}")
            return False
        
        print("\n✅ 数据库事务测试全部通过")
        return True
    finally:
        # 清理临时数据库文件
        try:
            os.unlink(db_path)
        except:
            pass


def test_monitoring():
    """测试错误监控告警"""
    print("\n" + "="*60)
    print("测试 3: 错误监控告警")
    print("="*60)
    
    from monitoring import MonitoringManager, ErrorRecord
    
    # 使用新的监控实例（避免单例影响）
    monitoring = MonitoringManager.__new__(MonitoringManager)
    monitoring._initialized = False
    monitoring.__init__()
    
    # 测试错误记录
    print("\n3.1 测试错误记录...")
    try:
        raise ValueError("测试错误记录功能")
    except Exception as e:
        error_id = monitoring.record_error(
            error=e,
            level="ERROR",
            context={"error_code": "TEST_ERROR", "action": "test_monitoring"},
            user_id="test_user",
            wechat_id="wxid_test"
        )
    print(f"   错误已记录: {error_id}")
    assert error_id.startswith("ERR-"), "错误ID格式正确"
    print("   ✅ 错误记录测试通过")
    
    # 测试健康检查
    print("\n3.2 测试健康检查接口...")
    health = monitoring.get_health_status()
    print(f"   状态: {health.status}")
    print(f"   版本: {health.version}")
    print(f"   运行时间: {health.uptime_seconds}秒")
    print(f"   1小时错误数: {health.error_count_1h}")
    print(f"   检查项: {health.checks}")
    assert health.status in ["healthy", "degraded", "unhealthy"]
    assert health.version == "2.0.0"
    print("   ✅ 健康检查测试通过")
    
    # 测试错误统计
    print("\n3.3 测试错误统计...")
    stats = monitoring.get_error_stats(hours=1)
    print(f"   总错误数: {stats['total_errors']}")
    print(f"   按类型: {stats['by_type']}")
    print(f"   按级别: {stats['by_level']}")
    assert stats['total_errors'] >= 1  # 至少记录了我们刚才的错误
    print("   ✅ 错误统计测试通过")
    
    # 测试告警日志文件
    print("\n3.4 测试日志文件写入...")
    from monitoring import LOG_DIR, ERROR_LOG_FILE
    assert LOG_DIR.exists(), "日志目录应该存在"
    assert ERROR_LOG_FILE.exists(), "错误日志文件应该存在"
    print(f"   日志目录: {LOG_DIR}")
    print(f"   错误日志: {ERROR_LOG_FILE} ({ERROR_LOG_FILE.stat().st_size} bytes)")
    print("   ✅ 日志文件测试通过")
    
    print("\n✅ 错误监控告警测试全部通过")
    return True


def test_integration():
    """测试集成：限流 + 监控"""
    print("\n" + "="*60)
    print("测试 4: 集成测试")
    print("="*60)
    
    from main_router import MainRouter
    from database import DatabaseManager
    from monitoring import monitoring
    import tempfile
    
    # 创建测试环境
    test_db = DatabaseManager(":memory:")
    test_dir = tempfile.mkdtemp()
    
    try:
        # 更新 AgentService 的 clients_dir
        from services.agent_service import AgentService
        AgentService.CLIENTS_DIR = test_dir
        
        router = MainRouter(test_db)
        
        print("\n4.1 测试限流触发时的监控记录...")
        test_user = "rate_limit_test_user"
        
        # 快速发送超过限制的消息
        rate_limited_results = []
        for i in range(35):
            allowed, msg = router.rate_limiter.check_message_limit(test_user)
            if not allowed:
                rate_limited_results.append(msg)
        
        assert len(rate_limited_results) > 0, "应该有被限制的消息"
        print(f"   被限制消息数: {len(rate_limited_results)}")
        print("   ✅ 限流触发正常")
        
        # 测试健康检查包含所有模块
        print("\n4.2 测试综合健康检查...")
        health = router.health_check()
        print(f"   状态: {health['status']}")
        print(f"   服务: {health['services']}")
        print(f"   限流配置: {health['rate_limits']}")
        
        assert 'rate_limiter' in health['services']
        assert 'monitoring' in health['services']
        assert 'database' in health['services']
        print("   ✅ 综合健康检查正常")
        
        print("\n✅ 集成测试全部通过")
        return True
        
    finally:
        import shutil
        shutil.rmtree(test_dir)


def run_all_tests():
    """运行所有测试"""
    print("\n" + "="*70)
    print("StockAI 2.0 - Phase 4 生产问题修复验证")
    print("="*70)
    
    results = []
    
    # 测试1: API限流保护
    try:
        results.append(("API限流保护", test_rate_limiting()))
    except Exception as e:
        print(f"\n❌ API限流保护测试失败: {e}")
        results.append(("API限流保护", False))
    
    # 测试2: 数据库事务支持
    try:
        results.append(("数据库事务支持", test_database_transaction()))
    except Exception as e:
        print(f"\n❌ 数据库事务支持测试失败: {e}")
        import traceback
        traceback.print_exc()
        results.append(("数据库事务支持", False))
    
    # 测试3: 错误监控告警
    try:
        results.append(("错误监控告警", test_monitoring()))
    except Exception as e:
        print(f"\n❌ 错误监控告警测试失败: {e}")
        import traceback
        traceback.print_exc()
        results.append(("错误监控告警", False))
    
    # 测试4: 集成测试
    try:
        results.append(("集成测试", test_integration()))
    except Exception as e:
        print(f"\n❌ 集成测试失败: {e}")
        import traceback
        traceback.print_exc()
        results.append(("集成测试", False))
    
    # 打印测试报告
    print("\n" + "="*70)
    print("测试报告")
    print("="*70)
    
    for name, passed in results:
        status = "✅ 通过" if passed else "❌ 失败"
        print(f"  {status}: {name}")
    
    all_passed = all(passed for _, passed in results)
    
    print("\n" + "="*70)
    if all_passed:
        print("🎉 所有测试通过！生产问题修复验证完成。")
    else:
        print("⚠️ 部分测试失败，请检查修复代码。")
    print("="*70)
    
    return all_passed


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
