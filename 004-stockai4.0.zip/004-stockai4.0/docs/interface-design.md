# StockAI 4.0 接口设计（统一 Main Agent）

## 1. 接口设计原则

### 1.1 与官方文档对照

根据 `docs.openclaw.ai/tools/subagents.md` 和 `docs.openclaw.ai/concepts/session-tool.md`：

```python
# 官方 sessions_spawn 接口
sessions_spawn(
    task: str,
    runtime: "subagent" | "acp",
    agentId?: str,
    timeout?: int
) -> str

# 官方消息处理入口（Gateway 调用）
def on_message(payload: dict) -> str:
    """
    payload = {
        "sender_id": "ou_xxx",      # open_id
        "content": "消息内容",
        "msg_type": "text",
        "timestamp": "2026-04-05T12:00:00Z"
    }
    return "回复内容"
    """
```

### 1.2 接口分层

```
┌─────────────────────────────────────────┐
│  Layer 1: 入口层 (Gateway Interface)      │
│  - on_message()                         │
│  - 被 OpenClaw Gateway 调用              │
└─────────────────┬───────────────────────┘
                  │
┌─────────────────▼───────────────────────┐
│  Layer 2: 路由层 (Router)                │
│  - handle_message()                     │
│  - route_by_user_status()               │
│  - parse_command()                      │
└─────────────────┬───────────────────────┘
                  │
┌─────────────────▼───────────────────────┐
│  Layer 3: 服务层 (Services)              │
│  - IdentityService                      │
│  - OnboardingService                    │
│  - UserMemoryService                    │
│  - StockAnalysisService                 │
│  - SubAgentDispatcher                   │
└─────────────────────────────────────────┘
```

## 2. 核心接口定义

### 2.1 Layer 1: 入口层

```python
# src/entry.py
from typing import Dict, Any

def on_message(payload: Dict[str, Any]) -> str:
    """
    OpenClaw Gateway 消息入口
    
    Args:
        payload: {
            "sender_id": str,      # 微信 open_id (必需)
            "content": str,        # 消息内容 (必需)
            "msg_type": str,       # 消息类型: text/image (必需)
            "timestamp": str,      # ISO 8601 时间戳 (可选)
            "channel": str,        # 渠道标识 (可选)
            "account_id": str      # 账号标识 (可选)
        }
    
    Returns:
        str: 回复给用户的文本
        
    Raises:
        无异常抛出，内部捕获所有异常并返回错误提示
    """
    pass
```

### 2.2 Layer 2: 路由层

```python
# src/router.py
from typing import Dict, Any, Optional
from dataclasses import dataclass

@dataclass
class UserContext:
    """用户上下文"""
    user_id: str
    open_id: str
    name: str
    status: str          # new/onboarding/active
    profile: Optional[Dict] = None

@dataclass  
class Message:
    """消息对象"""
    sender_id: str       # open_id
    content: str
    msg_type: str
    timestamp: Optional[str] = None

class MessageRouter:
    """消息路由器"""
    
    def handle_message(self, message: Message) -> str:
        """
        主处理入口
        
        流程:
        1. 识别用户身份
        2. 根据状态路由
        3. 返回响应
        """
        pass
    
    def identify_user(self, open_id: str) -> UserContext:
        """
        识别用户
        
        - 新用户: 自动创建，返回 status='new'
        - 老用户: 查询返回
        """
        pass
    
    def route_by_status(self, user: UserContext, message: Message) -> str:
        """
        根据用户状态路由
        
        - new: 启动 onboarding
        - onboarding: 继续问卷
        - active: 业务处理
        """
        pass
    
    def parse_command(self, content: str) -> Dict[str, Any]:
        """
        解析用户指令
        
        Returns:
            {
                "type": "stock_analysis" | "watchlist" | "position" | "help" | "unknown",
                "params": {...}
            }
        """
        pass
```

### 2.3 Layer 3: 服务层

#### IdentityService

```python
# src/services/identity.py
from typing import Optional, Dict, Any

class IdentityService:
    """身份识别服务"""
    
    def get_or_create_user(self, open_id: str) -> Dict[str, Any]:
        """
        获取或创建用户
        
        Args:
            open_id: 微信用户唯一标识
            
        Returns:
            {
                "user_id": str,
                "open_id": str,
                "name": str,
                "status": str,
                "created_at": str,
                "last_active": str
            }
        """
        pass
    
    def get_user_by_open_id(self, open_id: str) -> Optional[Dict]:
        """通过 open_id 查询用户"""
        pass
    
    def create_user(self, open_id: str) -> Dict:
        """创建新用户"""
        pass
    
    def update_user_status(self, open_id: str, status: str) -> bool:
        """更新用户状态"""
        pass
    
    def update_last_active(self, open_id: str) -> bool:
        """更新最后活跃时间"""
        pass
```

#### OnboardingService

```python
# src/services/onboarding.py
from typing import Dict, Any, Optional, List

class OnboardingService:
    """问卷服务"""
    
    QUESTIONS = [
        {
            "id": 1,
            "key": "name",
            "question": "👋 欢迎！请问怎么称呼您？",
            "type": "text"
        },
        {
            "id": 2,
            "key": "watchlist",
            "question": "📈 您关注哪些股票？（可跳过）",
            "type": "text"
        },
        {
            "id": 3,
            "key": "experience",
            "question": "🎯 您的投资经验？\n1.新手 2.初级 3.中级 4.资深",
            "type": "choice",
            "options": ["newbie", "junior", "intermediate", "expert"]
        },
        {
            "id": 4,
            "key": "risk_level",
            "question": "⚖️ 您的风险承受能力？\n1.保守 2.稳健 3.积极 4.激进",
            "type": "choice",
            "options": ["conservative", "moderate", "aggressive", "radical"]
        },
        {
            "id": 5,
            "key": "style",
            "question": "🔄 您的投资风格？\n1.价值 2.成长 3.股息 4.波段 5.短线",
            "type": "choice",
            "options": ["value", "growth", "dividend", "swing", "daytrade"]
        },
        {
            "id": 6,
            "key": "focus_sectors",
            "question": "🏭 关注的行业？（多选用逗号分隔）\n1.科技 2.金融 3.医药 4.新能源 5.消费 6.制造",
            "type": "multi_choice",
            "options": ["tech", "finance", "healthcare", "energy", "consumer", "manufacturing"]
        }
    ]
    
    def get_current_question(self, open_id: str) -> Optional[Dict]:
        """获取当前问题"""
        pass
    
    def process_answer(self, open_id: str, answer: str) -> Dict[str, Any]:
        """
        处理用户答案
        
        Returns:
            {
                "success": bool,
                "completed": bool,
                "next_question": Optional[str],
                "progress": str,      # "1/6"
                "message": str
            }
        """
        pass
    
    def is_completed(self, open_id: str) -> bool:
        """检查是否完成问卷"""
        pass
    
    def get_answers(self, open_id: str) -> Optional[Dict]:
        """获取所有答案"""
        pass
    
    def complete_onboarding(self, open_id: str) -> bool:
        """完成问卷，保存用户画像"""
        pass
```

#### UserMemoryService

```python
# src/services/user_memory.py
from typing import List, Dict, Any, Optional
from dataclasses import dataclass

@dataclass
class UserProfile:
    name: str
    experience: str
    risk_level: str
    style: str
    focus_sectors: List[str]

@dataclass
class Position:
    stock_code: str
    shares: float
    avg_cost: float

class UserMemoryService:
    """用户记忆服务"""
    
    # ========== 画像管理 ==========
    def save_profile(self, user_id: str, profile: Dict) -> bool:
        """保存用户画像"""
        pass
    
    def get_profile(self, user_id: str) -> Optional[UserProfile]:
        """获取用户画像"""
        pass
    
    # ========== 自选管理 ==========
    def add_watchlist(self, user_id: str, stock_code: str) -> bool:
        """添加自选"""
        pass
    
    def remove_watchlist(self, user_id: str, stock_code: str) -> bool:
        """删除自选"""
        pass
    
    def get_watchlist(self, user_id: str) -> List[str]:
        """获取自选列表"""
        pass
    
    def is_in_watchlist(self, user_id: str, stock_code: str) -> bool:
        """检查是否在自选"""
        pass
    
    # ========== 持仓管理 ==========
    def add_position(self, user_id: str, stock_code: str, shares: float, price: float) -> bool:
        """买入/加仓，自动计算加权平均成本"""
        pass
    
    def reduce_position(self, user_id: str, stock_code: str, shares: float) -> Dict:
        """卖出/减仓
        
        Returns:
            {"success": bool, "message": str}
        """
        pass
    
    def get_positions(self, user_id: str) -> List[Position]:
        """获取持仓列表"""
        pass
    
    def get_position(self, user_id: str, stock_code: str) -> Optional[Position]:
        """获取单只股票持仓"""
        pass
```

#### StockAnalysisService

```python
# src/services/stock_analysis.py
from typing import Dict, Any
from dataclasses import dataclass

@dataclass
class AnalysisResult:
    stock_code: str
    current_price: float
    change_pct: float
    ma5: float
    ma20: float
    rsi: float
    macd: float
    expert_scores: Dict[str, int]  # 六大专家评分
    overall_score: int
    report: str

class StockAnalysisService:
    """股票分析服务"""
    
    def analyze(self, stock_code: str, risk_level: str = "moderate") -> AnalysisResult:
        """
        分析股票
        
        Args:
            stock_code: 股票代码（如 000001.SZ）
            risk_level: 用户风险偏好（影响评分权重）
            
        Returns:
            AnalysisResult
        """
        pass
    
    def fetch_stock_data(self, stock_code: str, days: int = 60) -> Any:
        """获取股票历史数据"""
        pass
    
    def calculate_indicators(self, data: Any) -> Dict:
        """计算技术指标"""
        pass
    
    def experts_analysis(self, indicators: Dict, risk_level: str) -> Dict[str, int]:
        """
        六大专家分析
        
        - 趋势专家
        - 动能专家
        - 超买超卖专家
        - 波动专家
        - 量价专家
        - 风险匹配专家
        """
        pass
```

#### SubAgentDispatcher

```python
# src/services/subagent_dispatcher.py
from typing import Dict, Any, Optional

class SubAgentDispatcher:
    """Sub-Agent 调度器"""
    
    def dispatch(self, task: str, timeout: int = 120) -> Dict[str, Any]:
        """
        调度 Sub-Agent 执行任务
        
        Args:
            task: 任务描述
            timeout: 超时时间（秒）
            
        Returns:
            {
                "success": bool,
                "result": str,
                "error": Optional[str]
            }
        """
        pass
    
    def deep_research(self, stock_code: str, user_context: Dict) -> str:
        """
        深度研究
        
        调用 sessions_spawn 创建临时 Sub-Agent
        """
        task = f"""
        深度研究股票 {stock_code}
        
        用户画像：
        - 风险偏好：{user_context.get('risk_level')}
        - 投资风格：{user_context.get('style')}
        - 投资经验：{user_context.get('experience')}
        
        请提供：
        1. 基本面分析
        2. 技术面分析
        3. 行业对比
        4. 风险评估
        5. 投资建议（符合用户风险偏好）
        """
        result = self.dispatch(task, timeout=120)
        return result.get("result", "分析失败") if result.get("success") else "分析失败"
    
    def backtest_strategy(self, strategy: str, params: Dict, user_context: Dict) -> str:
        """策略回测"""
        pass
```

## 3. 数据模型（Pydantic）

```python
# src/models.py
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime

class User(BaseModel):
    """用户模型"""
    user_id: str
    open_id: str
    name: str = "用户"
    status: str = Field(default="new", regex="^(new|onboarding|active|inactive)$")
    created_at: datetime = Field(default_factory=datetime.now)
    last_active: Optional[datetime] = None

class UserProfile(BaseModel):
    """用户画像"""
    user_id: str
    name: str = "用户"
    experience: str = Field(regex="^(newbie|junior|intermediate|expert)$")
    risk_level: str = Field(regex="^(conservative|moderate|aggressive|radical)$")
    style: str = Field(regex="^(value|growth|dividend|swing|daytrade)$")
    focus_sectors: List[str] = Field(default_factory=list)
    updated_at: datetime = Field(default_factory=datetime.now)

class OnboardingProgress(BaseModel):
    """问卷进度"""
    open_id: str
    current_question: int = Field(default=0, ge=0, le=6)
    answers: Dict[str, Any] = Field(default_factory=dict)
    status: str = Field(default="in_progress", regex="^(in_progress|completed)$")
    start_time: datetime = Field(default_factory=datetime.now)
    complete_time: Optional[datetime] = None

class WatchlistItem(BaseModel):
    """自选股票"""
    user_id: str
    stock_code: str
    added_at: datetime = Field(default_factory=datetime.now)

class Position(BaseModel):
    """持仓"""
    user_id: str
    stock_code: str
    shares: float = Field(default=0, ge=0)
    avg_cost: float = Field(default=0, ge=0)
    updated_at: datetime = Field(default_factory=datetime.now)

class QueryHistory(BaseModel):
    """查询历史"""
    id: Optional[int] = None
    user_id: str
    stock_code: str
    query_type: str = "analysis"
    result_summary: str = ""
    created_at: datetime = Field(default_factory=datetime.now)
```

## 4. 错误码定义

```python
# src/errors.py

class ErrorCode:
    """错误码定义"""
    
    # 系统错误 (1000-1999)
    SYSTEM_ERROR = 1000
    DATABASE_ERROR = 1001
    CONFIG_ERROR = 1002
    
    # 用户错误 (2000-2999)
    USER_NOT_FOUND = 2000
    INVALID_OPEN_ID = 2001
    USER_INACTIVE = 2002
    ONBOARDING_INCOMPLETE = 2003
    
    # 业务错误 (3000-3999)
    STOCK_CODE_INVALID = 3000
    STOCK_DATA_NOT_FOUND = 3001
    ANALYSIS_FAILED = 3002
    WATCHLIST_EXISTS = 3003
    WATCHLIST_NOT_FOUND = 3004
    POSITION_NOT_FOUND = 3005
    INSUFFICIENT_SHARES = 3006
    
    # 外部服务错误 (4000-4999)
    DATASOURCE_ERROR = 4000
    SUBAGENT_TIMEOUT = 4001
    SUBAGENT_FAILED = 4002

class StockAIError(Exception):
    """业务异常"""
    def __init__(self, code: int, message: str, details: Dict = None):
        self.code = code
        self.message = message
        self.details = details or {}
        super().__init__(self.message)
```

## 5. 接口调用示例

### 5.1 新用户流程

```python
# 用户发送首条消息
payload = {
    "sender_id": "ou_wechat_xxx",
    "content": "你好",
    "msg_type": "text"
}

# on_message() 调用链:
response = on_message(payload)
# -> MessageRouter.handle_message()
#    -> IdentityService.get_or_create_user()  [创建用户]
#    -> OnboardingService.get_current_question()  [返回问题1]
#    -> "👋 欢迎！请问怎么称呼您？"

# 用户回答
payload = {"sender_id": "ou_wechat_xxx", "content": "张三"}
response = on_message(payload)
# -> OnboardingService.process_answer()
#    -> 保存答案，返回问题2
#    -> "📈 您关注哪些股票？"
```

### 5.2 股票分析流程

```python
# 活跃用户发送股票代码
payload = {"sender_id": "ou_wechat_xxx", "content": "000001"}
response = on_message(payload)
# -> MessageRouter.handle_message()
#    -> identify_user()  [识别用户]
#    -> parse_command()  [识别为股票代码]
#    -> UserMemoryService.get_profile()  [加载风险偏好]
#    -> StockAnalysisService.analyze("000001.SZ", "moderate")
#       -> fetch_stock_data()  [获取数据]
#       -> calculate_indicators()  [计算指标]
#       -> experts_analysis()  [专家分析]
#    -> 返回分析报告
```

### 5.3 深度研究流程

```python
# 用户请求深度分析
payload = {"sender_id": "ou_wechat_xxx", "content": "深度分析茅台"}
response = on_message(payload)
# -> parse_command()  [识别为深度研究]
# -> UserMemoryService.get_profile()  [加载上下文]
# -> SubAgentDispatcher.deep_research("600519.SH", user_context)
#    -> sessions_spawn(task="...", runtime="subagent", timeout=120)
#    -> 等待 Sub-Agent 返回
# -> 返回深度分析报告
```

## 6. 与官方接口对照

| 功能 | 官方接口 | 4.0 使用 | 符合度 |
|------|---------|---------|-------|
| 消息入口 | Gateway 调用 | `on_message()` | ✅ 100% |
| 子Agent计算 | `sessions_spawn()` | `SubAgentDispatcher.dispatch()` | ✅ 100% |
| 数据存储 | 自定义 | SQLite | ✅ 允许 |
| 配置 | `openclaw.json` | 静态配置 | ✅ 官方推荐 |

## 7. 待实现清单

- [ ] `src/entry.py` - 入口层
- [ ] `src/router.py` - 路由层
- [ ] `src/services/identity.py` - 身份服务
- [ ] `src/services/onboarding.py` - 问卷服务
- [ ] `src/services/user_memory.py` - 用户记忆
- [ ] `src/services/stock_analysis.py` - 股票分析
- [ ] `src/services/subagent_dispatcher.py` - Sub-Agent调度
- [ ] `src/models.py` - 数据模型
- [ ] `src/errors.py` - 错误定义
